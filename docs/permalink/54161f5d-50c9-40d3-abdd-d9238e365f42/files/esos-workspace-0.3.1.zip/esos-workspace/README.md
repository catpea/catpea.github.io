# eSOS Workspace 0.3.1

A local browser operating environment with a terminal, persistent files, native DOM devices, optional applications, and a complete project → publish → install → share workflow.

**This release delivers Software, Automate, Workbench, Cards, shared program runtimes, and an optional Linux folder connection.** The authoring applications are optional packages. A published program runs with its runtime dependencies; its editor does not need to remain installed.

**Delivery status:** implemented source release with focused storage, package lifecycle, command, workflow, and synchronization checks. Real-browser interaction and offline acceptance remain pending in this environment. The precise evidence and remaining walkthrough are in [verification.xml](docs/verification.xml).

## 0.3.1 application startup repair

The Applications menu, terminal commands, and Offline indicator now use one service-worker lifecycle. Opening an installed application waits for core installation, activation, control of the current page, and an acknowledgement of the verified package route. It no longer guesses readiness from an independent eight-second wait.

An already-active worker can be asked to claim an uncontrolled page. The worker is generated as a self-contained classic script, so registration no longer depends on module service-worker support. Registration, download, integrity, storage, and control failures have distinct `E_OFFLINE_*` diagnostics; terminal errors preserve those codes. `esos.v1.system.status()` includes the same offline status displayed by the desktop.

This is a startup repair. The volume format, package cache names, installed program records, and project formats remain unchanged. See [offline.xml](docs/offline.xml) for the lifecycle and diagnostic contract.

## Run

Use Node.js 22 or newer:

```sh
cd esos-workspace
npm start
```

There is no `npm install` step. SQLite WASM and Bootstrap are vendored. Open the printed address, normally **http://127.0.0.1:5173**. Use localhost or HTTPS; opening `index.html` directly is insufficient.

The browser runs eSOS and owns its OPFS volume. Node serves the files and, only when explicitly configured, the Linux folder adapter. Required browser capabilities include WebAssembly, dedicated workers, OPFS synchronous access handles, Web Locks, service workers for installed package delivery, and modern CSS container queries.

Keep the scheme, hostname, and port consistent. `localhost` and `127.0.0.1` have different browser storage. `ESOS_HOST` and `ESOS_PORT` configure the server; changing the origin does not move data.

## First session

The terminal asks for a local username, for example `alice`. The desktop fills the browser content area, with its Applications menu, Search, Terminal, and taskbar in the floating dock.

Start with:

```text
open software
```

Install **Automate**, **Workbench**, and **Cards** from Software. Each installation includes the exact shared runtime dependencies it needs. The equivalent commands are:

```text
software install automate
software install workbench
software install cards
open automate
open workbench
open cards
```

Wait for the Applications menu to report **Available offline** before relying on cached startup. Installed package assets have separate verified caches. An uninstalled application is not part of the browser's core startup cache, even though its distributable files are included in this source release.

The username identifies a local workspace. Password unlock, encrypted volumes, and multi-user isolation remain a later coherent group.

## The four applications

| Application | What it does | What remains after removing the editor |
| --- | --- | --- |
| **Software** | Lists, installs, enables, disables, repairs, and removes optional packages; imports and exports published programs. | Software is a core service and recovery surface. |
| **Automate** | Builds ordered workflows from understandable actions; configures parameters, checks stream compatibility, runs, stops, saves, and publishes them. | Saved workflow files and published programs run with `runtime.workflows`. |
| **Workbench** | Designs forms with a component palette, a design surface, properties, command actions, split regions, and a runnable preview. | Saved form projects and published programs run with `runtime.forms`. |
| **Cards** | Authors stacks with multiple cards, a shared background, fields, pictures, navigation buttons, and command actions. | Saved stacks and published programs run with the card/form runtimes. |

A small optional **Calculator** provides an immediately useful independent package, including a `calc` command and retained history. It also exercises installation without introducing an editor dependency.

### Automate

Actions speak in terms of work: **Ask for text**, **Read a file**, **List a folder**, **Get tasks**, **Keep matching records**, **Transform text**, **Replace text**, **Split into lines**, **Save text to a file**, and **Create tasks from text**. Their implementations call ordinary system commands with separate argument strings and strict NDJSON streams.

A useful workflow is:

1. Get tasks.
2. Keep matching records where `done` equals `false`.
3. Use the `title` field as text.
4. Save text to a file, such as `~/open-tasks.txt`.

Choose **Create a new file** for the first run. Choose **Replace the current file revision** when replacement is intended. Streams have explicit input/output categories; incompatible sequences are reported before execution. A running workflow exposes its progress, bounded results, diagnostics, and completed-effect receipts. Stop requests cooperative cancellation. Previously committed effects remain committed; actions are not silently retried.

### Workbench and Cards

Select a region, add components, and edit properties. Right-click a region for **Split left**, **Split right**, **Split up**, or **Split down**; the layout tools also provide a discoverable control path. A split has a ratio and a responsive collapse threshold.

There is one `container-fluid` root and one named `esos-window` query container per application window. Nested regions use CSS Grid and native Bootstrap controls. Restoring a wide application to a narrow window triggers its compact layout even when the browser itself is wide. A project can start maximized and can hide the caption bar. A small **Show window controls** button and desktop recovery keep it manageable.

Buttons bind to installed commands, messages, field updates, or card navigation. Command arguments can reference a field using `{{FIELD_ID}}`; the editor exposes component identities. Arguments remain separate strings, so field text is not interpreted as shell syntax. Command output can appear in a result component.

Cards shares a background across its cards and retains each field's value across navigation. In a running form or stack, **Save data** commits field values through the OS state service. **Reload data** retrieves the saved revision. A second window cannot silently overwrite newer saved state.

## Create → publish → install → share

1. Create a project in an authoring application and save its ordinary `.esos.json` file.
2. Preview or run it. Save retains the design; Save data in a running program retains its field values.
3. Choose **Publish**. Software receives a content-identified program bundle with exact runtime requirements.
4. Open Software, choose the published program, and install it. It appears in Applications and Search under its own name.
5. Close the editor and run the installed program. Its required runtime stays installed; the editor is optional.
6. Use **Download bundle** in Software, or synchronize its file from `~/Published`.
7. In another workspace, import the `.esospkg.json` file into Software and install it. Shared runtimes come from that workspace's trusted package catalog.

Publishing adds to the **local catalog**. It does not upload a program to a public service. Import validates the bundle and adds a catalog entry; it does not run the program. The recipient explicitly installs it.

Project sources, installed package state, published bundle bytes, and running program data have separate lifetimes. Publishing a changed project produces a new immutable version; an already installed version remains pinned until an explicit update. Removing a package retains source files, bundles, and program data. Busy packages and packages required by another installation cannot be removed underneath their consumers.

Files includes **Open program / bundle** and **Edit project** actions for saved documents. Search opens project documents with their runtime and bundle documents in Software. The terminal also provides:

```text
project new form ~/my-form.esos.json "Task desk"
project inspect ~/my-form.esos.json
project run ~/my-form.esos.json
project publish ~/my-form.esos.json
software list
software inspect applications.workbench
software plan applications.cards
```

Install the appropriate runtime or editor before running a project. Published program IDs and application IDs are returned in publication receipts and shown in Software.

## Linux folder synchronization

To enable the optional conventional-directory adapter, start the same server with a dedicated folder:

```sh
ESOS_PEER_DIR=/absolute/path/to/esos-shared npm start
```

Open **Sync**, choose a browser folder (normally `~`), and select **Compare**, then **Synchronize**. The selected browser folder's visible contents map to the root of that Linux folder. The adapter binds to localhost. Other hosting arrangements can keep using downloadable portable bundles.

Sync compares SHA-256 file hashes with the last synchronized baseline. One-sided changes transfer with destination revision/hash checks. Conflicting edits stay on both sides until **Keep browser** or **Use Linux** is chosen. Removal on one side is reported as a conflict; deletion is never propagated automatically.

```text
sync status
sync compare
sync run
sync resolve notes/example.txt local
sync resolve notes/example.txt remote
```

The Linux directory contains ordinary UTF-8 files. It can participate in an existing rsync or backup workflow. This adapter transfers complete changed files; rsync block deltas, network pairing, remote credentials, and binary asset synchronization are not implemented here. Coordinate writes from independent host tools while synchronizing; those tools do not participate in the adapter's serialized writes.

Hidden configuration and local state are excluded. Program bundles remain portable files: after receiving one, use **Add to Software** in Sync or Software, then install it.

## Desktop and existing applications

Up to **12 windows, including Terminal**, remain mounted. Minimize, focus, move, snap, and maximize retain controls and drafts. Normal windows may extend beyond the left, right, or bottom edge while their caption remains reachable.

| Action | Interaction |
| --- | --- |
| Move / resize | Drag the caption / bottom-right corner. |
| Keyboard geometry | Focus the caption; arrows move, Shift+arrows resize. |
| Maximize / restore | Titlebar control or double-click the caption. |
| Recover | Taskbar entry, Home on caption/taskbar, or `windows recover ID`. |
| Snap / arrange | Titlebar snap controls, Tile, or Cascade. |
| Hide / reveal chrome | Project presentation settings or `windows chrome ID off` / `on`. |
| Search | Search button or Ctrl+K. Applications, commands, and filenames are indexed. |

Tasks, Files, Journal, and System remain core applications. Tasks shares committed state with commands and other windows. Files keeps independent editor drafts and uses revision-checked saves. Journal exposes accepted events. System reports capabilities and installed groups. Commands selected in Search are prepared in Terminal for inspection before execution.

The terminal supports quoting and pipes, with one JSON object per line and a separate diagnostic channel:

```text
mkdir notes
write notes/hello.txt "A local note."
cat notes/hello.txt | write notes/copy.txt
tasks list | where done false | select id title
clipboard copy --workspace "Text for another document"
clipboard read --workspace | write notes/pasted.txt
```

There is no JavaScript evaluation, host shell, expansion, globbing, or command substitution. Clipboard copy receipts identify system access or the workspace fallback. Failed native reads preserve drafts; Paste workspace copy is an explicit separate action.

## OS interfaces

```js
const os = globalThis.esos.v1;
await os.views.open("software");
await os.commands.invoke("tasks", ["list"], {
  onRecord: record => console.log(record),
  onDiagnostic: diagnostic => console.error(diagnostic)
});
const source = await os.projects.load("~/my-form.esos.json");
const publication = await os.software.publish({ project: source.project, sourcePath: source.path });
await os.software.install(publication.id);
await os.views.open(publication.application);
```

The facade exposes `vfs`, `devices`, `desktop`, `views`, `commands`, `projects`, `software`, `state`, `sync`, `tasks`, `journal`, `search`, `clipboard`, and `system`.

Relevant filesystem interfaces include:

```text
/dev/view/new
/dev/view/ID/ctl
/dev/view/ID/events
/dev/clipboard/text
/dev/clipboard/workspace
/proc/self/status.json
/sys/capabilities.json
/sys/groups.json
/sys/software.json
~/Published/PACKAGE_ID/DIGEST.esospkg.json
~/.local/share/software/installed.json
~/.local/share/programs/PROJECT_NAMESPACE/state.json
~/.config/desktop/session.json
~/.config/sync/PEER_AND_ROOT_HASH.json
```

DOM writes use `create`, `set`, `place`, and `remove` batches. Components compile to the same device protocol used by commands. Native intentions call the owning service; committed state, accepted events, projections, and operation receipts are stored together. A DOM acknowledgement is separate from a storage commit.

Portable projects are validated data. Their behavior comes from installed JavaScript commands and runtimes. Executable packages are curated same-origin modules with page authority; this is not an isolation boundary for arbitrary uploaded JavaScript.

## Extend the package catalog

Create a directory under `packages/` with a schema-1 `package.json`, package-relative ESM files, optional scoped CSS, and exact dependencies. Declare application builders and command exports in the manifest. Builders receive the OS facade, components, helpers, and frame factory from the host; package modules do not import core implementation paths.

Run:

```sh
npm run prepare-offline
```

This regenerates `catalog/software.json`, checks package imports/dependencies, hashes package assets, and regenerates the core offline manifest and standalone `service-worker.mjs`. Edit `tools/service-worker-runtime.js` to change worker behavior; protocol and package-path declarations are included from their shared source modules. Optional executable files remain outside the core precache. The delivered manifests and worker are already generated. Use the supplied packages as the concrete integration examples.

## Upgrades and bounds

Serve this complete release at the **same origin** as your previous eSOS release without clearing browser data. The volume format remains version 1. Save work, replace the server's application files with this complete directory, and restart `npm start` at the same scheme, hostname, and port. Reload normally to discover the update. When Offline reports that the update is ready, close all eSOS tabs so its waiting worker can activate, then reopen the same address. The terminal footer should show **0.3.1**. Existing files, task history, installed programs, and saved desktop documents remain in the same browser storage.

The old worker must finish installing the update before its tabs close. The 0.3.1 loader can recover control from its active worker; an older worker that lacks the readiness protocol requires the one-time update above. The system never forces a waiting worker to activate underneath open applications. A failed update can continue using an already installed compatible worker. Do not use Clear site data or delete the OPFS volume to resolve a worker startup failure.

SQLite WASM **3.54.1** is pinned locally, as is Bootstrap **6.0.0-alpha.1**. Only one tab may own a volume. Clearing site data removes that origin's volume and package caches. `export` downloads a logical workspace snapshot; full-volume import remains unimplemented. Program-bundle import is implemented.

Current bounds include 1 MiB UTF-8 files, 512 KiB project documents, 768 KiB portable program bundles, 256 components per project, 32 cards, 32 fields per visible form/card plus background, 24 workflow actions, 12 pipeline stages, and 12 desktop windows. The Files text editor supports 65,536 characters; authoring editors read project documents directly within the larger project limit. Sync supports 1,000 files and 2,000 visible entries per selected folder.

Protected profiles, untrusted-code isolation, binary volumes, distributed multiwriter state, and WebLLM model/device management remain future groups. This release supplies the file, package, command, state, and authoring contracts those groups can build on.

Read [Software](docs/software.xml), [projects](docs/projects.xml), [Automate](docs/automate.xml), [authoring](docs/authoring.xml), [sync](docs/sync.xml), [storage](docs/storage.xml), [DOM devices](docs/dom-device.xml), [commands](docs/commands.xml), and [windows](docs/windows.xml) for the detailed contracts.
