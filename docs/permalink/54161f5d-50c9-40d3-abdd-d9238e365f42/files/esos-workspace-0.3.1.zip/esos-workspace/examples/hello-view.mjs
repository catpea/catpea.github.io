// To install this trusted example, import it and add it to src/commands/index.mjs.
// Then: hello-view "Hello, world" | dom "Greeting"
export const name = 'hello-view';
export const summary = 'Produce a small native view as ordinary command data.';
export const usage = 'hello-view [message]';

export async function run(ctx) {
  ctx.signal.throwIfAborted();
  await ctx.stdout.write({
    op: 'batch', id: crypto.randomUUID(), base: 0,
    ops: [
      { op: 'create', id: 'greeting', tag: 'h2', text: ctx.args.join(' ') || 'Hello from a small command' },
      { op: 'place', id: 'greeting', parent: 'root' }
    ]
  });
}
