import { constants } from 'node:fs';
import { mkdir, realpath, lstat, readdir, readFile, open, rename, unlink } from 'node:fs/promises';
import { resolve, join, basename, sep } from 'node:path';
import { createHash, randomUUID } from 'node:crypto';

const LIMIT = 1024 * 1024, MAX_FILES = 2000;
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const failure = (status, message) => Object.assign(new Error(message), { status });
function relativePath(value) {
  if (typeof value !== 'string' || !value || value.length > 4096 || /[\\\u0000-\u001f\u007f]/.test(value)) {
    throw failure(400, 'A bounded relative file path is required.');
  }
  const parts = value.split('/');
  if (parts.length > 64 || parts.some(part => !part || part.startsWith('.') || part.length > 255)) {
    throw failure(400, 'Use visible files within the shared directory; dot paths are excluded.');
  }
  return parts;
}

/** Optional localhost bridge. The browser remains the workspace's storage owner. */
export async function createLinuxPeer({ directory, host = '127.0.0.1' } = {}) {
  if (directory && !['127.0.0.1', 'localhost', '::1'].includes(host)) {
    throw new Error('The optional Linux folder bridge must bind to localhost.');
  }
  let root, identity;
  let writes = Promise.resolve();
  if (directory) {
    root = resolve(directory);
    if (root === sep) throw new Error('Choose a dedicated shared folder.');
    await mkdir(root, { recursive: true, mode: 0o700 });
    root = await realpath(root);
    const identityPath = join(root, '.esos-peer.json');
    try {
      const stat = await lstat(identityPath);
      if (stat.isSymbolicLink() || !stat.isFile()) throw new Error('The peer identity must be an ordinary file.');
      identity = JSON.parse(await readFile(identityPath, 'utf8'));
      if (identity.format !== 'esos.peer/1' || typeof identity.id !== 'string') throw new Error('Invalid peer identity.');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      identity = { format: 'esos.peer/1', id: randomUUID() };
      const handle = await open(identityPath, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY, 0o600);
      try { await handle.writeFile(JSON.stringify(identity) + '\n'); await handle.sync(); } finally { await handle.close(); }
    }
  }
  const status = () => ({ format: 'esos.peer/1', enabled: Boolean(root),
    ...(root ? { id: identity.id, label: basename(root) } : {}),
    fileByteLimit: LIMIT, fileLimit: MAX_FILES, deletion: 'explicit-only', encoding: 'UTF-8' });

  async function locate(value, { createParents = false } = {}) {
    const parts = relativePath(value);
    let current = root;
    for (const part of parts.slice(0, -1)) {
      current = join(current, part);
      if (createParents) await mkdir(current, { mode: 0o700 }).catch(error => { if (error.code !== 'EEXIST') throw error; });
      const stat = await lstat(current);
      if (stat.isSymbolicLink() || !stat.isDirectory()) throw failure(409, 'A path component is not an ordinary directory.');
      const canonical = await realpath(current);
      if (!canonical.startsWith(root + sep)) throw failure(403, 'The path leaves the shared directory.');
    }
    return join(current, parts.at(-1));
  }
  async function read(path) {
    const file = await locate(path);
    const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const stat = await handle.stat();
      if (!stat.isFile() || stat.size > LIMIT) throw failure(413, 'Only UTF-8 files up to 1 MiB can be synchronized.');
      const bytes = await handle.readFile();
      if (bytes.byteLength > LIMIT) throw failure(413, 'The file grew beyond 1 MiB.');
      const text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
      return { path, hash: hash(bytes), bytes: bytes.byteLength, text };
    } finally { await handle.close(); }
  }
  async function currentHash(path) {
    try { return (await read(path)).hash; }
    catch (error) { if (error.code === 'ENOENT') return null; throw error; }
  }
  async function manifest() {
    const files = [], skipped = [];
    let visited = 0;
    async function walk(directory, prefix = '', depth = 0) {
      if (depth > 64) throw failure(413, 'The shared directory exceeds the depth limit.');
      for (const entry of (await readdir(directory, { withFileTypes: true })).sort((a,b) => a.name.localeCompare(b.name))) {
        if (entry.name.startsWith('.')) continue;
        if (++visited > MAX_FILES) throw failure(413, 'The shared directory exceeds 2,000 visible entries.');
        const path = prefix + entry.name;
        relativePath(path);
        if (entry.isSymbolicLink()) { skipped.push({ path, reason: 'symbolic-link' }); continue; }
        if (entry.isDirectory()) await walk(join(directory, entry.name), path + '/', depth + 1);
        else if (entry.isFile()) {
          try { const { text, ...record } = await read(path); files.push(record); }
          catch (error) { skipped.push({ path, reason: error.message }); }
        }
      }
    }
    await walk(root);
    return { ...status(), files, skipped };
  }
  async function body(req) {
    let size = 0; const chunks = [];
    for await (const chunk of req) {
      size += chunk.length;
      if (size > 7 * LIMIT) throw failure(413, 'The request exceeds the file limit.');
      chunks.push(chunk);
    }
    try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
    catch { throw failure(400, 'Expected a JSON request.'); }
  }
  async function write(path, data) {
    if (!data || typeof data.text !== 'string' ||
        !(data.expectedHash === null || /^[a-f0-9]{64}$/.test(data.expectedHash))) {
      throw failure(400, 'A write requires text and the previously observed hash (null for a new file).');
    }
    const bytes = Buffer.from(data.text, 'utf8');
    if (bytes.length > LIMIT) throw failure(413, 'The file exceeds 1 MiB.');
    const destination = await locate(path, { createParents: true });
    const temporary = join(resolve(destination, '..'), '.esos-write-' + randomUUID());
    const handle = await open(temporary, constants.O_CREAT | constants.O_EXCL | constants.O_WRONLY | constants.O_NOFOLLOW, 0o600);
    try {
      await handle.writeFile(bytes); await handle.sync(); await handle.close();
      // Serialize bridge writers and recheck immediately before atomic replacement.
      if (await currentHash(path) !== data.expectedHash) throw failure(409, 'The Linux file changed; compare it again before writing.');
      await rename(temporary, destination);
      return { path, hash: hash(bytes), bytes: bytes.length, written: true };
    } finally { await handle.close().catch(() => {}); await unlink(temporary).catch(() => {}); }
  }

  return async function handle(req, res, url) {
    if (!url.pathname.startsWith('/__peer/')) return false;
    const send = (code, value) => {
      res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
        'X-Content-Type-Options': 'nosniff', 'Cross-Origin-Resource-Policy': 'same-origin' });
      res.end(JSON.stringify(value));
    };
    try {
      const requestHost = new URL('http://' + req.headers.host);
      if (!['localhost', '127.0.0.1', '[::1]'].includes(requestHost.hostname) ||
          (req.headers.origin && req.headers.origin !== requestHost.origin) ||
          (req.headers['sec-fetch-site'] && !['same-origin', 'none'].includes(req.headers['sec-fetch-site']))) {
        throw failure(403, 'The folder bridge accepts same-origin localhost requests.');
      }
      if (url.pathname === '/__peer/status' && req.method === 'GET') { send(200, status()); return true; }
      if (!root) throw failure(503, 'Start the server with ESOS_PEER_DIR pointing to a dedicated shared folder.');
      if (url.pathname === '/__peer/manifest' && req.method === 'GET') { send(200, await manifest()); return true; }
      if (url.pathname !== '/__peer/file') throw failure(404, 'Unknown folder operation.');
      const path = url.searchParams.get('path'); relativePath(path);
      if (req.method === 'GET') send(200, await read(path));
      else if (req.method === 'PUT' && req.headers['x-esos-peer'] === '1' && req.headers['content-type']?.startsWith('application/json')) {
        const data = await body(req);
        const task = writes.then(() => write(path, data)); writes = task.catch(() => {});
        send(200, await task);
      } else throw failure(405, 'Use GET or an explicit JSON PUT; deletion is not automatic.');
    } catch (error) {
      send(error.status ?? (error.code === 'ENOENT' ? 404 : 400), { error: error.message });
    }
    return true;
  };
}
