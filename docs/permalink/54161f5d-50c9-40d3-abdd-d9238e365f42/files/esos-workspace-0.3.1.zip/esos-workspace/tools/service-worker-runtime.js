// Included by prepare-offline.mjs after the generated manifest and shared sources.
// Keep this runtime a classic script so the worker does not require module support.
// Installation completes only when this exact release is cached in full.
// A waiting release activates after the current workspace has been closed.
const scope = new URL('./', self.location.href);
const prefix = 'esos-workspace:' + scope.pathname + ':';
const cacheName = prefix + BUILD;
const urls = new Set(ASSETS.map(asset => new URL(asset.path, scope).href));
const hex = bytes => Array.from(new Uint8Array(bytes), value => value.toString(16).padStart(2, '0')).join('');

function workspaceClient(client) {
  if (!client || client.type !== 'window') return false;
  try {
    const url = new URL(client.url);
    return url.origin === scope.origin && url.pathname.startsWith(scope.pathname);
  } catch { return false; }
}

function describeError(error) {
  const message = error?.message ?? String(error ?? 'Unknown error');
  return error?.name && error.name !== 'Error' ? error.name + ': ' + message : message;
}

function offlineError(code, message, cause) {
  const error = new Error(message);
  error.code = code;
  if (cause !== undefined) error.cause = cause;
  return error;
}

async function broadcastInstall(details) {
  // Diagnostics must not change whether a release can install. A window can
  // disappear between enumeration and postMessage, or there may be no windows.
  try {
    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const message = { type: OFFLINE_MESSAGE, protocol: OFFLINE_PROTOCOL, build: BUILD, ...details };
    for (const client of clients) {
      if (!workspaceClient(client)) continue;
      try { client.postMessage(message); } catch { /* The window has closed. */ }
    }
  } catch { /* Installation does not require a diagnostics listener. */ }
}

self.addEventListener('message', event => {
  const port = event.ports?.[0];
  if (event.data?.type !== OFFLINE_MESSAGE || !port) return;
  event.waitUntil((async () => {
    const reply = details => port.postMessage({
      type: OFFLINE_MESSAGE, protocol: OFFLINE_PROTOCOL, build: BUILD,
      scope: scope.href, packageRoute: PACKAGE_ROUTE, ...details,
    });
    try {
      // Resolve the browser-issued client identity rather than accepting a URL
      // or origin supplied inside the message payload.
      const client = event.source?.id ? await self.clients.get(event.source.id) : null;
      if (!workspaceClient(client)) {
        throw offlineError('E_OFFLINE_CLIENT', 'Offline readiness requires a window in this workspace.');
      }
      if (event.data.protocol !== OFFLINE_PROTOCOL || typeof event.data.claim !== 'boolean') {
        throw offlineError('E_OFFLINE_PROTOCOL', 'The page and offline worker use different readiness protocols.');
      }
      // The page sends this request to registration.active. claim() also rejects
      // when this worker is not active; it never activates a waiting update.
      if (event.data.claim) await self.clients.claim();
      reply({ ready: true });
    } catch (error) {
      reply({ ready: false, code: error.code ?? 'E_OFFLINE_CLAIM', message: describeError(error) });
    } finally {
      port.close();
    }
  })());
});

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    let completed = 0, currentPath = '', stage = 'cache';
    // A type-only module/classic update can reinstall the same BUILD while its
    // previous worker is still active. Never delete a cache we did not create.
    // If the presence check itself fails, conservatively preserve the cache.
    let cacheWasPresent = true;
    const total = ASSETS.length;
    try {
      await broadcastInstall({ event: 'install-progress', completed, total, path: currentPath });
      cacheWasPresent = await caches.has(cacheName);
      const cache = await caches.open(cacheName);
      for (const asset of ASSETS) {
        currentPath = asset.path;
        const url = new URL(asset.path, scope);
        if (cacheWasPresent) {
          stage = 'cache';
          const cached = await cache.match(url);
          if (cached?.ok) {
            stage = 'read';
            const bytes = await cached.clone().arrayBuffer();
            stage = 'hash';
            const digest = hex(await crypto.subtle.digest('SHA-256', bytes));
            if (digest === asset.sha256) {
              completed += 1;
              await broadcastInstall({ event: 'install-progress', completed, total, path: currentPath });
              continue;
            }
          }
        }
        stage = 'fetch';
        const response = await fetch(url, { cache: 'reload', credentials: 'same-origin' });
        if (!response.ok) {
          throw offlineError('E_OFFLINE_FETCH', 'Offline asset unavailable: ' + asset.path +
            ' (HTTP ' + response.status + (response.statusText ? ' ' + response.statusText : '') + ').');
        }
        stage = 'read';
        const bytes = await response.clone().arrayBuffer();
        stage = 'hash';
        const digest = hex(await crypto.subtle.digest('SHA-256', bytes));
        if (digest !== asset.sha256) {
          throw offlineError('E_OFFLINE_INTEGRITY', 'Offline asset changed: ' + asset.path +
            ' (expected SHA-256 ' + asset.sha256 + ', received ' + digest + '). Run npm run prepare-offline.');
        }
        stage = 'cache';
        await cache.put(url, response);
        completed += 1;
        await broadcastInstall({ event: 'install-progress', completed, total, path: currentPath });
      }
    } catch (cause) {
      const codes = { fetch: 'E_OFFLINE_FETCH', read: 'E_OFFLINE_FETCH', hash: 'E_OFFLINE_HASH', cache: 'E_OFFLINE_CACHE' };
      const code = cause?.name === 'QuotaExceededError' ? 'E_OFFLINE_QUOTA' : (codes[stage] ?? 'E_OFFLINE_INSTALL');
      const error = typeof cause?.code === 'string' && cause.code.startsWith('E_OFFLINE_') ? cause :
        offlineError(code, 'Offline ' + stage + ' failed' + (currentPath ? ' for ' + currentPath : '') +
          ': ' + describeError(cause), cause);
      // Preserve any same-build cache used by the active worker, including its
      // verified assets when a missing or mismatched asset cannot be repaired.
      // A cleanup failure must not hide the original installation failure.
      if (!cacheWasPresent) {
        try { await caches.delete(cacheName); } catch { /* This new partial cache belongs to an inactive release. */ }
      }
      await broadcastInstall({ event: 'install-error', completed, total, path: currentPath,
        code: error.code, message: error.message });
      throw error;
    }
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith(prefix) && name !== cacheName) await caches.delete(name);
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== scope.origin) return;
  if (url.pathname.startsWith(scope.pathname + PACKAGE_ROUTE)) {
    event.respondWith((async () => {
      const requested = parsePackageURL(url, scope);
      if (!requested || url.search || requested.path === MARKER) {
        return new Response('Invalid immutable package URL.', { status: 400 });
      }
      // This namespace is intentionally outside the core-release cache prefix.
      // Only the installer writes its marker, after checking every asset hash.
      const name = packageCache(requested, scope);
      if (!await caches.has(name)) return new Response('Package unavailable. Repair it in Software.', { status: 503 });
      const cache = await caches.open(name);
      const completion = await cache.match(packageURL(requested, MARKER, scope));
      if (!completion) return new Response('Package installation is incomplete. Repair it in Software.', { status: 503 });
      let marker;
      try { marker = await completion.json(); } catch { return new Response('Invalid package completion record.', { status: 503 }); }
      if (marker.schema !== 1 || marker.id !== requested.id || marker.version !== requested.version ||
          marker.digest !== requested.digest || !Array.isArray(marker.assets) ||
          !marker.assets.some(asset => asset.path === requested.path)) {
        return new Response('This asset is not part of the verified package.', { status: 404 });
      }
      const response = await cache.match(packageURL(requested, requested.path, scope));
      // Never replace missing verified code with a network response or another version.
      return response ?? new Response('Package asset missing. Repair it in Software.', { status: 503 });
    })());
    return;
  }
  url.search = '';
  url.hash = '';
  if (url.href === scope.href) url.pathname += 'index.html';
  if (!urls.has(url.href)) return;
  event.respondWith((async () => {
    const response = await (await caches.open(cacheName)).match(url);
    return response ?? fetch(event.request);
  })());
});
