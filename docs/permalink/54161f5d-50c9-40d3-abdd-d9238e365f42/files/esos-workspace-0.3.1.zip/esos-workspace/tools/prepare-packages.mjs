import { readdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { normalizeManifest, canonical, sha256, LIMITS } from '../src/software/schema.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const types = new Map([['.mjs', 'text/javascript'], ['.js', 'text/javascript'], ['.json', 'application/json'],
  ['.css', 'text/css'], ['.wasm', 'application/wasm'], ['.svg', 'image/svg+xml'], ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'], ['.jpeg', 'image/jpeg'], ['.woff2', 'font/woff2'], ['.xml', 'application/xml'], ['.md', 'text/plain']]);

async function packageFiles(directory, prefix = '') {
  const entries = await readdir(directory, { withFileTypes: true });
  const result = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    if (entry.name.startsWith('.')) continue;
    const relative = prefix + entry.name, absolute = path.join(directory, entry.name);
    if (entry.isDirectory()) result.push(...await packageFiles(absolute, relative + '/'));
    else if (entry.isFile()) result.push(relative);
    else throw new Error('Optional packages do not contain filesystem links: ' + relative);
  }
  return result;
}

export async function preparePackages() {
  const directories = (await readdir(path.join(root, 'packages'), { withFileTypes: true })).filter(entry => entry.isDirectory()).sort((a, b) => a.name.localeCompare(b.name));
  const packages = [], ids = new Set();
  for (const directory of directories) {
    const location = path.join(root, 'packages', directory.name);
    const source = JSON.parse(await readFile(path.join(location, 'package.json'), 'utf8'));
    const definition = normalizeManifest({ ...source, source: 'packages/' + directory.name }, { generated: false });
    if (ids.has(definition.id)) throw new Error('Duplicate package ID: ' + definition.id);
    ids.add(definition.id);
    const assets = [];
    for (const relative of await packageFiles(location)) {
      const bytes = await readFile(path.join(location, relative));
      if (bytes.byteLength > LIMITS.assetBytes) throw new Error('Package asset too large: ' + relative);
      if (/\.(mjs|js)$/.test(relative)) {
        const code = bytes.toString('utf8');
        // Build-time guard for the curated package authors. This is not a parser
        // or a sandbox; shared services are passed through the host context.
        for (const match of code.matchAll(/(?:\bfrom\s*|\bimport\s*\(?\s*)['"]([^'"]+)['"]/g)) {
          const specifier = match[1];
          if (!specifier.startsWith('./') && !specifier.startsWith('../')) throw new Error('Use a package-relative import or host service in ' + relative + ': ' + specifier);
          const target = path.posix.normalize(path.posix.join(path.posix.dirname(relative), specifier));
          if (target.startsWith('../') || target.includes('?') || target.includes('#')) throw new Error('Import escapes its immutable package: ' + relative + ' -> ' + specifier);
          await readFile(path.join(location, target));
        }
      }
      assets.push({ path: relative, bytes: bytes.byteLength, sha256: await sha256(bytes), type: types.get(path.extname(relative)) ?? 'application/octet-stream' });
    }
    const manifest = normalizeManifest({ ...definition, assets, digest: '0'.repeat(64) });
    delete manifest.digest;
    manifest.digest = await sha256(canonical(manifest));
    packages.push(manifest);
  }
  const byId = new Map(packages.map(item => [item.id, item]));
  for (const item of packages) for (const dep of item.dependencies) {
    if (byId.get(dep.id)?.version !== dep.version) throw new Error(item.id + ' requires missing exact dependency ' + dep.id + '@' + dep.version);
  }
  await writeFile(path.join(root, 'catalog/software.json'), JSON.stringify({ schema: 1, packages }, null, 2) + '\n');
  return { packages: packages.length, assets: packages.reduce((sum, item) => sum + item.assets.length, 0) };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const result = await preparePackages();
  console.log('Prepared ' + result.packages + ' optional package manifests and ' + result.assets + ' verified assets.');
}
