import http from 'node:http';
import { readFile, realpath, stat } from 'node:fs/promises';
import { dirname, extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createLinuxPeer } from './tools/linux-peer.mjs';

// Static by default. ESOS_PEER_DIR explicitly enables a localhost folder adapter;
// the browser remains the workspace owner and does not require that adapter.
const root = await realpath(dirname(fileURLToPath(import.meta.url)));
const port = Number(process.env.ESOS_PORT ?? 5173);
const host = process.env.ESOS_HOST ?? '127.0.0.1';
const peer = await createLinuxPeer({ directory: process.env.ESOS_PEER_DIR, host });
const mime = {
  '.html': 'text/html; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.wasm': 'application/wasm', '.svg': 'image/svg+xml',
  '.webmanifest': 'application/manifest+json'
};
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (await peer(req, res, url)) return;
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405, { Allow: 'GET, HEAD' }); return res.end();
    }
    const path = decodeURIComponent(url.pathname);
    const requested = resolve(root, '.' + (path.endsWith('/') ? path + 'index.html' : path));
    const file = await realpath(requested);
    if (file !== root && !file.startsWith(root + sep)) throw new Error('Outside root');
    if (!(await stat(file)).isFile()) throw new Error('Not a file');
    const body = await readFile(file);
    res.writeHead(200, {
      'Content-Type': mime[extname(file)] ?? 'application/octet-stream',
      'Content-Length': body.byteLength,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; img-src 'self' data:; worker-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    });
    res.end(req.method === 'HEAD' ? undefined : body);
  } catch {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Not found');
  }
});
server.listen(port, host, () => console.log('eSOS Workspace: http://' + host + ':' + port));
