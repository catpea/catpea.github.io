export async function buildCards(context, options = {}) {
  const authoring = await context.os.software.loadModule('authoring.shared');
  return authoring.buildEditor(context, { ...options, kind: 'cards' });
}
