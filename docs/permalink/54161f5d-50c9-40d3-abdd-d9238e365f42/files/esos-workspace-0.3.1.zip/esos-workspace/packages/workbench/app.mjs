export async function buildWorkbench(context, options = {}) {
  const authoring = await context.os.software.loadModule('authoring.shared');
  return authoring.buildEditor(context, { ...options, kind: 'form' });
}
