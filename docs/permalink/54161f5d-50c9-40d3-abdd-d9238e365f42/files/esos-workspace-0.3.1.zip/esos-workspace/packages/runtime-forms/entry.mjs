/** Shared form/card renderer. All presentation writes use its owned DOM device. */
export function createRenderer({ app, os, components, projects = os.projects, project,
  parent = 'project-stage', prefix = 'program', mode = 'run', selected = null, card = null,
  values: initialValues = {}, onChange = () => {}, onStatus = () => {} }) {
  const { element: el, text, button, compileTree } = components;
  let document = projects.validate(project), activeCard = card;
  let currentMode = mode, selection = selected, mounted = false, disposed = false, busy = false, locked = false, composing = false;
  let running = null, actionTask = null, outputText = new Map(), values = new Map();
  const lifetime = new AbortController();
  const surfaceId = prefix + '-surface';
  const nodeId = id => prefix + '-' + id;
  const allFields = () => projects.walkNodes(document).map(item => item.node).filter(node => ['field', 'textarea'].includes(node.type));
  const visibleSurface = () => app.container.querySelector('[data-project-surface="' + prefix + '"]');
  function normalizeValues(source = {}) {
    const next = new Map();
    for (const field of allFields()) next.set(field.id, typeof source[field.id] === 'string' && source[field.id].length <= 16384 ? source[field.id] : field.value);
    return next;
  }
  values = normalizeValues(initialValues);
  function currentCard() {
    if (document.kind !== 'cards') return null;
    return document.stack.cards.find(card => card.id === activeCard) ?? document.stack.cards.find(card => card.id === document.stack.startCard) ?? document.stack.cards[0];
  }
  activeCard = currentCard()?.id ?? null;
  function capture() {
    if (currentMode !== 'run') return;
    for (const control of visibleSurface()?.querySelectorAll('[data-project-field]') ?? []) {
      if (values.has(control.dataset.projectField)) values.set(control.dataset.projectField, control.value.slice(0, 16384));
    }
  }
  function snapshot({ bounded = false } = {}) {
    capture();
    const state = { schema: 1, values: Object.fromEntries(values), card: activeCard };
    if (bounded && new TextEncoder().encode(JSON.stringify(state)).byteLength > 512 * 1024) throw new Error('Program data is limited to 512 KiB. Reduce field text before saving.');
    return state;
  }
  function interpolate(value, fields) {
    return value.replace(/\{\{([A-Za-z][A-Za-z0-9_-]{0,63})\}\}/g, (_, id) => fields[id] ?? '');
  }
  function renderNode(node) {
    const id = nodeId(node.id), design = currentMode === 'design';
    const className = 'project-node project-node-' + node.type + (design ? ' project-design-node' : '') +
      (design && selection === node.id ? ' is-selected' : '');
    const wrapper = { class: className, attrs: { 'data-project-node': node.id },
      ...(design ? { on: { click: 'editor.select', contextmenu: 'editor.context' }, data: { node: node.id },
        props: { tabIndex: 0 } } : {}) };
    const children = [];
    if (node.type === 'section' || node.type === 'split') {
      wrapper.class += node.type === 'split' ? ' project-split project-split-' + node.direction + ' project-ratio-' + node.ratio + ' project-collapse-' + node.collapse : ' project-region';
      wrapper.attrs['aria-label'] = node.label;
      if (design) children.push(text('span', id + '-region-label', node.label, 'project-region-label'));
      children.push(...node.children.map(renderNode));
      if (!node.children.length) children.push(text('p', id + '-empty', design ? 'Select this region, then choose a component.' : '', 'project-empty-region'));
    } else if (node.type === 'field' || node.type === 'textarea') {
      children.push(el('label', id + '-label', { text: node.label, attrs: { for: id + '-control' } }));
      children.push(el(node.type === 'textarea' ? 'textarea' : 'input', id + '-control', {
        class: 'form-control', attrs: { ...(node.type === 'field' ? { type: node.inputType } : { rows: '5' }),
          name: node.id, placeholder: node.placeholder, maxlength: '16384', 'data-project-field': node.id,
          ...(node.required ? { required: '' } : {}) },
        props: { value: values.get(node.id) ?? node.value, readOnly: design || locked, tabIndex: design ? -1 : 0 }
      }));
    } else if (node.type === 'button') {
      children.push(el('button', id + '-control', { text: node.text, class: 'btn-solid theme-' + node.tone,
        attrs: { type: 'button', 'data-project-action': node.id }, props: { disabled: busy || design || locked, tabIndex: design ? -1 : 0 },
        ...(!design ? { on: { click: 'project.action' }, data: { node: node.id } } : {}) }));
    } else if (node.type === 'image') {
      children.push(node.src ? el('img', id + '-picture', { class: 'project-picture project-picture-' + node.fit,
        attrs: { src: node.src, alt: node.alt, loading: 'lazy' } })
        : text('p', id + '-picture', design ? 'Choose a picture in Properties.' : node.alt, 'project-picture-placeholder'));
    } else if (node.type === 'output') {
      children.push(text('pre', id + '-result', outputText.get(node.id) ?? node.text, 'project-result'));
    } else children.push(text(node.type === 'heading' ? 'h2' : 'p', id + '-text', node.text, 'project-content-' + node.type));
    return el('section', id, wrapper, children);
  }
  async function render(options = {}) {
    if (disposed || app.disposed) return;
    if (options.capture !== false) capture();
    if (options.project) {
      document = projects.validate(options.project);
      values = normalizeValues(currentMode === 'design' ? {} : Object.fromEntries(values));
    }
    if (options.mode) currentMode = options.mode;
    if (Object.hasOwn(options, 'selected')) selection = options.selected;
    if (Object.hasOwn(options, 'card')) activeCard = options.card;
    activeCard = currentCard()?.id ?? null;
    let nodes;
    if (document.kind === 'cards') nodes = options.backgroundOnly ? [document.stack.background]
      : [document.stack.background, currentCard().root];
    else nodes = [document.form.root];
    const tree = el('div', surfaceId, { class: 'project-surface project-surface-' + currentMode,
      attrs: { 'data-project-surface': prefix } }, nodes.map(renderNode));
    const ops = [...(mounted ? [{ op: 'remove', id: surfaceId }] : []), ...compileTree(tree, parent)];
    await app.ui.send(ops); mounted = true;
  }
  async function showResult(target, value) {
    if (value.length > 65536) throw new Error('The displayed result exceeds 65,536 characters. Use a file or workflow for this larger output.');
    const output = target ?? projects.walkNodes(document).find(item => item.node.type === 'output')?.node.id;
    if (!output) { await onStatus(value); return; }
    outputText.set(output, value);
    const existing = visibleSurface()?.querySelector('[data-project-node="' + output + '"]');
    if (existing) await app.ui.set(nodeId(output) + '-result', { text: value });
  }
  async function setBusy(value) {
    busy = value;
    if (!mounted || disposed || app.disposed) return;
    const ids = Array.from(visibleSurface()?.querySelectorAll('[data-project-action]') ?? [], control => control.dataset.projectAction);
    if (ids.length) await app.ui.send(ids.map(id => ({ op: 'set', id: nodeId(id) + '-control', props: { disabled: value || locked } })));
  }
  async function setLocked(value) {
    if (value && composing) throw new Error('Finish composing text before reloading or closing the program.');
    locked = value;
    const controls = Array.from(visibleSurface()?.querySelectorAll('[data-project-field]') ?? []);
    const ops = controls.map(control => ({ op: 'set', id: nodeId(control.dataset.projectField) + '-control', props: { readOnly: value || currentMode === 'design' } }));
    for (const control of visibleSurface()?.querySelectorAll('[data-project-action]') ?? []) ops.push({ op: 'set', id: nodeId(control.dataset.projectAction) + '-control', props: { disabled: value || busy || currentMode === 'design' } });
    if (ops.length) await app.ui.send(ops);
    if (value && composing) throw new Error('Finish composing text before reloading or closing the program.');
  }
  async function navigate(target) {
    if (document.kind !== 'cards') return;
    capture();
    const cards = document.stack.cards, index = cards.findIndex(card => card.id === activeCard);
    const next = target === 'next' ? cards[(index + 1) % cards.length] : target === 'previous' ? cards[(index - 1 + cards.length) % cards.length]
      : target === 'first' ? cards[0] : target === 'last' ? cards.at(-1) : cards.find(card => card.id === target);
    if (!next) throw new Error('That card is no longer available.');
    activeCard = next.id; await render(); onChange(snapshot());
    await onStatus(next.name + ' · card ' + (cards.indexOf(next) + 1) + ' of ' + cards.length);
  }
  async function executeIntent(value) {
    if (disposed || currentMode !== 'run' || value.action !== 'project.action') return false;
    if (locked) throw new Error('Wait for the current data operation.');
    if (busy) throw new Error('Wait for the current action, or stop it first.');
    const node = projects.findNode(document, value.data?.node);
    if (node?.type !== 'button' || !node.action) { await onStatus('This button has no action yet.'); return true; }
    const fields = snapshot().values, action = node.action;
    if (action.kind === 'navigate') { await navigate(action.card); return true; }
    if (action.kind === 'message') { await showResult(action.output, interpolate(action.text, fields)); return true; }
    if (action.kind === 'set-field') {
      const next = interpolate(action.value, fields);
      if (next.length > 16384) throw new Error('The result is too long for a field.');
      values.set(action.field, next);
      const control = visibleSurface()?.querySelector('[data-project-field="' + action.field + '"]');
      if (control) await app.ui.set(nodeId(action.field) + '-control', { props: { value: next }, ifValue: control.value });
      onChange(snapshot()); return true;
    }
    for (const control of visibleSurface()?.querySelectorAll('[data-project-field]') ?? []) {
      if (!control.checkValidity()) { control.reportValidity(); return true; }
    }
    running = new AbortController();
    const abort = () => running?.abort(lifetime.signal.reason);
    lifetime.signal.addEventListener('abort', abort, { once: true });
    let result = '', records = 0;
    try {
      await setBusy(true);
      await onStatus('Running ' + action.command + '…');
      const receipt = await os.commands.invoke(action.command, action.args.map(arg => interpolate(arg, fields)), {
        stdin: action.input ?? [], signal: running.signal,
        async onRecord(record) {
          const line = JSON.stringify(record) + '\n';
          if (++records > 200 || result.length + line.length > 65536) throw new Error('This result exceeds the 200-record / 65,536-character display limit. Use a workflow to process larger streams.');
          result += line;
        },
        async onDiagnostic(record) { await onStatus(typeof record?.message === 'string' ? record.message : JSON.stringify(record)); }
      });
      if (disposed || app.disposed) return true;
      if (result) await showResult(action.output, result.trimEnd());
      if (receipt.exitCode !== 0) throw new Error(receipt.status === 'cancelled' ? 'Command stopped. Already committed changes are retained.' : receipt.error?.message ?? 'The command did not complete. Already committed changes are retained.');
      await onStatus(action.command + ' completed · ' + records + ' result' + (records === 1 ? '' : 's') + '.');
    } finally {
      lifetime.signal.removeEventListener('abort', abort);
      running = null; await setBusy(false);
    }
    return true;
  }
  function intent(value) {
    if (value.action !== 'project.action') return false;
    const node = projects.findNode(document, value.data?.node);
    if (node?.action?.kind !== 'command') return executeIntent(value);
    if (actionTask || busy) throw new Error('Wait for the current action, or stop it first.');
    // Release the DOM intent queue so Stop and other window actions can dispatch.
    const task = executeIntent(value).catch(async error => {
      if (!disposed && !app.disposed) { try { await onStatus(error?.message ?? String(error), true); } catch { /* Closed view. */ } }
    }).finally(() => { if (actionTask === task) actionTask = null; });
    actionTask = task;
    return true;
  }
  app.container.addEventListener('input', event => {
    if (currentMode !== 'run' || !event.target?.matches?.('[data-project-field]') || !visibleSurface()?.contains(event.target)) return;
    values.set(event.target.dataset.projectField, event.target.value.slice(0, 16384));
    try { onChange(snapshot()); } catch (error) { void onStatus(error.message, true); }
  }, { signal: lifetime.signal });
  app.container.addEventListener('compositionstart', event => { if (visibleSurface()?.contains(event.target)) composing = true; }, { signal: lifetime.signal });
  app.container.addEventListener('compositionend', () => { composing = false; }, { signal: lifetime.signal });
  return Object.freeze({
    render, intent, snapshot, navigate, setLocked,
    get project() { return projects.validate(document); },
    get card() { return activeCard; },
    get busy() { return busy; },
    async loadState(state) {
      if (!state || state.schema !== 1 || !state.values || typeof state.values !== 'object' || Array.isArray(state.values)) throw new Error('This program data has an unsupported format.');
      values = normalizeValues(state.values); activeCard = state.card; activeCard = currentCard()?.id ?? null;
      await render({ capture: false });
    },
    stop() { running?.abort(new DOMException('Stopped by user', 'AbortError')); },
    whenIdle() { return actionTask ?? Promise.resolve(); },
    async stopAndWait() { running?.abort(new DOMException('Window closed', 'AbortError')); await actionTask; },
    dispose() { if (disposed) return; disposed = true; lifetime.abort(); running?.abort(); }
  });
}

export async function buildProject(ctx, options = {}) {
  const { os, frame, components, projects = os.projects, helpers } = ctx;
  const { element: el, text, button } = components;
  const loaded = options.path ? await projects.load(options.path) : null;
  const project = projects.validate(options.project ?? loaded?.project);
  if (!['form', 'cards'].includes(project.kind)) throw new Error('This runtime opens forms and card stacks.');
  const stateApp = 'project.' + project.id;
  const stored = await os.state.read(stateApp);
  if (stored.state && (stored.state.schema !== 1 || !stored.state.values || typeof stored.state.values !== 'object' || Array.isArray(stored.state.values))) throw new Error('This program data has an unsupported format. Its saved state was kept.');
  let stateRevision = stored.revision ?? 0, savedState, renderer, app;
  let saving = false, replacing = false, closing = false, saveTask = null;
  const lifetime = new AbortController();
  const sameState = () => !renderer || JSON.stringify(renderer.snapshot()) === savedState;
  function dirty() { if (!app.disposed) app.setDirty(!sameState()); }
  async function performSave(operationId) {
    if (saving || replacing || closing) throw new Error('Wait for the current data operation to finish.');
    const state = renderer.snapshot({ bounded: true });
    saving = true;
    try {
      const receipt = await os.state.commit({ app: stateApp, expectedRevision: stateRevision, state,
        events: [{ type: 'project.data.saved', data: { project: project.id, fields: Object.keys(state.values), card: state.card } }], operationId });
      if (app.disposed) return;
      stateRevision = receipt.revision; savedState = JSON.stringify(state); dirty();
      await app.say('Data saved locally · revision ' + stateRevision + (app.dirty ? '. Newer typing is still unsaved.' : '.'));
    } finally { saving = false; }
  }
  function saveData(operationId) {
    if (saveTask) return Promise.reject(new Error('This program is already saving its data.'));
    const task = performSave(operationId);
    saveTask = task;
    task.then(() => { if (saveTask === task) saveTask = null; }, () => { if (saveTask === task) saveTask = null; });
    return task;
  }
  app = frame('project', project.name, async intent => {
    try {
      if (closing) return;
      if (intent.action === 'project.save-data') await saveData(intent.eventId);
      else if (intent.action === 'project.reload-data') {
        if (saving || replacing || renderer.busy) throw new Error('Finish the current operation before reloading data.');
        if (!sameState() && !window.confirm('Discard unsaved field values and reload the saved program data?')) return;
        replacing = true;
        try {
          const before = JSON.stringify(renderer.snapshot());
          await renderer.setLocked(true);
          if (JSON.stringify(renderer.snapshot()) !== before) throw new Error('Fields changed while preparing to reload. Your data was kept.');
          const next = await os.state.read(stateApp);
          if (app.disposed) return;
          if (JSON.stringify(renderer.snapshot()) !== before) throw new Error('Fields changed while loading. Your current data was kept.');
          await renderer.loadState(next.state ?? { schema: 1, values: {}, card: null });
          stateRevision = next.revision ?? 0; savedState = JSON.stringify(renderer.snapshot()); dirty();
          await app.say('Loaded saved data · revision ' + stateRevision + '.');
        } finally { replacing = false; if (!app.disposed) await renderer.setLocked(false); }
      } else if (intent.action === 'project.previous') await renderer.navigate('previous');
      else if (intent.action === 'project.next') await renderer.navigate('next');
      else if (intent.action === 'project.stop') { renderer.stop(); await app.say('Stopping the current command.'); }
      else await renderer.intent(intent);
    } catch (error) { if (!app.disposed) await app.say(helpers?.formatError?.(error) ?? error.message, true); }
  });
  app.appMode = true;
  app.chrome = project.presentation.chrome;
  app.preferredMode = project.presentation.maximized ? 'maximized' : 'normal';
  app.container.classList.add('container-fluid', 'project-application');
  app.resourcePath = () => loaded?.path ?? options.sourcePath ?? null;
  app.sessionOptions = () => options.path ? { path: options.path } : {};
  app.beforeClose = async () => {
    closing = true;
    try {
      await renderer.setLocked(true);
      await saveTask;
      if (!sameState() && !window.confirm('Close ' + project.name + ' and discard its unsaved field values?')) {
        closing = false; await renderer.setLocked(false); return false;
      }
      await renderer.stopAndWait(); return true;
    } catch (error) {
      closing = false; await renderer.setLocked(false); await app.say(error.message, true); return false;
    }
  };
  await app.ui.tree(el('main', 'project-shell', { class: 'project-shell' }, [
    el('header', 'project-toolbar', { class: 'project-toolbar' }, [
      text('span', 'project-name', project.name, 'project-name'),
      el('div', 'project-data-actions', { class: 'app-actions' }, [
        button('project-save', 'Save data', 'project.save-data', {}, 'btn-solid theme-primary btn-sm'),
        button('project-reload', 'Reload data', 'project.reload-data'),
        ...(project.kind === 'cards' ? [button('project-previous', 'Previous', 'project.previous'), button('project-next', 'Next', 'project.next')] : []),
        button('project-stop', 'Stop', 'project.stop')
      ])
    ]),
    el('div', 'project-stage', { class: 'project-stage' }),
    el('p', 'message', { class: 'inline-message project-status', attrs: { role: 'status', 'aria-live': 'polite' } })
  ]));
  renderer = createRenderer({ app, os, components, projects, project, values: stored.state?.values ?? {}, card: stored.state?.card,
    onChange: dirty, onStatus: (message, failure) => app.say(message, failure) });
  await renderer.render();
  savedState = JSON.stringify(renderer.snapshot());
  app.cleanup.push(() => { lifetime.abort(); renderer.dispose(); });
  window.addEventListener('beforeunload', event => { if (!sameState()) { event.preventDefault(); event.returnValue = ''; } }, { signal: lifetime.signal });
  app.container.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') {
      event.preventDefault(); void saveData(crypto.randomUUID()).catch(error => app.say(error.message, true));
    }
  }, { signal: lifetime.signal });
  await app.say(project.kind === 'cards' ? 'Your stack is ready. Save data to retain field values and the current card.' : 'Your application is ready. Save data to retain field values.');
  return app;
}
