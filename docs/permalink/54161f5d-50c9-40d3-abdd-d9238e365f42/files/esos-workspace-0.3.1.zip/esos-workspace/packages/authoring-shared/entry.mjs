// Optional editor UI shared by Workbench and Cards. The installed runtime is independent.
export async function buildEditor(ctx, options = {}) {
  const { frame, os, components: C, helpers, projects = os.projects } = ctx;
  const { element: el, text, button, submitButton, form, field } = C;
  const kind = options.kind;
  if (!['form', 'cards'].includes(kind)) throw new Error('Choose Workbench or Cards.');
  const name = kind === 'cards' ? 'Cards' : 'Workbench';
  const application = kind === 'cards' ? 'cards' : 'workbench';
  const runtime = await os.software.loadModule('runtime.forms');
  const draft = await projects.createDraft({ kind, path: options.path, project: options.project });
  let app, renderer, selected, card, background = false, busy = false, composing = false;
  let propertyToken = crypto.randomUUID(), propertyBaseline = '', settingsBaseline = '', cardBaseline = '', published = null;
  let propertiesMounted = false, outlineMounted = false, cardsMounted = false;
  const nativeLifetime = new AbortController();
  const formatError = error => helpers?.formatError?.(error) ?? error.message ?? String(error);
  const clip = (value, count) => Array.from(String(value)).slice(0, count).join('');
  const selector = suffix => '[data-editor-form="' + suffix + '"]';
  const findForm = suffix => app.container.querySelector(selector(suffix));
  const input = (suffix, fieldName) => Array.from(findForm(suffix)?.elements ?? []).find(control => control.name === fieldName);
  function readForm(suffix) {
    const result = {};
    for (const control of findForm(suffix)?.elements ?? []) {
      if (!control.name || !['INPUT', 'TEXTAREA', 'SELECT'].includes(control.tagName) || control.type === 'file') continue;
      result[control.name] = control.type === 'checkbox' ? control.checked : control.value;
    }
    return result;
  }
  const fingerprint = suffix => JSON.stringify(readForm(suffix));
  const hasProperties = () => propertiesMounted && fingerprint('properties') !== propertyBaseline;
  const hasSettings = () => settingsBaseline && fingerprint('settings') !== settingsBaseline;
  const hasCardName = () => kind === 'cards' && cardsMounted && fingerprint('card-name') !== cardBaseline;
  const hasDraft = () => draft.dirty || hasProperties() || hasSettings() || hasCardName();
  const currentCard = () => draft.project.stack?.cards.find(item => item.id === card) ?? draft.project.stack?.cards[0];
  const root = () => kind === 'form' ? draft.project.form.root : background ? draft.project.stack.background : currentCard().root;
  function metadata() {
    if (!app || app.disposed) return;
    app.setDirty(Boolean(hasDraft()));
    app.setTitle(draft.project.name + ' — ' + name);
  }
  function selectField(id, label, fieldName, value, values, on) {
    return el('div', id + '-field', { class: 'component-field' }, [
      el('label', id + '-label', { text: label, attrs: { for: id } }),
      el('select', id, { class: 'form-control', attrs: { name: fieldName }, props: { value: String(value ?? '') },
        ...(on ? { on: { change: on } } : {}) }, values.map((item, index) =>
        el('option', id + '-option-' + index, { text: typeof item === 'string' ? item : item.label,
          props: { value: typeof item === 'string' ? item : item.value } })))
    ]);
  }
  const checkbox = (id, label, fieldName, checked) => el('label', id + '-label', { class: 'authoring-checkbox', attrs: { for: id } }, [
    el('input', id, { attrs: { name: fieldName, type: 'checkbox' }, props: { checked: Boolean(checked) } }),
    text('span', id + '-text', label)
  ]);
  const hidden = (id, fieldName, value) => el('input', id, { attrs: { type: 'hidden', name: fieldName }, props: { value } });
  // Set select values after their complete option list has crossed all device batches.
  async function putTree(tree, parent) {
    await app.ui.tree(tree, parent);
    const ops = [];
    function visit(node) {
      if (node.tag === 'select' && Object.hasOwn(node.props ?? {}, 'value')) ops.push({ op: 'set', id: node.id, props: { value: node.props.value } });
      for (const child of node.children ?? []) visit(child);
    }
    for (const node of Array.isArray(tree) ? tree : [tree]) visit(node);
    if (ops.length) await app.ui.send(ops);
  }
  function resetSelection() {
    card = kind === 'cards' ? draft.project.stack.startCard : null; background = false;
    selected = root().id;
  }
  resetSelection();

  function propertyTree() {
    const project = draft.project, node = projects.findNode(project, selected) ?? root();
    selected = node.id; propertyToken = crypto.randomUUID();
    const controls = [hidden('property-document', 'document', draft.generation), hidden('property-token', 'selection', propertyToken), hidden('property-node', 'node', node.id)];
    const names = ['document', 'selection', 'node'];
    function add(name, definition) { names.push(name); controls.push(definition); }
    const textField = (name, label, value, options = {}) => field('property-' + name, { name, label, value, attrs: { maxlength: '16384', ...options.attrs }, ...options });
    if (['section', 'split', 'field', 'textarea'].includes(node.type)) add('label', textField('label', 'Label', node.label, { attrs: { maxlength: '240' } }));
    if (['heading', 'text', 'button', 'output'].includes(node.type)) add('text', textField('text', node.type === 'button' ? 'Button text' : 'Text', node.text, { multiline: node.type !== 'button' }));
    if (['field', 'textarea'].includes(node.type)) {
      add('value', textField('value', 'Initial value', node.value, { multiline: node.type === 'textarea' }));
      add('placeholder', textField('placeholder', 'Placeholder', node.placeholder));
      add('required', checkbox('property-required', 'Require a value', 'required', node.required));
      if (node.type === 'field') add('inputType', selectField('property-input-type', 'Input type', 'inputType', node.inputType, ['text', 'email', 'number', 'date', 'url', 'search']));
      controls.push(text('p', 'property-binding-note', 'Use {{' + node.id + '}} in a button argument or message to read this field.', 'field-hint authoring-mono'));
    }
    if (node.type === 'split') {
      add('direction', selectField('property-direction', 'Direction', 'direction', node.direction, [{ value: 'horizontal', label: 'Left / right' }, { value: 'vertical', label: 'Up / down' }]));
      add('ratio', selectField('property-ratio', 'Relative sizes', 'ratio', node.ratio, [{ value: 'equal', label: 'Equal' }, { value: 'wide-first', label: 'Larger first region' }, { value: 'wide-second', label: 'Larger second region' }]));
      add('collapse', selectField('property-collapse', 'Stack regions when window is narrower than', 'collapse', node.collapse,
        [{ value: '420', label: '420 px · small window' }, { value: '650', label: '650 px · default' }, { value: '900', label: '900 px · roomy layout' }, { value: 'never', label: 'Never' }]));
    }
    if (node.type === 'image') {
      add('alt', textField('alt', 'Picture description', node.alt, { attrs: { maxlength: '500' } }));
      add('fit', selectField('property-fit', 'Picture fit', 'fit', node.fit, ['contain', 'cover']));
      controls.push(el('div', 'picture-picker', { class: 'component-field' }, [
        el('label', 'picture-picker-label', { text: 'Choose picture', attrs: { for: 'picture-file' } }),
        el('input', 'picture-file', { class: 'form-control', attrs: { type: 'file', name: 'picture', accept: 'image/png,image/jpeg,image/gif,image/webp' }, on: { change: 'editor.picture' }, data: { node: node.id, document: draft.generation } }),
        text('p', 'picture-picker-hint', 'PNG, JPEG, GIF, or WebP · up to 240 KiB. The picture travels inside the project.', 'field-hint')
      ]));
    }
    if (node.type === 'button') {
      const action = node.action ?? { kind: 'none' };
      add('tone', selectField('property-tone', 'Button style', 'tone', node.tone, ['primary', 'secondary', 'success']));
      add('actionKind', selectField('property-action-kind', 'When clicked', 'actionKind', action.kind,
        [{ value: 'none', label: 'No action' }, { value: 'message', label: 'Show a message' }, { value: 'command', label: 'Run a command' },
          ...(kind === 'cards' ? [{ value: 'navigate', label: 'Go to a card' }] : []), { value: 'set-field', label: 'Set a field' }], 'editor.action-kind'));
      const commands = os.commands.list().map(command => ({ value: command.name, label: command.name + ' — ' + command.summary }));
      if (action.command && !commands.some(command => command.value === action.command)) commands.push({ value: action.command, label: action.command + ' (not installed)' });
      const commandGroup = el('div', 'property-command-group', { class: 'authoring-action-group', props: { hidden: action.kind !== 'command' } }, [
        selectField('property-command', 'Command', 'command', action.command ?? 'echo', commands, 'editor.command-help'),
        textField('arguments', 'Arguments (JSON array)', JSON.stringify(action.args ?? ['Hello from my application']), { multiline: true, hint: 'Each value is one argument. A field token is expanded as text, never executed as code.' }),
        textField('inputRecords', 'Input records (JSON array)', JSON.stringify(action.input ?? []), { multiline: true }),
        text('p', 'command-usage', '', 'field-hint authoring-mono')
      ]);
      names.push('command', 'arguments', 'inputRecords'); controls.push(commandGroup);
      const fields = projects.walkNodes(project).map(item => item.node).filter(item => ['field', 'textarea'].includes(item.type));
      const fieldOptions = fields.map(item => ({ value: item.id, label: item.label + ' · ' + item.id.slice(-8) }));
      names.push('binding');
      controls.push(el('div', 'property-binding-group', { class: 'authoring-action-group', props: { hidden: action.kind !== 'command' || !fields.length } }, [
        selectField('property-binding', 'Field argument', 'binding', fields[0]?.id ?? '', fieldOptions.length ? fieldOptions : [{ value: '', label: 'Add a field first' }]),
        button('property-insert-binding', 'Append field argument', 'editor.binding')
      ]));
      names.push('message'); controls.push(el('div', 'property-message-group', { props: { hidden: !['message', 'set-field'].includes(action.kind) } }, [
        textField('message', 'Message or field value', action.text ?? action.value ?? 'Hello from my application.', { multiline: true })
      ]));
      names.push('targetCard'); controls.push(el('div', 'property-navigation-group', { props: { hidden: action.kind !== 'navigate' } }, [
        selectField('property-target-card', 'Card', 'targetCard', action.card ?? 'next', [
          { value: 'next', label: 'Next card' }, { value: 'previous', label: 'Previous card' }, { value: 'first', label: 'First card' }, { value: 'last', label: 'Last card' },
          ...(project.stack?.cards ?? []).map(card => ({ value: card.id, label: card.name }))
        ])
      ]));
      names.push('targetField'); controls.push(el('div', 'property-field-group', { props: { hidden: action.kind !== 'set-field' } }, [
        selectField('property-target-field', 'Field to change', 'targetField', action.field ?? fields[0]?.id ?? '', fieldOptions.length ? fieldOptions : [{ value: '', label: 'Add a field first' }])
      ]));
      const outputs = projects.walkNodes(project).map(item => item.node).filter(item => item.type === 'output');
      names.push('output'); controls.push(el('div', 'property-output-group', { props: { hidden: !['command', 'message'].includes(action.kind) } }, [
        selectField('property-output', 'Show result in', 'output', action.output ?? '', [{ value: '', label: 'First result component or status bar' }, ...outputs.map(item => ({ value: item.id, label: clip(item.text, 35) || item.id.slice(-8) }))])
      ]));
    }
    controls.push(submitButton('apply-properties', 'Apply properties'));
    return el('div', 'properties-content', {}, [
      el('header', 'properties-heading', { class: 'authoring-panel-heading' }, [text('h3', 'properties-title', 'Properties'), text('span', 'properties-type', node.type, 'authoring-type')]),
      text('p', 'properties-id', node.id, 'authoring-component-id'),
      form('properties-form', { action: 'editor.properties', fields: names, attrs: { 'data-editor-form': 'properties' }, className: 'authoring-properties' }, controls),
      el('div', 'selected-node-actions', { class: 'app-actions authoring-node-actions' }, [
        button('component-up', 'Move up', 'editor.move-up'), button('component-down', 'Move down', 'editor.move-down'),
        button('component-remove', 'Remove', 'editor.remove')
      ]),
      text('p', 'selected-node-help', 'Changes apply when you select another component, Save, Run, or Publish. Ctrl+S saves the project.', 'app-note')
    ]);
  }
  function applyProperties(value = readForm('properties')) {
    if (!propertiesMounted) return;
    if (value.document !== draft.generation || value.selection !== propertyToken || value.node !== selected) throw new Error('Those properties belong to an earlier selection. The current project was kept.');
    const original = projects.findNode(draft.project, selected);
    if (!original) throw new Error('Select a component first.');
    const node = structuredClone(original);
    for (const key of ['label', 'text', 'placeholder', 'inputType', 'tone', 'direction', 'ratio', 'alt', 'fit']) if (Object.hasOwn(value, key)) node[key] = value[key];
    if (['field', 'textarea'].includes(node.type)) { node.value = value.value; node.required = value.required; }
    if (node.type === 'split') node.collapse = value.collapse === 'never' ? 'never' : Number(value.collapse);
    if (node.type === 'button') {
      const output = value.output ? { output: value.output } : {};
      if (value.actionKind === 'none') node.action = null;
      else if (value.actionKind === 'message') node.action = { kind: 'message', text: value.message, ...output };
      else if (value.actionKind === 'navigate') node.action = { kind: 'navigate', card: value.targetCard };
      else if (value.actionKind === 'set-field') node.action = { kind: 'set-field', field: value.targetField, value: value.message };
      else if (value.actionKind === 'command') {
        let args, inputRecords;
        try { args = JSON.parse(value.arguments); } catch { throw new Error('Arguments must be a JSON array, for example ["add", "{{field-id}}"].'); }
        try { inputRecords = JSON.parse(value.inputRecords); } catch { throw new Error('Input records must be a JSON array of objects, or [].'); }
        node.action = { kind: 'command', command: value.command, args, input: inputRecords, ...output };
      }
    }
    draft.replace(projects.replaceNode(draft.project, selected, node));
    propertyBaseline = fingerprint('properties');
  }
  function applySettings(value = readForm('settings')) {
    if (!settingsBaseline) return;
    if (value.generation !== draft.generation) throw new Error('Those settings belong to a previous document.');
    draft.change(project => { project.name = value.name; project.description = value.description;
      project.presentation = { chrome: value.chrome, maximized: value.maximized }; });
    settingsBaseline = fingerprint('settings');
  }
  function flushEditors() {
    if (composing) throw new Error('Finish composing text before changing the project.');
    if (hasProperties()) applyProperties();
    if (hasSettings()) applySettings();
    if (hasCardName()) {
      const value = readForm('card-name');
      if (value.generation !== draft.generation || value.cardId !== card) throw new Error('That name belongs to a previous card.');
      draft.change(project => { project.stack.cards.find(item => item.id === card).name = value.cardName; });
      cardBaseline = fingerprint('card-name');
    }
    draft.setPath(input('document', 'path')?.value ?? draft.displayPath);
    metadata();
  }
  async function renderProperties() {
    if (propertiesMounted) await app.ui.send([{ op: 'remove', id: 'properties-content' }]);
    await putTree(propertyTree(), 'property-pane'); propertiesMounted = true;
    propertyBaseline = fingerprint('properties');
    await updateCommandHelp();
  }
  async function updateCommandHelp() {
    const command = input('properties', 'command')?.value;
    if (!command) return;
    let usage;
    try { usage = os.commands.inspect(command).usage; } catch { usage = 'Install this command before running the application.'; }
    await app.ui.set('command-usage', { text: usage });
  }
  async function updateActionFields() {
    const type = input('properties', 'actionKind')?.value;
    if (!type) return;
    const fields = projects.walkNodes(draft.project).some(item => ['field', 'textarea'].includes(item.node.type));
    await app.ui.send([
      { op: 'set', id: 'property-command-group', props: { hidden: type !== 'command' } },
      { op: 'set', id: 'property-binding-group', props: { hidden: type !== 'command' || !fields } },
      { op: 'set', id: 'property-message-group', props: { hidden: !['message', 'set-field'].includes(type) } },
      { op: 'set', id: 'property-navigation-group', props: { hidden: type !== 'navigate' } },
      { op: 'set', id: 'property-field-group', props: { hidden: type !== 'set-field' } },
      { op: 'set', id: 'property-output-group', props: { hidden: !['command', 'message'].includes(type) } }
    ]);
  }
  async function renderOutline() {
    if (outlineMounted) await app.ui.send([{ op: 'remove', id: 'outline-content' }]);
    const entries = [];
    function visit(node, depth = 0) { entries.push({ node, depth }); for (const child of node.children ?? []) visit(child, depth + 1); }
    visit(root());
    await putTree(el('nav', 'outline-content', { class: 'authoring-outline', attrs: { 'aria-label': 'Component outline' } }, entries.map(({ node, depth }, index) =>
      button('outline-node-' + index, (depth ? '↳ '.repeat(Math.min(depth, 4)) : '') + clip(node.label || node.text || node.alt || node.type, 46),
        'editor.select', { node: node.id }, 'authoring-outline-item' + (selected === node.id ? ' is-selected' : '')))), 'outline-pane');
    outlineMounted = true;
  }
  async function renderCards() {
    if (kind !== 'cards') return;
    if (cardsMounted) await app.ui.send([{ op: 'remove', id: 'card-controls' }]);
    const project = draft.project, active = currentCard(); card = active.id;
    await putTree(el('div', 'card-controls', { class: 'authoring-card-controls' }, [
      selectField('card-select', 'Card', 'cardSelection', card, project.stack.cards.map(item => ({ value: item.id, label: item.name + (item.id === project.stack.startCard ? ' · start' : '') })), 'editor.card'),
      selectField('layer-select', 'Editing', 'cardLayer', background ? 'background' : 'card', [{ value: 'card', label: 'This card' }, { value: 'background', label: 'Shared background' }], 'editor.layer'),
      form('card-name-form', { action: 'editor.card-name', fields: ['cardName', 'generation', 'cardId'], attrs: { 'data-editor-form': 'card-name' }, className: 'authoring-card-name' }, [
        field('card-name', { label: 'Card name', name: 'cardName', value: active.name, attrs: { maxlength: '120' } }),
        hidden('card-generation', 'generation', draft.generation), hidden('card-identity', 'cardId', card),
        submitButton('rename-card', 'Rename', 'btn-outline theme-secondary btn-sm')
      ]),
      el('div', 'card-buttons', { class: 'app-actions' }, [button('add-card', 'Add card', 'editor.add-card'),
        button('duplicate-card', 'Duplicate', 'editor.duplicate-card'), button('start-card', 'Start here', 'editor.start-card'), button('delete-card', 'Delete card', 'editor.delete-card')])
    ]), 'cards-pane');
    cardsMounted = true; cardBaseline = fingerprint('card-name');
  }
  async function syncSettings() {
    const project = draft.project;
    await app.ui.send([
      { op: 'set', id: 'project-name-input', props: { value: project.name } },
      { op: 'set', id: 'project-description-input', props: { value: project.description } },
      { op: 'set', id: 'project-chrome', props: { checked: project.presentation.chrome } },
      { op: 'set', id: 'project-maximized', props: { checked: project.presentation.maximized } },
      { op: 'set', id: 'settings-generation', props: { value: draft.generation } },
      { op: 'set', id: 'document-generation', props: { value: draft.generation } },
      { op: 'set', id: 'project-path', props: { value: draft.displayPath } }
    ]);
    settingsBaseline = fingerprint('settings');
  }
  async function refresh({ settings = false } = {}) {
    if (app.disposed) return;
    if (!projects.findNode(draft.project, selected)) selected = root().id;
    await renderer.render({ project: draft.project, selected, card, backgroundOnly: background });
    await renderProperties(); await renderOutline(); await renderCards();
    if (settings) await syncSettings();
    await app.ui.send([
      { op: 'set', id: 'editor-project-title', text: draft.project.name },
      { op: 'set', id: 'editor-undo', props: { disabled: !draft.canUndo } },
      { op: 'set', id: 'editor-redo', props: { disabled: !draft.canRedo } },
      { op: 'set', id: 'editor-context', props: { hidden: true } },
      { op: 'set', id: 'canvas-caption', text: background ? 'Shared background · shown on every card' : kind === 'cards' ? currentCard().name : 'Responsive form · right-click a component to split' }
    ]);
    metadata(); app.changed();
  }
  async function editing(work, { refreshAfter = true, settings = false, flush = true } = {}) {
    if (busy) throw new Error('Wait for the current project operation.');
    if (composing) throw new Error('Finish composing text first.');
    busy = true;
    try {
      await app.ui.set('editor-controls', { props: { disabled: true } });
      if (flush) flushEditors();
      const result = await work();
      if (!app.disposed && refreshAfter) await refresh({ settings });
      return result;
    } finally {
      busy = false;
      if (!app.disposed) { await app.ui.set('editor-controls', { props: { disabled: false } }); metadata(); }
    }
  }
  function addComponent(type) {
    const node = projects.newNode(type);
    draft.change(project => {
      const item = projects.walkNodes(project).find(item => item.node.id === selected);
      if (item.node.type === 'section') item.node.children.push(node);
      else if (item.node.type === 'split') {
        const region = item.node.children.find(child => child.type === 'section');
        if (!region) throw new Error('Select one of the split regions before adding a component.');
        region.children.push(node);
      } else if (item.parent?.type === 'section') item.parent.children.splice(item.parent.children.findIndex(child => child.id === selected) + 1, 0, node);
      else return projects.replaceNode(project, selected, { ...projects.newNode('section'), children: [item.node, node] });
    });
    selected = node.id;
  }
  function removeComponent() {
    const project = draft.project, item = projects.walkNodes(project).find(item => item.node.id === selected);
    if (!item?.parent) throw new Error('Keep the outer region. You can remove its contents or create a new project.');
    const parentId = item.parent.id;
    draft.change(next => {
      const parent = projects.findNode(next, parentId), index = parent.children.findIndex(child => child.id === selected);
      if (parent.type === 'split') parent.children.splice(index, 1, projects.newNode('section'));
      else parent.children.splice(index, 1);
    });
    selected = parentId;
  }
  function moveComponent(direction) {
    draft.change(project => {
      const item = projects.walkNodes(project).find(item => item.node.id === selected);
      if (!item?.parent) return;
      const children = item.parent.children, index = children.findIndex(child => child.id === selected), target = index + direction;
      if (target < 0 || target >= children.length) return;
      [children[index], children[target]] = [children[target], children[index]];
    });
  }
  async function save(operationId) {
    const result = await draft.save({ operationId, expectedGeneration: draft.generation });
    await app.ui.set('project-path', { props: { value: draft.displayPath } });
    await app.say('Saved locally · revision ' + result.revision + '.'); return result;
  }
  async function showPublication(receipt) {
    published = receipt;
    await app.ui.send([
      { op: 'set', id: 'publication-panel', props: { hidden: false } },
      { op: 'set', id: 'publication-text', text: 'Published ' + receipt.id + ' · ' + receipt.version },
      { op: 'set', id: 'publication-path', text: receipt.bundlePath ?? '' },
      { op: 'set', id: 'install-publication', props: { disabled: false }, data: { id: receipt.id, application: receipt.application } },
      { op: 'set', id: 'open-publication', props: { disabled: !receipt.installed }, data: { application: receipt.application } },
      { op: 'set', id: 'share-publication', data: { id: receipt.id } }
    ]);
  }
  async function share(id) {
    const bundle = await os.software.exportBundle(id);
    const url = URL.createObjectURL(new Blob([JSON.stringify(bundle, null, 2) + '\n'], { type: 'application/json' }));
    const link = document.createElement('a'); link.href = url; link.download = id + '.esospkg.json'; link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    await app.say('Portable program downloaded. Import it through Software on another eSOS workspace.');
  }
  function mayReplace() { return !hasDraft() || window.confirm('Discard the unsaved project in this ' + name + ' window?'); }
  async function importPicture(intent) {
    if (intent.data?.document !== draft.generation || intent.data?.node !== selected) throw new Error('That picture selection belongs to a previous component.');
    const file = input('properties', 'picture')?.files?.[0];
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/gif', 'image/webp'].includes(file.type) || file.size > 240 * 1024) throw new Error('Choose a PNG, JPEG, GIF, or WebP picture up to 240 KiB.');
    await editing(async () => {
      const bytes = new Uint8Array(await file.arrayBuffer());
      let binary = '';
      for (let offset = 0; offset < bytes.length; offset += 8192) binary += String.fromCharCode(...bytes.subarray(offset, offset + 8192));
      const src = 'data:' + file.type + ';base64,' + btoa(binary);
      draft.change(project => { projects.findNode(project, selected).src = src; });
      await app.say('Picture embedded in this project. Save to keep it.');
    });
  }
  function addCard(duplicate = false) {
    const old = currentCard(), nextId = projects.newId('card');
    let next;
    if (duplicate) {
      next = structuredClone(old); next.id = nextId; next.name = (old.name + ' copy').slice(0, 120);
      const ids = new Map();
      function identify(node) { ids.set(node.id, projects.newId(node.type)); for (const child of node.children ?? []) identify(child); }
      identify(next.root);
      function rewrite(node) {
        node.id = ids.get(node.id);
        if (node.action) {
          if (ids.has(node.action.output)) node.action.output = ids.get(node.action.output);
          if (ids.has(node.action.field)) node.action.field = ids.get(node.action.field);
          if (node.action.card === old.id) node.action.card = nextId;
          for (const key of ['text', 'value']) if (typeof node.action[key] === 'string') for (const [from, to] of ids) node.action[key] = node.action[key].replaceAll('{{' + from + '}}', '{{' + to + '}}');
          if (node.action.args) node.action.args = node.action.args.map(value => { for (const [from, to] of ids) value = value.replaceAll('{{' + from + '}}', '{{' + to + '}}'); return value; });
        }
        for (const child of node.children ?? []) rewrite(child);
      }
      rewrite(next.root);
    } else next = { id: nextId, name: 'Card ' + (draft.project.stack.cards.length + 1), root: { ...projects.newNode('section'), label: 'Card content', children: [
      { ...projects.newNode('heading'), text: 'A new card' }, projects.newNode('text'),
      { ...projects.newNode('button'), text: 'Next card', action: { kind: 'navigate', card: 'next' } }
    ] } };
    draft.change(project => { project.stack.cards.push(next); }); card = nextId; background = false; selected = next.root.id;
  }
  function deleteCard() {
    const project = draft.project;
    if (project.stack.cards.length === 1) throw new Error('A stack keeps at least one card.');
    if (!window.confirm('Delete this card? Buttons pointing to it will go to the next card.')) return;
    draft.change(next => {
      next.stack.cards = next.stack.cards.filter(item => item.id !== card);
      if (next.stack.startCard === card) next.stack.startCard = next.stack.cards[0].id;
      for (const { node } of projects.walkNodes(next)) if (node.action?.kind === 'navigate' && node.action.card === card) node.action.card = 'next';
    });
    card = draft.project.stack.cards[0].id; background = false; selected = currentCard().root.id;
  }

  app = frame(application, name, async intent => {
    try {
      if (intent.action === 'editor.action-kind') { await updateActionFields(); metadata(); return; }
      if (intent.action === 'editor.command-help') { await updateCommandHelp(); metadata(); return; }
      if (intent.action === 'editor.picture') { await importPicture(intent); return; }
      if (intent.action === 'editor.binding') {
        const control = input('properties', 'arguments'), field = input('properties', 'binding')?.value;
        if (!field) throw new Error('Add a field first.');
        const before = control.value; let args;
        try { args = JSON.parse(before); } catch { throw new Error('Enter a JSON argument array first.'); }
        if (!Array.isArray(args) || args.length >= 32) throw new Error('Use an array with fewer than 32 arguments.');
        args.push('{{' + field + '}}');
        await app.ui.set('property-arguments', { ifValue: before, props: { value: JSON.stringify(args) } }); metadata(); return;
      }
      if (intent.action === 'editor.new') {
        if (!mayReplace()) return;
        await editing(() => { draft.reset(); resetSelection(); published = null; }, { flush: false, settings: true });
        await app.ui.set('publication-panel', { props: { hidden: true } }); await app.say('New ' + (kind === 'cards' ? 'stack' : 'form') + ' ready to edit.');
      } else if (intent.action === 'editor.open') {
        const path = input('document', 'path')?.value;
        if (!mayReplace()) return;
        await editing(async () => { await draft.load(path); resetSelection(); published = null; }, { flush: false, settings: true });
        await app.ui.set('publication-panel', { props: { hidden: true } }); await app.say('Opened revision ' + draft.revision + '.');
      } else if (intent.action === 'editor.save') {
        if (intent.fields.generation !== draft.generation) throw new Error('That save belonged to a previous project.');
        await editing(() => save(intent.eventId));
      } else if (intent.action === 'editor.run') {
        await editing(async () => { await os.views.open('project', { project: draft.project, newWindow: true }); await app.say('Running in a separate window. Your design remains here.'); }, { refreshAfter: false });
      } else if (intent.action === 'editor.publish') {
        await editing(async () => {
          await save(crypto.randomUUID());
          const receipt = await os.software.publish({ project: draft.project, sourcePath: draft.path });
          await showPublication(receipt); await app.say('Published to Software. Install to add it to your launcher, or share the portable package.');
        });
      } else if (intent.action === 'editor.install-publication') {
        await editing(async () => { await os.software.install(intent.data.id);
          await app.ui.send([{ op: 'set', id: 'install-publication', props: { disabled: true } }, { op: 'set', id: 'open-publication', props: { disabled: false } }]);
          await app.say('Installed. Open the published application here or from the launcher.'); }, { refreshAfter: false });
      } else if (intent.action === 'editor.open-publication') await os.views.open(intent.data.application, { newWindow: true });
      else if (intent.action === 'editor.share-publication') await editing(() => share(intent.data.id), { flush: false, refreshAfter: false });
      else if (intent.action === 'editor.software') await os.views.open('software');
      else if (intent.action === 'editor.properties') {
        if (intent.fields.document !== draft.generation || intent.fields.selection !== propertyToken) throw new Error('Those properties belong to an earlier selection.');
        await editing(() => {}, { refreshAfter: true });
        await app.say('Properties applied.');
      } else if (intent.action === 'editor.settings') {
        if (intent.fields.generation !== draft.generation) throw new Error('Those settings belong to an earlier project.');
        await editing(() => {}, { refreshAfter: true }); await app.say('Application settings applied.');
      } else if (intent.action === 'editor.select' || intent.action === 'editor.context') {
        const target = intent.data?.node;
        if (!projects.findNode(draft.project, target)) throw new Error('That component is no longer present.');
        await editing(() => { selected = target; });
        if (intent.action === 'editor.context') await app.ui.set('editor-context', { props: { hidden: false } });
      } else if (intent.action === 'editor.add') await editing(() => addComponent(intent.data.type));
      else if (intent.action === 'editor.split') await editing(() => {
        const result = projects.splitNode(draft.project, selected, intent.data.side); draft.replace(result.project); selected = result.selected;
      });
      else if (intent.action === 'editor.remove') await editing(removeComponent);
      else if (intent.action === 'editor.move-up') await editing(() => moveComponent(-1));
      else if (intent.action === 'editor.move-down') await editing(() => moveComponent(1));
      else if (intent.action === 'editor.undo') await editing(() => { draft.undo(); }, { settings: true });
      else if (intent.action === 'editor.redo') await editing(() => { draft.redo(); }, { settings: true });
      else if (intent.action === 'editor.card') await editing(() => { card = intent.value; background = false; selected = currentCard().root.id; });
      else if (intent.action === 'editor.layer') await editing(() => { background = intent.value === 'background'; selected = root().id; });
      else if (intent.action === 'editor.add-card') await editing(() => addCard(false));
      else if (intent.action === 'editor.duplicate-card') await editing(() => addCard(true));
      else if (intent.action === 'editor.delete-card') await editing(deleteCard);
      else if (intent.action === 'editor.start-card') await editing(() => draft.change(project => { project.stack.startCard = card; }));
      else if (intent.action === 'editor.card-name') {
        if (intent.fields.generation !== draft.generation || intent.fields.cardId !== card) throw new Error('That rename belonged to another card.');
        await editing(() => {});
      }
    } catch (error) { if (!app.disposed) { metadata(); await app.say(formatError(error), true); } }
  });
  app.container.classList.add('container-fluid', 'authoring-application', 'authoring-' + application);
  app.appMode = true; app.preferredMode = 'maximized';
  app.resourcePath = () => draft.path;
  app.sessionOptions = () => draft.path ? { path: draft.path } : {};
  app.beforeClose = async () => {
    if (busy) { await app.say('Wait for the current project operation before closing this window.', true); return false; }
    return !hasDraft() || window.confirm('Close ' + name + ' and discard this unsaved project?');
  };
  const project = draft.project;
  await putTree(el('main', 'authoring-shell', { class: 'authoring-shell' }, [
    el('fieldset', 'editor-controls', { class: 'authoring-controls' }, [
      el('header', 'editor-header', { class: 'authoring-header' }, [
        el('div', 'editor-identity', {}, [text('p', 'editor-eyebrow', kind === 'cards' ? 'MAKE SOMETHING INTERACTIVE' : 'YOUR APPLICATION, COMPOSED', 'authoring-eyebrow'),
          text('h2', 'editor-project-title', project.name), text('p', 'editor-subtitle', kind === 'cards' ? 'Cards · pages, shared backgrounds, and useful actions.' : 'Workbench · components, properties, and ordinary system commands.', 'authoring-subtitle')]),
        el('div', 'editor-actions', { class: 'app-actions' }, [button('editor-new', 'New', 'editor.new'), button('editor-undo', 'Undo', 'editor.undo'), button('editor-redo', 'Redo', 'editor.redo'),
          button('editor-run', 'Run', 'editor.run', {}, 'btn-outline theme-primary btn-sm'), button('editor-publish', 'Publish', 'editor.publish', {}, 'btn-solid theme-primary btn-sm')])
      ]),
      form('document-form', { action: 'editor.save', fields: ['path', 'generation'], attrs: { 'data-editor-form': 'document' }, className: 'authoring-document-bar' }, [
        field('project-path', { label: 'Project file', name: 'path', value: draft.displayPath, attrs: { maxlength: '1024', spellcheck: 'false', autocomplete: 'off' } }),
        hidden('document-generation', 'generation', draft.generation), submitButton('editor-save', 'Save'), button('editor-open', 'Open path', 'editor.open')
      ]),
      el('details', 'project-settings', { class: 'authoring-settings' }, [
        text('summary', 'project-settings-summary', 'Application settings'),
        form('settings-form', { action: 'editor.settings', fields: ['name', 'description', 'chrome', 'maximized', 'generation'], attrs: { 'data-editor-form': 'settings' }, className: 'authoring-settings-form' }, [
          field('project-name-input', { label: 'Application name', name: 'name', value: project.name, attrs: { maxlength: '100' } }),
          field('project-description-input', { label: 'Description', name: 'description', value: project.description, attrs: { maxlength: '600' } }),
          checkbox('project-chrome', 'Show window controls', 'chrome', project.presentation.chrome), checkbox('project-maximized', 'Open maximized', 'maximized', project.presentation.maximized),
          hidden('settings-generation', 'generation', draft.generation), submitButton('apply-settings', 'Apply settings', 'btn-outline theme-secondary btn-sm')
        ])
      ]),
      el('section', 'cards-pane', { class: 'authoring-cards-pane', props: { hidden: kind !== 'cards' } }),
      el('section', 'publication-panel', { class: 'authoring-publication', props: { hidden: true }, attrs: { 'aria-label': 'Published program' } }, [
        text('p', 'publication-text', ''), text('p', 'publication-path', '', 'authoring-bundle-path'),
        el('div', 'publication-actions', { class: 'app-actions' }, [button('install-publication', 'Install program', 'editor.install-publication', {}, 'btn-solid theme-primary btn-sm'),
          button('open-publication', 'Open program', 'editor.open-publication'), button('share-publication', 'Download to share', 'editor.share-publication'), button('open-software', 'Open Software', 'editor.software')])
      ]),
      el('div', 'authoring-workspace', { class: 'authoring-workspace' }, [
        el('aside', 'palette-pane', { class: 'authoring-palette-pane' }, [
          text('h3', 'palette-title', 'Components', 'authoring-panel-title'),
          el('div', 'component-palette', { class: 'authoring-palette' }, projects.components.map((component, index) => button('palette-' + index, component.label, 'editor.add', { type: component.type }, 'authoring-palette-button'))),
          text('h3', 'split-title', 'Split selected region', 'authoring-panel-title'),
          el('div', 'split-actions', { class: 'authoring-split-actions' }, ['left', 'right', 'up', 'down'].map(side => button('split-' + side, ({ left: '← Left', right: 'Right →', up: '↑ Up', down: '↓ Down' })[side], 'editor.split', { side }))),
          el('details', 'outline-details', { class: 'authoring-outline-panel', props: { open: true } }, [text('summary', 'outline-summary', 'Outline'), el('div', 'outline-pane')])
        ]),
        el('section', 'canvas-pane', { class: 'authoring-canvas-pane' }, [
          el('div', 'canvas-toolbar', { class: 'authoring-canvas-toolbar' }, [text('span', 'canvas-label', 'DESIGN'), text('span', 'canvas-caption', '')]),
          el('div', 'editor-context', { class: 'authoring-context', props: { hidden: true }, attrs: { role: 'group', 'aria-label': 'Split selected component' } }, [
            text('strong', 'context-title', 'Split selected component'),
            ...['left', 'right', 'up', 'down'].map(side => button('context-' + side, 'Split ' + side, 'editor.split', { side }))
          ]),
          el('div', 'editor-canvas', { class: 'authoring-canvas' })
        ]),
        el('aside', 'property-pane', { class: 'authoring-property-pane' })
      ])
    ]),
    el('p', 'message', { class: 'inline-message authoring-status', attrs: { role: 'status', 'aria-live': 'polite' } })
  ]));
  settingsBaseline = fingerprint('settings');
  renderer = runtime.createRenderer({ app, os, components: C, projects, project: draft.project, parent: 'editor-canvas', prefix: 'designer', mode: 'design', selected, card });
  await refresh();
  app.cleanup.push(() => { nativeLifetime.abort(); renderer.dispose(); });
  app.container.addEventListener('input', event => {
    if (event.target?.name === 'path') draft.setPath(event.target.value);
    metadata();
  }, { signal: nativeLifetime.signal });
  app.container.addEventListener('change', metadata, { signal: nativeLifetime.signal });
  app.container.addEventListener('compositionstart', () => { composing = true; }, { signal: nativeLifetime.signal });
  app.container.addEventListener('compositionend', () => { composing = false; metadata(); }, { signal: nativeLifetime.signal });
  app.container.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's') { event.preventDefault(); if (!busy) findForm('document')?.requestSubmit(); }
    else if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target?.tagName)) {
      if (event.key === 'Enter' && event.target?.dataset?.projectNode) { event.preventDefault(); event.target.click(); }
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') {
        event.preventDefault(); app.container.querySelector('[id$="-' + (event.shiftKey ? 'editor-redo' : 'editor-undo') + '"]')?.click();
      }
    }
  }, { signal: nativeLifetime.signal });
  window.addEventListener('beforeunload', event => { if (hasDraft()) { event.preventDefault(); event.returnValue = ''; } }, { signal: nativeLifetime.signal });
  await app.say(kind === 'cards' ? 'Edit a card or its shared background. Run opens your stack in a separate window.' : 'Choose a component, edit its properties, and Run your form. The starter button already adds a task.');
  return app;
}
