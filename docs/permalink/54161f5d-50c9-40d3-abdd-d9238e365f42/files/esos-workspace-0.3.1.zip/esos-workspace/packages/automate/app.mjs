/** Optional authoring UI. Runtime and host services are injected, not bundled here. */
export async function buildAutomate(ctx, options = {}) {
  const { frame, os, components, helpers = {}, projects = os.projects } = ctx;
  const runtime = await os.software.loadModule('runtime.workflows');
  const { element: el, text, button, submitButton, form, field } = components;
  const catalog = runtime.getActionCatalog(), definitions = new Map(catalog.map(value => [value.id, value]));
  const draft = await projects.createDraft({ kind: 'workflow', ...(options.path ? { path: options.path } : {}),
    ...(options.project ? { project: options.project } : {}) });
  const newAction = (action, parameters = runtime.defaultParameters(action)) => ({ id: projects.newId('action'), action, parameters });
  function example() {
    const project = projects.create('workflow');
    project.name = 'Make text uppercase';
    project.description = 'Ask for text, then transform it. Add more actions to make this workflow your own.';
    project.workflow.actions = [newAction('input.text', { prompt: 'What text would you like to transform?', defaultValue: 'Hello from Automate' }),
      newAction('text.transform')];
    return project;
  }
  if (!options.path && !options.project) draft.replace(example());
  let app, runner, selected = options.selected ?? draft.project.workflow.actions[0]?.id ?? null;
  let cardsMounted = false, parametersMounted = false, nativeDirty = false, composing = false;
  let nativeVersion = 0, documentTask = null, documentBusy = false, published = null;
  const lifetime = new AbortController();
  const errorText = error => (error?.code ? error.code + ' · ' : '') + (error?.message ?? String(error));
  const control = name => app.container.querySelector('[name="' + name + '"]');
  const hasDraft = () => draft.dirty || nativeDirty;
  const mayDiscard = () => !hasDraft() || window.confirm('Discard the unsaved changes in this Automate window?');
  function metadata() {
    if (app.disposed) return;
    app.setDirty(hasDraft());
    app.setTitle(draft.project.name + ' — Automate');
  }
  function currentAction(project = draft.project) { return project.workflow.actions.find(value => value.id === selected) ?? null; }
  function guardGeneration(value) {
    if (value !== undefined && value !== draft.generation) throw new Error('That action belonged to the previous workflow. The current document was kept.');
  }
  function requireEditable() {
    if (documentBusy || runner?.running) throw new Error('Wait for this operation to finish, or cancel the current run.');
    if (composing) throw new Error('Finish composing text before changing the workflow.');
  }
  function capture() {
    if (composing) throw new Error('Finish composing text before using the workflow.');
    const project = draft.project;
    const name = control('document-name'), description = control('document-description'), path = control('document-path');
    if (name) project.name = name.value;
    if (description) project.description = description.value;
    const step = currentAction(project), definition = step && definitions.get(step.action);
    if (definition && parametersMounted) {
      const parameters = {};
      for (const parameter of definition.parameters) parameters[parameter.name] = control('parameter-' + parameter.name)?.value ?? step.parameters[parameter.name] ?? parameter.defaultValue;
      // Preserve incomplete settings while selecting, reordering, or saving a
      // draft. Full parameter and stream checks gate execution and publication.
      step.parameters = parameters;
    }
    draft.replace(project);
    if (path) draft.setPath(path.value);
    nativeDirty = false; metadata();
    return draft.project;
  }
  async function validateDisplay() {
    let failure = null, plan;
    try { plan = runtime.validateWorkflow(draft.project); } catch (error) { failure = error; }
    await app.ui.send([
      { op: 'set', id: 'automate-compatibility', text: failure ? errorText(failure) :
        plan.actions.length + ' compatible actions · output: ' + plan.output + (plan.effects.length ? ' · changes local files or tasks' : ''),
        class: 'automate-compatibility' + (failure ? ' failure' : '') },
      { op: 'set', id: 'automate-publish', props: { disabled: Boolean(failure) || documentBusy || runner.running } },
      { op: 'set', id: 'automate-run-run', props: { disabled: Boolean(failure) || documentBusy || runner.running } },
      { op: 'set', id: 'automate-undo', props: { disabled: !draft.canUndo } },
      { op: 'set', id: 'automate-redo', props: { disabled: !draft.canRedo } }
    ]);
  }
  async function setEditingState() {
    if (app.disposed) return;
    await app.ui.set('automate-editor-fields', { props: { disabled: documentBusy || runner.running } });
    await validateDisplay();
  }
  async function renderMetadata() {
    const project = draft.project;
    await app.ui.send([
      { op: 'set', id: 'automate-name', props: { value: project.name } },
      { op: 'set', id: 'automate-description', props: { value: project.description } },
      { op: 'set', id: 'automate-path', props: { value: draft.displayPath } },
      { op: 'set', id: 'automate-generation', props: { value: draft.generation } },
      { op: 'set', id: 'automate-open-generation', props: { value: draft.generation } },
      { op: 'set', id: 'automate-add-generation', props: { value: draft.generation } },
      ...['automate-new', 'automate-publish', 'automate-undo', 'automate-redo', 'automate-show-file', 'automate-run-run']
        .map(id => ({ op: 'set', id, data: { generation: draft.generation } })),
      { op: 'set', id: 'automate-revision', text: draft.path ? draft.path + ' · revision ' + draft.revision : 'Unsaved workflow · ordinary .esos.json project file' }
    ]);
    metadata();
  }
  function parameterTree(step) {
    const definition = definitions.get(step?.action);
    if (!step) return el('div', 'automate-parameter-body', {}, [text('p', 'automate-select-note', 'Select an action to configure it.', 'empty-state')]);
    if (!definition) return el('div', 'automate-parameter-body', {}, [text('p', 'automate-select-note',
      'This action is unavailable in runtime version 1. Remove it or open the project with a compatible runtime.', 'inline-message failure')]);
    const parameters = { ...runtime.defaultParameters(step.action), ...step.parameters };
    return el('div', 'automate-parameter-body', {}, [
      text('h3', 'automate-selected-label', definition.label),
      text('p', 'automate-selected-description', definition.description, 'app-note'),
      text('p', 'automate-selected-types', (definition.input === 'none' ? 'Starts a workflow' : 'Input: ' + definition.input) + ' · output: ' + definition.output,
        'automate-types'),
      form('automate-parameters', { action: 'automate.apply', fields: ['step', 'generation', ...definition.parameters.map(value => 'parameter-' + value.name)] }, [
        el('input', 'automate-selected-id', { attrs: { type: 'hidden', name: 'step' }, props: { value: step.id } }),
        el('input', 'automate-selected-generation', { attrs: { type: 'hidden', name: 'generation' }, props: { value: draft.generation } }),
        ...definition.parameters.map(parameter => {
          const id = 'automate-parameter-' + parameter.name;
          if (parameter.type === 'select') return el('div', id + '-field', { class: 'component-field' }, [
            el('label', id + '-label', { text: parameter.label, attrs: { for: id } }),
            el('select', id, { class: 'form-control', attrs: { name: 'parameter-' + parameter.name }, props: { value: parameters[parameter.name] } },
              parameter.options.map((option, index) => el('option', id + '-option-' + index, { text: option.label, props: { value: option.value } })))
          ]);
          return field(id, { label: parameter.label, name: 'parameter-' + parameter.name,
            multiline: parameter.type === 'multiline', value: parameters[parameter.name],
            attrs: { maxlength: String(parameter.maxLength), ...(parameter.required ? { required: '' } : {}),
              ...(parameter.type === 'multiline' ? { rows: '5' } : {}), autocomplete: 'off' }, hint: parameter.hint });
        }),
        ...(definition.parameters.length ? [submitButton('automate-apply', 'Apply settings', 'btn-outline theme-secondary btn-sm')]
          : [text('p', 'automate-no-parameters', 'This action has no settings.', 'app-note')])
      ]),
      text('p', 'automate-command-note', 'Uses the ' + definition.command + ' command with structured arguments.', 'app-note')
    ]);
  }
  async function renderActions() {
    const project = draft.project, actions = project.workflow.actions;
    if (!actions.some(value => value.id === selected)) selected = actions[0]?.id ?? null;
    if (cardsMounted) await app.ui.send([{ op: 'remove', id: 'automate-action-list' }]);
    await app.ui.tree(el('ol', 'automate-action-list', { class: 'automate-action-list' }, actions.map((step, index) => {
      const definition = definitions.get(step.action), data = { id: step.id, generation: draft.generation };
      return el('li', 'automate-card-' + index, { class: 'automate-action-card' + (step.id === selected ? ' is-selected' : '') }, [
        button('automate-select-' + index, (index + 1) + '. ' + (definition?.label ?? step.action), 'automate.select', data, 'automate-card-select'),
        text('p', 'automate-card-schema-' + index, definition ? (definition.input === 'none' ? 'Start' : definition.input) + ' → ' + definition.output : 'Unavailable action', 'automate-types'),
        el('div', 'automate-card-actions-' + index, { class: 'automate-card-tools' }, [
          { ...button('automate-up-' + index, '↑ Move up', 'automate.up', data, 'btn-text btn-xs'), props: { disabled: index === 0 } },
          { ...button('automate-down-' + index, '↓ Move down', 'automate.down', data, 'btn-text btn-xs'), props: { disabled: index === actions.length - 1 } },
          button('automate-remove-' + index, 'Remove', 'automate.remove', data, 'btn-text btn-xs')
        ])
      ]);
    })), 'automate-sequence');
    cardsMounted = true;
    if (parametersMounted) await app.ui.send([{ op: 'remove', id: 'automate-parameter-body' }]);
    await app.ui.tree(parameterTree(currentAction(project)), 'automate-inspector');
    parametersMounted = true;
    await app.ui.set('automate-empty', { props: { hidden: actions.length > 0 } });
    await validateDisplay();
    metadata(); app.changed();
  }
  async function fullRender() { await renderMetadata(); await renderActions(); }
  function documentOperation(operation) {
    if (documentTask) throw new Error('Another document operation is still finishing.');
    documentBusy = true;
    const startingVersion = nativeVersion;
    const task = (async () => {
      try {
        await setEditingState();
        if (nativeVersion !== startingVersion) throw new Error('The draft changed before the operation began. Your changes were kept; try again.');
        return await operation();
      }
      finally { documentBusy = false; documentTask = null; await setEditingState(); }
    })();
    documentTask = task;
    return task;
  }
  async function save(eventId) {
    const result = await draft.save({ operationId: eventId, expectedGeneration: draft.generation });
    await renderMetadata();
    await app.say('Saved locally · revision ' + result.revision + '.');
    app.changed();
    return result;
  }

  app = frame('automate', 'Automate', async intent => {
    try {
      if (await runner.handleIntent(intent)) return;
      guardGeneration(intent.fields?.generation ?? intent.data?.generation);
      if (intent.action === runner.runAction) {
        requireEditable();
        const project = capture();
        runtime.validateWorkflow(project);
        runner.start(project);
        return;
      }
      if (intent.action === 'automate.software') { await os.views.open('software'); return; }
      requireEditable();
      if (intent.action === 'automate.open') {
        if (!mayDiscard()) return;
        const version = nativeVersion, generation = draft.generation, draftVersion = draft.version;
        await documentOperation(async () => {
          if (nativeVersion !== version) throw new Error('The draft changed before opening. Your changes were kept.');
          await draft.load(intent.fields.path, { expectedGeneration: generation, expectedVersion: draftVersion });
          nativeDirty = false; selected = draft.project.workflow.actions[0]?.id ?? null; published = null;
          await fullRender(); await app.say('Opened workflow revision ' + draft.revision + '.');
        });
      } else if (intent.action === 'automate.new') {
        if (!mayDiscard()) return;
        draft.reset(); draft.replace(example()); nativeDirty = false; published = null;
        selected = draft.project.workflow.actions[0]?.id ?? null;
        await fullRender(); await app.say('New workflow. Change its actions, then save it as a project file.');
      } else if (intent.action === 'automate.save') {
        capture();
        await documentOperation(() => save(intent.eventId));
      } else if (intent.action === 'automate.publish') {
        const project = capture(); runtime.validateWorkflow(project);
        await documentOperation(async () => {
          if (draft.dirty || !draft.path) await save(crypto.randomUUID());
          published = await os.software.publish({ project: draft.project, sourcePath: draft.path });
          await app.say('Published “' + project.name + '” to Software · ' + published.version + '. Install it there to run without Automate, or export its program file to share.');
          await app.ui.set('automate-software', { props: { hidden: false } });
        });
      } else if (intent.action === 'automate.show-file') {
        if (!draft.path) throw new Error('Save the workflow before showing its file.');
        await os.views.open('files', { path: draft.path });
      } else if (intent.action === 'automate.undo' || intent.action === 'automate.redo') {
        capture(); intent.action === 'automate.undo' ? draft.undo() : draft.redo();
        nativeDirty = false; await fullRender();
      } else if (intent.action === 'automate.add') {
        capture();
        if (draft.project.workflow.actions.length >= runtime.MAX_ACTIONS) throw new Error('A workflow supports up to ' + runtime.MAX_ACTIONS + ' actions.');
        const step = newAction(intent.fields.action);
        draft.change(project => { project.workflow.actions.push(step); }); selected = step.id;
        await renderActions();
      } else if (['automate.select', 'automate.up', 'automate.down', 'automate.remove'].includes(intent.action)) {
        capture();
        const project = draft.project, index = project.workflow.actions.findIndex(step => step.id === intent.data.id);
        if (index < 0) throw new Error('That action is no longer in this workflow.');
        if (intent.action === 'automate.select') selected = intent.data.id;
        else {
          if (intent.action === 'automate.remove') project.workflow.actions.splice(index, 1);
          else {
            const next = index + (intent.action === 'automate.up' ? -1 : 1);
            if (next < 0 || next >= project.workflow.actions.length) return;
            [project.workflow.actions[index], project.workflow.actions[next]] = [project.workflow.actions[next], project.workflow.actions[index]];
          }
          draft.replace(project);
        }
        await renderActions();
      } else if (intent.action === 'automate.apply') {
        if (intent.fields.step !== selected) throw new Error('Those settings belong to a different action.');
        capture(); await renderActions(); await app.say('Action settings applied to this draft. Save to keep them.');
      }
    } catch (error) { if (!app.disposed) await app.say(errorText(error), true); }
  });
  runner = runtime.createWorkflowRunView({ app, os, components, projects, prefix: 'automate-run',
    onStateChange: () => setEditingState() });
  await app.ui.tree([
    el('header', 'automate-heading', { class: 'app-heading' }, [
      text('p', 'automate-eyebrow', 'SMALL ACTIONS · USEFUL WORKFLOWS', 'app-eyebrow'),
      text('h2', 'automate-title', 'Automate'),
      text('p', 'automate-description-copy', 'Arrange actions, configure their fields, and connect the work with typed records.', 'app-description')
    ]),
    el('fieldset', 'automate-editor-fields', { class: 'automate-editor-fields' }, [
      el('div', 'automate-toolbar', { class: 'app-toolbar' }, [
        button('automate-new', 'New workflow', 'automate.new'), button('automate-undo', 'Undo edit', 'automate.undo'),
        button('automate-redo', 'Redo edit', 'automate.redo'), button('automate-show-file', 'Show in Files', 'automate.show-file')
      ]),
      el('details', 'automate-open-details', {}, [
        text('summary', 'automate-open-summary', 'Open a workflow file'),
        form('automate-open-form', { action: 'automate.open', fields: ['path', 'generation'], className: 'automate-open-form' }, [
          el('input', 'automate-open-generation', { attrs: { type: 'hidden', name: 'generation' }, props: { value: draft.generation } }),
          field('automate-open-path', { label: 'Project path', name: 'path', value: draft.displayPath,
            attrs: { maxlength: '1024', required: '', placeholder: '~/my-workflow.esos.json' } }),
          submitButton('automate-open-button', 'Open', 'btn-outline theme-secondary btn-sm')
        ])
      ]),
      form('automate-document', { action: 'automate.save', fields: ['document-name', 'document-description', 'document-path', 'generation'], className: 'automate-document-form' }, [
        el('input', 'automate-generation', { attrs: { type: 'hidden', name: 'generation' }, props: { value: draft.generation } }),
        el('div', 'automate-document-fields', { class: 'automate-document-fields' }, [
          field('automate-name', { label: 'Workflow name', name: 'document-name', value: draft.project.name, attrs: { maxlength: '120', required: '' } }),
          field('automate-path', { label: 'Project file', name: 'document-path', value: draft.displayPath, attrs: { maxlength: '1024', required: '' } })
        ]),
        field('automate-description', { label: 'Description', name: 'document-description', value: draft.project.description, attrs: { maxlength: '1000' } }),
        el('div', 'automate-save-tools', { class: 'app-toolbar' }, [
          submitButton('automate-save', 'Save workflow', 'btn-solid theme-primary btn-sm'),
          button('automate-publish', 'Publish to Software', 'automate.publish'),
          { ...button('automate-software', 'Open Software', 'automate.software'), props: { hidden: true } }
        ])
      ]),
      text('p', 'automate-revision', '', 'app-note'),
      form('automate-add-form', { action: 'automate.add', fields: ['action', 'generation'], className: 'automate-add-form' }, [
        el('input', 'automate-add-generation', { attrs: { type: 'hidden', name: 'generation' }, props: { value: draft.generation } }),
        el('div', 'automate-action-picker-field', { class: 'component-field' }, [
          el('label', 'automate-action-picker-label', { text: 'Choose an action', attrs: { for: 'automate-action-picker' } }),
          el('select', 'automate-action-picker', { class: 'form-control', attrs: { name: 'action' }, props: { value: 'text.replace' } },
            catalog.map((definition, index) => el('option', 'automate-action-option-' + index, { text: definition.category + ' · ' + definition.label, props: { value: definition.id } })))
        ]),
        submitButton('automate-add', 'Add action', 'btn-outline theme-secondary btn-sm')
      ]),
      el('div', 'automate-workspace', { class: 'automate-workspace' }, [
        el('section', 'automate-sequence', { class: 'automate-sequence', attrs: { 'aria-label': 'Ordered actions' } }, [
          text('p', 'automate-empty', 'Add a starting action: Text, Ask for text, List a folder, Read a file, Find files, or Get tasks.', 'empty-state')
        ]),
        el('section', 'automate-inspector', { class: 'automate-inspector', attrs: { 'aria-label': 'Selected action settings' } })
      ]),
      text('p', 'automate-compatibility', '', 'automate-compatibility')
    ]),
    runner.tree,
    helpers.message?.() ?? el('p', 'message', { class: 'inline-message', attrs: { role: 'status', 'aria-live': 'polite' } }),
    text('p', 'automate-footnote', 'Projects are ordinary files. Publishing registers a version in Software; its installed program uses the workflow runtime without this editor.', 'app-note')
  ]);
  await fullRender();
  const inputChanged = event => {
    if (!event.target.closest('fieldset') || !app.container.contains(event.target)) return;
    const name = event.target.name ?? '';
    if (!name.startsWith('document-') && !name.startsWith('parameter-')) return;
    nativeVersion++; nativeDirty = true; metadata();
  };
  app.container.addEventListener('input', inputChanged, { signal: lifetime.signal });
  app.container.addEventListener('change', inputChanged, { signal: lifetime.signal });
  app.container.addEventListener('compositionstart', () => { composing = true; }, { signal: lifetime.signal });
  app.container.addEventListener('compositionend', () => { composing = false; }, { signal: lifetime.signal });
  app.container.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's' && !event.altKey && !event.isComposing) {
      event.preventDefault();
      if (!documentBusy && !runner.running) app.container.querySelector('form[id$="-automate-document"]')?.requestSubmit();
    }
  }, { signal: lifetime.signal });
  window.addEventListener('beforeunload', event => {
    if (hasDraft() || runner.running || documentBusy) { event.preventDefault(); event.returnValue = ''; }
  }, { signal: lifetime.signal });
  app.beforeClose = async () => {
    if (documentTask) await documentTask.catch(() => {});
    if (composing) { await app.say('Finish composing text before closing this workflow.'); return false; }
    if (!mayDiscard()) return false;
    await runner.stop();
    return true;
  };
  app.cleanup.push(() => lifetime.abort(), () => runner.dispose());
  app.sessionOptions = () => ({ ...(draft.path ? { path: draft.path } : {}), ...(selected ? { selected } : {}) });
  app.resourcePath = () => draft.path;
  metadata();
  return app;
}
