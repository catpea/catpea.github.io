import { calculate } from './arithmetic.mjs';
export { calculate } from './arithmetic.mjs';

export async function run(ctx) {
  if (!Array.isArray(ctx.args) || ctx.args.some(value => typeof value !== 'string')) throw new TypeError('calc arguments must be text.');
  if (ctx.args.length) {
    ctx.signal?.throwIfAborted();
    await ctx.stdout.write(calculate(ctx.args.join(' ')));
    return;
  }
  for await (const record of ctx.stdin) {
    ctx.signal?.throwIfAborted();
    await ctx.stdout.write(calculate(record.expression));
  }
}

export async function buildCalculator({ frame, os, onError, components, helpers }) {
  const { element: el, text, button, form, field, submitButton, dataTable } = components;
  const { heading, message, formatError, refresher } = helpers;
  const namespace = 'applications.calculator';
  let app, table;
  function history(value) {
    if (value === null) return [];
    if (value?.schema !== 1 || !Array.isArray(value.history) || value.history.length > 50 ||
        value.history.some(item => typeof item.id !== 'string' || typeof item.expression !== 'string' || item.expression.length > 512 || !Number.isFinite(item.result))) {
      throw new Error('Calculator history is not in a supported format. Its data was preserved.');
    }
    return value.history;
  }
  async function refresh() {
    const saved = await os.state.read(namespace);
    const rows = history(saved.state);
    if (app.disposed) return;
    await table.update([...rows].reverse().map(item => ({ key: item.id, cells: [item.expression, String(item.result),
      button('reuse', 'Use', 'calculator.reuse', { expression: item.expression }, 'btn-text btn-sm')] })));
    await app.ui.set('history-note', { text: rows.length + ' saved calculations · revision ' + saved.revision });
  }
  const schedule = refresher(refresh, error => { if (!app.disposed) onError(error); });
  app = frame('calculator', 'Calculator', async intent => {
    try {
      if (intent.action === 'calculator.calculate') {
        const result = calculate(intent.fields.expression);
        const saved = await os.state.read(namespace);
        const rows = [...history(saved.state), { id: crypto.randomUUID(), ...result }].slice(-50);
        await os.state.commit({ app: namespace, expectedRevision: saved.revision, state: { schema: 1, history: rows },
          events: [{ type: 'calculation.saved', data: result }], operationId: intent.eventId });
        if (!app.disposed) {
          await app.ui.set('answer', { text: String(result.result) });
          await app.say('Calculation saved locally.');
        }
      } else if (intent.action === 'calculator.reuse') {
        await app.ui.set('expression', { props: { value: intent.data.expression } });
      } else if (intent.action === 'calculator.clear') {
        const saved = await os.state.read(namespace);
        await os.state.commit({ app: namespace, expectedRevision: saved.revision, state: { schema: 1, history: [] },
          events: [{ type: 'calculation.history-cleared', data: { count: history(saved.state).length } }], operationId: intent.eventId });
        await app.say('Visible history cleared. Committed journal history is retained.');
      }
      await schedule();
    } catch (error) { await app.say(formatError(error), true); }
  });
  table = dataTable(app.ui, { id: 'calculator-history', caption: 'Saved calculations', columns: ['Expression', 'Result', 'Reuse'], limit: 50 });
  await app.ui.tree([
    heading('A calculation, with a record.', 'Arithmetic in a window or through the calc command. Removing Calculator retains its saved history.'),
    form('calculate-form', { action: 'calculator.calculate', fields: ['expression'], className: 'app-toolbar' }, [
      field('expression', { label: 'Expression', name: 'expression', className: 'field-grow',
        attrs: { placeholder: '(18 + 24) / 6', maxlength: '512', required: '', autocomplete: 'off', spellcheck: 'false' } }),
      submitButton('calculate-button', 'Calculate')
    ]),
    el('p', 'answer', { text: 'Ready', class: 'calculator-answer', attrs: { role: 'status', 'aria-live': 'polite' } }),
    text('p', 'arithmetic-note', 'Use +, −, *, /, % and ^, with parentheses. Standard browser number arithmetic applies; integral values must remain within the exact integer range.', 'app-note'),
    message(),
    el('div', 'history-toolbar', { class: 'app-toolbar' }, [
      text('h3', 'history-title', 'Local history', 'section-title'), button('clear-history', 'Clear history', 'calculator.clear')
    ]),
    table.tree, text('p', 'history-note', '', 'app-note')
  ]);
  app.cleanup.push(os.observe(() => { schedule().catch(() => {}); }));
  await schedule();
  return app;
}
