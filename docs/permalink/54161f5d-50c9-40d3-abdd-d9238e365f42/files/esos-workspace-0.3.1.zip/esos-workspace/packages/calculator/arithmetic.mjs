export class CalculationError extends Error {
  constructor(message) { super(message); this.name = 'CalculationError'; this.code = 'E_CALCULATOR'; }
}
const fail = message => { throw new CalculationError(message); };
const number = value => {
  if (!Number.isFinite(value)) fail('This calculation does not have a finite result.');
  if (Number.isInteger(value) && !Number.isSafeInteger(value)) fail('This integral result exceeds JavaScript’s exact integer range.');
  return Object.is(value, -0) ? 0 : value;
};

/** A bounded arithmetic grammar. No expression is evaluated as JavaScript. */
export function calculate(source) {
  if (typeof source !== 'string' || !source.trim() || source.length > 512) fail('Enter an arithmetic expression of 1–512 characters.');
  const input = source.trim(), tokens = [];
  const token = /(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?|[()+\-*/%^]/iy;
  let offset = 0;
  while (offset < input.length) {
    if (/\s/.test(input[offset])) { offset++; continue; }
    token.lastIndex = offset;
    const match = token.exec(input);
    if (!match) fail('Unexpected character at position ' + (offset + 1) + '. Use numbers and + − * / % ^ ( ).');
    tokens.push(match[0]); offset = token.lastIndex;
    if (tokens.length > 128) fail('An expression supports at most 128 tokens.');
  }
  let index = 0, depth = 0;
  const peek = () => tokens[index];
  function nested(action) {
    if (++depth > 32) fail('An expression is nested too deeply.');
    try { return action(); } finally { depth--; }
  }
  function primary() {
    if (peek() === '(') {
      index++; const value = nested(sum);
      if (tokens[index++] !== ')') fail('A closing parenthesis is missing.');
      return value;
    }
    const value = tokens[index++];
    if (value === undefined || !/^(?:\d|\.)/.test(value)) fail('A number or parenthesized expression is required.');
    return number(Number(value));
  }
  function power() {
    const left = primary();
    if (peek() !== '^') return left;
    index++; return number(left ** nested(unary));
  }
  function unary() {
    if (peek() === '+' || peek() === '-') {
      const sign = tokens[index++] === '-' ? -1 : 1;
      return number(sign * nested(unary));
    }
    return power();
  }
  function product() {
    let result = unary();
    while (['*', '/', '%'].includes(peek())) {
      const op = tokens[index++], right = unary();
      if ((op === '/' || op === '%') && right === 0) fail('Division or remainder by zero is undefined.');
      result = number(op === '*' ? result * right : op === '/' ? result / right : result % right);
    }
    return result;
  }
  function sum() {
    let result = product();
    while (peek() === '+' || peek() === '-') {
      const op = tokens[index++], right = product();
      result = number(op === '+' ? result + right : result - right);
    }
    return result;
  }
  const result = sum();
  if (index !== tokens.length) fail('Unexpected token: ' + tokens[index] + '. Insert an operator between values.');
  return { expression: input, result: number(result) };
}
