import { createWorkflowRuntime } from './runtime.mjs';
import { validateWorkflow } from './catalog.mjs';

const cut = (value, limit = 60000) => {
  let text = String(value);
  if (text.length <= limit) return text;
  text = text.slice(0, limit);
  if (/[\uD800-\uDBFF]/.test(text.at(-1))) text = text.slice(0, -1);
  return text + '\n…';
};
const describeError = error => (error?.code ? error.code + ' · ' : '') + (error?.message ?? String(error));

/** Shared, editor-independent run controls for Automate and published programs. */
export function createWorkflowRunView({ app, os, components, projects = os.projects, prefix = 'flow-run', onStateChange } = {}) {
  const { element: el, text, button, submitButton, form, field } = components;
  const runtime = createWorkflowRuntime({ os });
  const node = suffix => prefix + '-' + suffix;
  const action = suffix => prefix + '.' + suffix;
  let active = null, input = null, lastResult = null, captured = [], resultText = '', resultCount = 0, diagnosticLines = [];
  let stepsMounted = false;
  const set = (suffix, values) => app.disposed ? Promise.resolve() : app.ui.set(node(suffix), values);
  async function status(message, failure = false) {
    await set('status', { text: cut(message, 2000), class: 'flow-run-status' + (failure ? ' failure' : '') });
  }
  const tree = el('section', node('panel'), { class: 'flow-run-panel', attrs: { 'aria-label': 'Workflow run' } }, [
    el('div', node('toolbar'), { class: 'app-toolbar flow-run-toolbar' }, [
      text('h3', node('heading'), 'Run and results'),
      button(node('run'), 'Run workflow', action('run'), {}, 'btn-solid theme-primary btn-sm'),
      { ...button(node('cancel'), 'Cancel', action('cancel')), props: { disabled: true } }
    ]),
    text('p', node('status'), 'Ready. Running a workflow may create files or tasks.', 'flow-run-status'),
    el('div', node('steps'), { class: 'flow-run-steps', attrs: { 'aria-label': 'Action progress' } }),
    el('section', node('input'), { class: 'flow-run-input', props: { hidden: true } }, [
      text('h4', node('question'), 'Input'),
      form(node('input-form'), { action: action('input'), fields: ['value', 'token'] }, [
        el('input', node('input-token'), { attrs: { type: 'hidden', name: 'token' }, props: { value: '' } }),
        field(node('input-value'), { label: 'Your text', name: 'value', multiline: true,
          attrs: { rows: '4', maxlength: '65536' }, value: '' }),
        submitButton(node('input-continue'), 'Continue', 'btn-solid theme-primary btn-sm')
      ])
    ]),
    el('details', node('results-details'), { props: { open: true } }, [
      text('summary', node('results-summary'), 'Output records'),
      text('p', node('record-count'), 'No results yet.', 'app-note'),
      text('pre', node('results'), '', 'flow-record-output'),
      form(node('save-form'), { action: action('save-results'), fields: ['path'], className: 'flow-result-save' }, [
        field(node('result-path'), { label: 'Save captured results as NDJSON', name: 'path',
          value: '/home/' + os.profile.username + '/workflow-results.ndjson', attrs: { maxlength: '1024', required: '' } }),
        { ...submitButton(node('save-results'), 'Save new results file', 'btn-outline theme-secondary btn-sm'), props: { disabled: true } }
      ])
    ]),
    el('details', node('diagnostic-details'), {}, [
      text('summary', node('diagnostic-summary'), 'Diagnostics and committed effects'),
      text('pre', node('diagnostics'), '', 'flow-record-output')
    ]),
    text('p', node('effect-note'), 'Cancel stops further work. Completed file writes and tasks remain; a failed run never retries them automatically.', 'app-note')
  ]);
  async function requestInput(request) {
    request.signal.throwIfAborted();
    const token = crypto.randomUUID();
    await app.ui.send([
      { op: 'set', id: node('question'), text: request.prompt },
      { op: 'set', id: node('input-token'), props: { value: token } },
      { op: 'set', id: node('input-value'), props: { value: request.defaultValue } },
      { op: 'set', id: node('input'), props: { hidden: false } }
    ]);
    request.signal.throwIfAborted();
    app.container.querySelector('[name="value"]')?.focus({ preventScroll: true });
    let abort;
    try {
      return await new Promise((resolve, reject) => {
        abort = () => reject(request.signal.reason ?? new DOMException('Cancelled', 'AbortError'));
        input = { token, resolve, reject };
        request.signal.addEventListener('abort', abort, { once: true });
        if (request.signal.aborted) abort();
      });
    } finally {
      request.signal.removeEventListener('abort', abort);
      if (input?.token === token) input = null;
      await set('input', { props: { hidden: true } });
    }
  }
  async function renderStepList(plan) {
    if (stepsMounted) await app.ui.send([{ op: 'remove', id: node('step-list') }]);
    await app.ui.tree(el('ol', node('step-list'), {}, plan.actions.map((step, index) =>
      text('li', node('step-' + index), step.definition.label + ' · waiting', 'flow-run-step'))), node('steps'));
    stepsMounted = true;
  }
  function start(project) {
    if (active) throw new Error('A workflow is already running in this window.');
    const snapshot = structuredClone(project), plan = validateWorkflow(snapshot);
    const job = { controller: new AbortController(), done: null };
    active = job; lastResult = null; captured = []; resultText = ''; resultCount = 0; diagnosticLines = [];
    job.done = (async () => {
      try {
        await onStateChange?.(true);
        await app.ui.send([
          { op: 'set', id: node('run'), props: { disabled: true } },
          { op: 'set', id: node('cancel'), props: { disabled: false } },
          { op: 'set', id: node('save-results'), props: { disabled: true } },
          { op: 'set', id: node('results'), text: '' },
          { op: 'set', id: node('diagnostics'), text: '' },
          { op: 'set', id: node('record-count'), text: 'Waiting for output…' }
        ]);
        await renderStepList(plan);
        await status('Running ' + snapshot.name + '…');
        lastResult = await runtime.run(snapshot, {
          signal: job.controller.signal, requestInput,
          async onRecord(record) {
            resultCount++;
            const line = JSON.stringify(record) + '\n';
            if (captured.length < 100 && resultText.length + line.length <= 48000) {
              captured.push(line); resultText += line;
              await set('results', { text: resultText });
            }
          },
          async onStep(step) {
            const index = plan.actions.findIndex(value => value.id === step.id);
            await set('step-' + index, { text: step.label + ' · ' + step.status.replaceAll('-', ' ') +
              (step.outputRecords ? ' · ' + step.outputRecords + ' output records' : ''),
              class: 'flow-run-step flow-step-' + step.status });
            if (step.status === 'waiting-input') await status('Waiting for your input.');
          },
          async onDiagnostic(record) {
            if (record.code?.startsWith('WORKFLOW_EFFECT_')) return;
            if (diagnosticLines.length < 100) diagnosticLines.push((record.index + 1) + '. ' + (record.code ?? record.level ?? 'info') + ' · ' + (record.message ?? ''));
            await set('diagnostics', { text: cut(diagnosticLines.join('\n')) });
          }
        });
        const committed = lastResult.effects.filter(effect => effect.status === 'committed').length;
        const unconfirmed = lastResult.effects.filter(effect => effect.status !== 'committed').length;
        const outcome = lastResult.status === 'ok' ? 'Finished' : lastResult.status === 'cancelled' ? 'Cancelled' : 'Stopped with an error';
        await status(outcome + ' · ' + resultCount + ' output records · ' + committed + ' committed effects' +
          (unconfirmed ? ' · ' + unconfirmed + ' unconfirmed operation receipts' : '') +
          (lastResult.error ? '. ' + describeError(lastResult.error) : '.'), lastResult.status === 'error');
        const ledger = lastResult.effects.map(effect => effect.status.toUpperCase() + ' · ' + effect.kind + ' · ' + effect.target +
          '\n  Operation ' + effect.operationId + (effect.revision === undefined ? '' : ' · revision ' + effect.revision));
        await set('diagnostics', { text: cut([...diagnosticLines, ...ledger].join('\n')) });
        return lastResult;
      } catch (error) {
        await status(describeError(error), true);
        return { status: 'error', exitCode: 1, error: { message: describeError(error) } };
      } finally {
        active = null;
        if (!app.disposed) {
          await app.ui.send([
            { op: 'set', id: node('run'), props: { disabled: false } },
            { op: 'set', id: node('cancel'), props: { disabled: true } },
            { op: 'set', id: node('save-results'), props: { disabled: captured.length === 0 } },
            { op: 'set', id: node('input'), props: { hidden: true } },
            { op: 'set', id: node('record-count'), text: captured.length + ' captured of ' + resultCount + ' output records.' +
              (captured.length < resultCount ? ' The preview keeps up to 100 complete records / 48,000 characters. Add Save text to a file to retain a larger output.' : '') }
          ]);
          await onStateChange?.(false);
        }
      }
    })();
    // The button handler must return promptly so Cancel and Continue can dispatch.
    job.done.catch(() => {});
    return job.done;
  }
  async function stop() {
    const job = active;
    if (!job) return lastResult;
    job.controller.abort(new DOMException('Stopped by user', 'AbortError'));
    return job.done;
  }
  async function handleIntent(intent) {
    if (intent.action === action('cancel')) {
      if (active) { active.controller.abort(new DOMException('Stopped by user', 'AbortError')); await status('Stopping. Waiting for in-flight operations to settle…'); }
      return true;
    }
    if (intent.action === action('input')) {
      if (!input || intent.fields.token !== input.token) throw new Error('This input belongs to an earlier run.');
      input.resolve(intent.fields.value); await status('Running…'); return true;
    }
    if (intent.action === action('save-results')) {
      if (active || !captured.length) throw new Error('Finish a run with captured records before saving its results.');
      const path = projects.resolvePath(intent.fields.path);
      const saved = await os.vfs.write(path, captured.join(''), { expectedRevision: 0, operationId: intent.eventId });
      await status('Captured results saved to ' + saved.path + ' · revision ' + saved.revision + '.');
      return true;
    }
    return false;
  }
  return Object.freeze({ tree, start, stop, handleIntent, runAction: action('run'),
    get running() { return Boolean(active); }, get result() { return lastResult; }, dispose: stop });
}

export async function buildWorkflowProgram(ctx, options = {}) {
  const { frame, os, components, projects = os.projects, helpers = {} } = ctx;
  const project = projects.validate(options.project, 'workflow');
  validateWorkflow(project);
  const { element: el, text } = components;
  let app, view;
  app = frame(options.application ?? 'workflow', project.name, async intent => {
    try {
      if (intent.action === view.runAction) { view.start(project); return; }
      await view.handleIntent(intent);
    } catch (error) { await app.say(describeError(error), true); }
  });
  view = createWorkflowRunView({ app, os, components, projects });
  await app.ui.tree([
    el('header', 'workflow-heading', { class: 'app-heading' }, [
      text('p', 'workflow-eyebrow', 'WORKFLOW PROGRAM', 'app-eyebrow'),
      text('h2', 'workflow-title', project.name),
      text('p', 'workflow-description', project.description || 'A local workflow made from small commands.', 'app-description')
    ]),
    view.tree,
    helpers.message?.() ?? el('p', 'message', { class: 'inline-message', attrs: { role: 'status', 'aria-live': 'polite' } })
  ]);
  app.beforeClose = async () => { await view.stop(); return true; };
  app.chrome = project.presentation?.chrome ?? true;
  app.preferredMode = project.presentation?.maximized ? 'maximized' : 'normal';
  app.appMode = true;
  app.cleanup.push(() => view.dispose());
  app.sessionOptions = () => (options.path ? { path: options.path } : {});
  app.resourcePath = () => options.path ?? null;
  return app;
}
