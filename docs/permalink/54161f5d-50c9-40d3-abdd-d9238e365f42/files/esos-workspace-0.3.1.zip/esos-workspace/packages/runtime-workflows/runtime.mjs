import { WorkflowError, validateWorkflow, commandFor, getActionCatalog, MAX_STAGE_RECORDS, MAX_EFFECTS } from './catalog.mjs';

const encoder = new TextEncoder();
const errorValue = error => ({ code: error?.code ?? 'E_WORKFLOW', message: error?.message?.slice(0, 1000) ?? 'The workflow failed.' });
const cancelled = () => new DOMException('Workflow cancelled', 'AbortError');
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const recordBytes = value => encoder.encode(JSON.stringify(value)).byteLength + 1;
function checkRecord(record, type, label) {
  let valid = plain(record);
  if (type === 'text' || type === 'text-lines') valid &&= typeof record.text === 'string';
  else if (type === 'files') valid &&= typeof record.path === 'string' && ['file', 'directory', 'device'].includes(record.kind);
  else if (type === 'tasks') valid &&= record.kind === 'task' && typeof record.id === 'string' && typeof record.title === 'string' && typeof record.done === 'boolean';
  else if (type === 'receipt') valid &&= typeof record.kind === 'string' && typeof record.operationId === 'string';
  if (!valid) throw new WorkflowError('E_INPUT_SCHEMA', label + ' received a record incompatible with ' + type + '.');
}
function waitForInput(callback, request, signal) {
  if (typeof callback !== 'function') return Promise.reject(new WorkflowError('E_INTERACTION_REQUIRED', 'Run this workflow in a window that can ask for text.'));
  let abort;
  return new Promise((resolve, reject) => {
    abort = () => reject(signal.reason ?? cancelled());
    signal.addEventListener('abort', abort, { once: true });
    if (signal.aborted) abort();
    else Promise.resolve().then(() => callback({ ...request, signal })).then(resolve, reject);
  }).finally(() => signal.removeEventListener('abort', abort));
}

/**
 * All executable stages use the host command service. It encodes and decodes the
 * strict object-NDJSON profile at each invocation boundary. This intermediate
 * queue holds records under byte-counted Web Streams backpressure; no stage
 * accumulates the entire output of a preceding stage.
 */
export function createWorkflowRuntime({ os } = {}) {
  if (!os?.commands?.invoke) throw new TypeError('The workflow runtime needs os.commands.invoke.');
  async function run(project, { signal, onRecord, onDiagnostic, onStep, requestInput } = {}) {
    const plan = validateWorkflow(project);
    for (const callback of [onRecord, onDiagnostic, onStep, requestInput]) {
      if (callback !== undefined && typeof callback !== 'function') throw new TypeError('Workflow callbacks must be functions.');
    }
    // Resolve the complete command vocabulary before starting interactive or effectful work.
    if (os.commands.inspect) for (const command of new Set(plan.actions.map(step => step.definition.command))) await os.commands.inspect(command);
    const id = 'flow:' + crypto.randomUUID(), startedAt = new Date().toISOString();
    const controller = new AbortController(), cancellation = controller.signal;
    const steps = plan.actions.map(step => ({ id: step.id, action: step.action, label: step.definition.label,
      status: 'pending', inputRecords: 0, outputRecords: 0 }));
    const diagnostics = [], effects = new Map();
    let firstFailure = null, outputRecords = 0;
    const pipes = plan.actions.map(() => {
      const stream = new TransformStream(undefined, { highWaterMark: 1 }, { highWaterMark: 65536, size: recordBytes });
      return { reader: stream.readable.getReader(), writer: stream.writable.getWriter() };
    });
    const abortTasks = [];
    const stopStreams = () => {
      const reason = cancellation.reason ?? cancelled();
      for (const pipe of pipes) {
        abortTasks.push(pipe.reader.cancel(reason).catch(() => {}), pipe.writer.abort(reason).catch(() => {}));
      }
    };
    const externalAbort = () => controller.abort(signal.reason ?? cancelled());
    cancellation.addEventListener('abort', stopStreams, { once: true });
    signal?.addEventListener('abort', externalAbort, { once: true });
    if (signal?.aborted) externalAbort();
    const notifyStep = async index => { await onStep?.(structuredClone(steps[index])); };
    const diagnostic = async (record, step) => {
      const value = { ...record, actionId: step.id, action: step.action, index: step.index };
      if (record.code === 'WORKFLOW_EFFECT_PENDING' || record.code === 'WORKFLOW_EFFECT_COMMITTED') {
        const receipt = record.effect;
        if (!plain(receipt) || typeof receipt.operationId !== 'string') throw new WorkflowError('E_EFFECT_RECEIPT', 'An effect has no operation receipt.');
        const previous = effects.get(receipt.operationId);
        if (!previous && effects.size >= MAX_EFFECTS) throw new WorkflowError('E_EFFECT_LIMIT', 'This run reached its ' + MAX_EFFECTS + '-effect limit.');
        effects.set(receipt.operationId, { ...previous, ...receipt, actionId: step.id,
          status: record.code === 'WORKFLOW_EFFECT_COMMITTED' ? 'committed' : previous?.status ?? 'pending' });
      }
      if (diagnostics.length < 100 && !record.code?.startsWith('WORKFLOW_EFFECT_')) diagnostics.push(value);
      await onDiagnostic?.(value);
    };
    const fail = (error, step) => {
      if (!firstFailure && !signal?.aborted) firstFailure = { ...errorValue(error), ...(step ? { actionId: step.id, action: step.action } : {}) };
      if (!cancellation.aborted) controller.abort(error);
    };
    function input(index) {
      if (!index) return (async function* () {})();
      const reader = pipes[index - 1].reader;
      return {
        [Symbol.asyncIterator]() { return this; },
        async next() {
          cancellation.throwIfAborted();
          const item = await reader.read();
          cancellation.throwIfAborted();
          if (!item.done) {
            checkRecord(item.value, plan.actions[index].input, steps[index].label);
            if (++steps[index].inputRecords > MAX_STAGE_RECORDS) throw new WorkflowError('E_RECORD_LIMIT', 'An action received too many records.');
          }
          return item;
        },
        async return() {
          await reader.cancel(new WorkflowError('E_WORKFLOW_DOWNSTREAM', 'The following action stopped accepting input.'));
          return { done: true, value: undefined };
        }
      };
    }
    const consume = (async () => {
      const reader = pipes.at(-1).reader;
      try {
        while (true) {
          cancellation.throwIfAborted();
          const item = await reader.read();
          if (item.done) break;
          cancellation.throwIfAborted();
          outputRecords++;
          await onRecord?.(item.value);
        }
      } catch (error) { if (!cancellation.aborted) fail(error); }
    })();
    const running = plan.actions.map(async (step, index) => {
      const status = steps[index], writer = pipes[index].writer;
      try {
        cancellation.throwIfAborted();
        status.status = step.definition.interactive ? 'waiting-input' : 'running';
        await notifyStep(index);
        let enteredText;
        if (step.definition.interactive) {
          enteredText = await waitForInput(requestInput, { actionId: step.id, label: step.definition.label,
            prompt: step.parameters.prompt, defaultValue: step.parameters.defaultValue, maxLength: 65536 }, cancellation);
          cancellation.throwIfAborted();
          if (enteredText === null) throw cancelled();
          if (typeof enteredText !== 'string' || enteredText.length > 65536 || !enteredText.isWellFormed()) throw new WorkflowError('E_WORKFLOW_INPUT', 'Enter valid text of at most 65,536 characters.');
          status.status = 'running'; await notifyStep(index);
        }
        const [command, args] = commandFor(step, id, enteredText);
        const result = await os.commands.invoke(command, args, {
          stdin: input(index), signal: cancellation,
          async onRecord(record) {
            cancellation.throwIfAborted();
            checkRecord(record, step.output, step.definition.label);
            if (++status.outputRecords > MAX_STAGE_RECORDS) throw new WorkflowError('E_RECORD_LIMIT', 'An action produced too many records.');
            await writer.write(record);
          },
          onDiagnostic: record => diagnostic(record, step)
        });
        if (result?.status === 'ok' && !cancellation.aborted) {
          await writer.close(); status.status = 'succeeded';
        } else if (result?.error?.code === 'E_WORKFLOW_DOWNSTREAM' && !cancellation.aborted) {
          // Wait for the downstream action's authoritative error. Its deliberate
          // input closure must not replace the cause with an upstream pipe error.
          status.status = 'cancelled';
        } else if (cancellation.aborted || result?.status === 'cancelled') {
          status.status = 'cancelled';
          if (!cancellation.aborted) controller.abort(cancelled());
        } else {
          const error = new WorkflowError(result?.error?.code ?? 'E_COMMAND', result?.error?.message ?? 'The action failed.');
          status.status = 'failed'; status.error = errorValue(error); fail(error, step);
        }
      } catch (error) {
        const isCancellation = cancellation.aborted || error?.name === 'AbortError';
        status.status = isCancellation ? 'cancelled' : 'failed';
        if (!isCancellation) { status.error = errorValue(error); fail(error, step); }
        else if (!cancellation.aborted) controller.abort(error);
      } finally {
        try { await notifyStep(index); } catch (error) { if (!cancellation.aborted) fail(error, step); }
      }
    });
    try {
      await Promise.all(running);
      await consume;
      await Promise.all(abortTasks);
      // A cancellation may occur after a service committed but before its output
      // receipt was accepted. Query announced operation IDs once; never retry I/O.
      for (const effect of effects.values()) {
        if (effect.status === 'committed') continue;
        try {
          if (!os.vfs?.getOperationStatus) throw new Error('Operation lookup is unavailable.');
          const receipt = await os.vfs.getOperationStatus(effect.operationId);
          effect.status = receipt.status === 'committed' ? 'committed' : 'unconfirmed';
          const revision = receipt.result?.revision ?? receipt.revision;
          if (Number.isSafeInteger(revision)) effect.revision = revision;
        } catch { effect.status = 'unconfirmed'; }
      }
      const status = firstFailure ? 'error' : cancellation.aborted ? 'cancelled' : 'ok';
      return { id, status, exitCode: status === 'ok' ? 0 : status === 'cancelled' ? 130 : 1,
        startedAt, finishedAt: new Date().toISOString(), outputRecords,
        steps: structuredClone(steps), effects: [...effects.values()], diagnostics,
        ...(firstFailure ? { error: firstFailure } : {}) };
    } finally {
      signal?.removeEventListener('abort', externalAbort);
      cancellation.removeEventListener('abort', stopStreams);
      for (const pipe of pipes) { pipe.reader.releaseLock(); pipe.writer.releaseLock(); }
    }
  }
  return Object.freeze({ catalog: getActionCatalog, validate: validateWorkflow, run });
}
