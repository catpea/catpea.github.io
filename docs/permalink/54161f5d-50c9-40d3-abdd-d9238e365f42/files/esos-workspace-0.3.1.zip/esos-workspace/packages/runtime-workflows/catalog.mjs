export const WORKFLOW_VERSION = 1;
export const MAX_ACTIONS = 24;
export const MAX_TEXT_BYTES = 1024 * 1024;
export const MAX_STAGE_RECORDS = 10000;
export const MAX_EFFECTS = 200;

export class WorkflowError extends Error {
  constructor(code, message, details) {
    super(message); this.name = 'WorkflowError'; this.code = code;
    if (details !== undefined) this.details = details;
  }
}
const fail = (code, message) => { throw new WorkflowError(code, message); };
const field = (name, label, defaultValue = '', options = {}) => ({ name, label, type: 'text', defaultValue, maxLength: 4096, ...options });
const choice = (name, label, values, defaultValue) => field(name, label, defaultValue, {
  type: 'select', options: values.map(([value, label]) => ({ value, label }))
});
const definitions = [
  { id: 'input.text', label: 'Ask for text', category: 'Input', command: 'echo', input: 'none', output: 'text', interactive: true,
    description: 'Pause for a person to enter text when the workflow runs.',
    parameters: [field('prompt', 'Question', 'What would you like to work with?', { required: true, maxLength: 240 }),
      field('defaultValue', 'Starting text', '', { type: 'multiline', maxLength: 65536 })] },
  { id: 'text.literal', label: 'Text', category: 'Input', command: 'echo', input: 'none', output: 'text',
    description: 'Start with the text entered here.',
    parameters: [field('text', 'Text', 'Hello from Automate', { type: 'multiline', maxLength: 65536 })] },
  { id: 'files.list', label: 'List a folder', category: 'Files', command: 'ls', input: 'none', output: 'files',
    description: 'List files and folders at a local path.',
    parameters: [field('path', 'Folder', '~', { required: true })] },
  { id: 'files.find', label: 'Find files', category: 'Files', command: 'find', input: 'none', output: 'files',
    description: 'Find up to 100 local files and folders by a name or path fragment.',
    parameters: [field('query', 'Name or path contains', '.txt', { required: true, maxLength: 128 })] },
  { id: 'files.read', label: 'Read a file', category: 'Files', command: 'cat', input: 'none', output: 'text',
    description: 'Read a local file as ordered text records.',
    parameters: [field('path', 'File', '~/notes.txt', { required: true })] },
  { id: 'files.read-each', label: 'Read each file', category: 'Files', command: 'flow', input: 'files', output: 'text',
    description: 'Read incoming files in order; skip folder and device entries.', parameters: [] },
  { id: 'text.transform', label: 'Transform text', category: 'Text', command: 'flow', input: 'text', output: 'text',
    description: 'Combine up to 1 MiB of text, then transform it as one document.',
    parameters: [choice('mode', 'Transformation', [['uppercase', 'UPPERCASE'], ['lowercase', 'lowercase'], ['trim', 'Trim outer whitespace']], 'uppercase')] },
  { id: 'text.replace', label: 'Replace text', category: 'Text', command: 'flow', input: 'text', output: 'text',
    description: 'Replace every literal occurrence in up to 1 MiB of combined text.',
    parameters: [field('find', 'Find', '', { required: true, maxLength: 4096 }), field('replacement', 'Replace with', '', { maxLength: 4096 })] },
  { id: 'text.lines', label: 'Split into lines', category: 'Text', command: 'flow', input: 'text', output: 'text-lines',
    description: 'Emit one text record per line, without its line ending. Blank lines are kept.', parameters: [] },
  { id: 'records.where', label: 'Keep matching records', category: 'Records', command: 'where', input: 'any', output: 'same',
    description: 'Keep records whose named field equals text, a number, true, false, or null.',
    parameters: [field('field', 'Field', 'done', { required: true, maxLength: 128 }),
      field('value', 'Equals', 'false', { maxLength: 4096, hint: 'Use false for open tasks; use a quoted JSON string when text resembles a number.' })] },
  { id: 'records.field', label: 'Use a field as text', category: 'Records', command: 'flow', input: 'any', output: 'text',
    description: 'Emit a named text field from each record, followed by a line ending.',
    parameters: [field('field', 'Text field', 'title', { required: true, maxLength: 128 })] },
  { id: 'records.ndjson', label: 'Convert records to NDJSON', category: 'Records', command: 'flow', input: 'any', output: 'text',
    description: 'Turn each object into one JSON text line for saving or sharing.', parameters: [] },
  { id: 'files.write', label: 'Save text to a file', category: 'Files', command: 'flow', input: 'text', output: 'receipt', effects: 'file-write',
    description: 'Save up to 1 MiB. Creating refuses an existing file; replacement checks its opened revision.',
    parameters: [field('path', 'Destination file', '~/output.txt', { required: true }),
      choice('mode', 'When saving', [['create', 'Create a new file'], ['replace', 'Replace the current file revision']], 'create'),
      choice('separator', 'Between text records', [['none', 'Nothing (preserve text chunks)'], ['newline', 'A line ending']], 'none')] },
  { id: 'tasks.list', label: 'Get tasks', category: 'Tasks', command: 'tasks', input: 'none', output: 'tasks',
    description: 'Read the current task list as records.', parameters: [] },
  { id: 'tasks.add', label: 'Create tasks from text', category: 'Tasks', command: 'flow', input: 'text', output: 'receipt', effects: 'task-add',
    description: 'Create one task per nonblank text record (up to 240 characters each). Use Split into lines first for a list.', parameters: [] }
];
function freeze(value) {
  if (value && typeof value === 'object') { Object.values(value).forEach(freeze); Object.freeze(value); }
  return value;
}
export const workflowActions = freeze(definitions.map(value => ({
  version: 1, effects: 'none', interactive: false, streamMode: 'ordered', cancellation: 'cooperative', retry: 'never', ...value
})));
const catalog = new Map(workflowActions.map(value => [value.id, value]));
export const getActionCatalog = () => structuredClone(workflowActions);
export const actionDefinition = id => catalog.get(id) ?? null;
export const defaultParameters = id => {
  const definition = catalog.get(id);
  if (!definition) fail('E_WORKFLOW_ACTION', 'Unknown action: ' + String(id));
  return Object.fromEntries(definition.parameters.map(parameter => [parameter.name, parameter.defaultValue]));
};
function plain(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) &&
    [Object.prototype, null].includes(Object.getPrototypeOf(value));
}
export function validateParameters(id, supplied = {}) {
  const definition = catalog.get(id);
  if (!definition) fail('E_WORKFLOW_ACTION', 'Unknown action: ' + String(id));
  if (!plain(supplied)) fail('E_WORKFLOW_PARAMETERS', definition.label + ' needs a parameter object.');
  const names = new Set(definition.parameters.map(value => value.name));
  for (const name of Object.keys(supplied)) if (!names.has(name)) fail('E_WORKFLOW_PARAMETERS', definition.label + ': unknown parameter ' + name + '.');
  const result = {};
  for (const parameter of definition.parameters) {
    const value = supplied[parameter.name] ?? parameter.defaultValue;
    if (typeof value !== 'string' || value.length > parameter.maxLength || !value.isWellFormed() ||
        (parameter.required && !value.trim())) fail('E_WORKFLOW_PARAMETERS', definition.label + ': enter a valid ' + parameter.label.toLowerCase() + '.');
    if (parameter.options && !parameter.options.some(option => option.value === value)) fail('E_WORKFLOW_PARAMETERS', definition.label + ': unsupported ' + parameter.label.toLowerCase() + '.');
    result[parameter.name] = value;
  }
  if (id === 'records.where') {
    let value; try { value = JSON.parse(result.value); } catch { value = result.value; }
    if (value !== null && !['string', 'boolean', 'number'].includes(typeof value)) fail('E_WORKFLOW_PARAMETERS', 'Comparison values must be text, a number, true, false, or null.');
    if (typeof value === 'number' && (!Number.isFinite(value) || Number.isInteger(value) && !Number.isSafeInteger(value))) fail('E_WORKFLOW_PARAMETERS', 'The comparison number cannot be represented exactly.');
  }
  return result;
}
export function validateWorkflow(project) {
  if (!plain(project) || project.format !== 'esos.project' || project.version !== 1 || project.kind !== 'workflow') fail('E_WORKFLOW_FORMAT', 'Open an eSOS version 1 workflow project.');
  if (typeof project.id !== 'string' || !project.id || typeof project.name !== 'string' || !project.name.trim()) fail('E_WORKFLOW_FORMAT', 'A workflow needs a project identity and name.');
  if (!plain(project.workflow) || project.workflow.version !== WORKFLOW_VERSION || !Array.isArray(project.workflow.actions)) fail('E_WORKFLOW_VERSION', 'This workflow runtime supports workflow version 1.');
  const actions = project.workflow.actions;
  if (!actions.length || actions.length > MAX_ACTIONS) fail('E_WORKFLOW_LIMIT', 'A workflow needs 1–' + MAX_ACTIONS + ' actions.');
  const seen = new Set(), plan = [];
  let previous = 'none';
  for (const [index, instance] of actions.entries()) {
    if (!plain(instance) || typeof instance.id !== 'string' || !/^[A-Za-z][A-Za-z0-9_-]{0,63}$/.test(instance.id) || seen.has(instance.id)) fail('E_WORKFLOW_ID', 'Every action needs a distinct, stable identity of at most 64 letters, digits, underscores, or hyphens.');
    seen.add(instance.id);
    if (Object.keys(instance).some(key => !['id', 'action', 'parameters'].includes(key))) fail('E_WORKFLOW_ACTION', 'An action contains an unsupported field.');
    const definition = catalog.get(instance.action);
    if (!definition) fail('E_WORKFLOW_ACTION', 'Action ' + (index + 1) + ' is unavailable: ' + String(instance.action) + '.');
    const parameters = validateParameters(instance.action, instance.parameters);
    const compatible = definition.input === 'none' ? index === 0
      : previous !== 'none' && (definition.input === 'any' || previous === definition.input || definition.input === 'text' && previous === 'text-lines');
    if (!compatible) fail('E_WORKFLOW_COMPATIBILITY', 'Action ' + (index + 1) + ' (' + definition.label + ') needs ' + definition.input + '; the preceding action provides ' + previous + '.');
    const output = definition.output === 'same' ? previous : definition.output;
    plan.push({ id: instance.id, action: instance.action, parameters, definition, index, input: previous, output });
    previous = output;
  }
  return { version: WORKFLOW_VERSION, actions: plan, output: previous, effects: plan.filter(value => value.definition.effects !== 'none').map(value => value.id) };
}

/** Arguments are separate strings; none is parsed as shell syntax. */
export function commandFor(step, runId, enteredText) {
  const p = step.parameters;
  const operation = runId + ':' + step.index;
  switch (step.action) {
    case 'input.text': return ['echo', [JSON.stringify({ text: enteredText })]];
    case 'text.literal': return ['echo', [JSON.stringify({ text: p.text })]];
    case 'files.list': return ['ls', [p.path]];
    case 'files.find': return ['find', [p.query]];
    case 'files.read': return ['cat', [p.path]];
    case 'files.read-each': return ['flow', ['read']];
    case 'text.transform': return ['flow', ['text', p.mode]];
    case 'text.replace': return ['flow', ['replace', p.find, p.replacement]];
    case 'text.lines': return ['flow', ['lines']];
    case 'records.where': return ['where', [p.field, p.value]];
    case 'records.field': return ['flow', ['field', p.field]];
    case 'records.ndjson': return ['flow', ['ndjson']];
    case 'files.write': return ['flow', ['write', p.path, p.mode, p.separator, operation]];
    case 'tasks.list': return ['tasks', ['list']];
    case 'tasks.add': return ['flow', ['tasks-add', operation]];
    default: fail('E_WORKFLOW_ACTION', 'Unsupported action.');
  }
}
