import { WorkflowError, MAX_TEXT_BYTES, MAX_EFFECTS, MAX_STAGE_RECORDS } from './catalog.mjs';

export const name = 'flow';
export const summary = 'Typed text, file, and task actions for workflows.';
export const usage = 'flow text MODE | replace FIND REPLACEMENT | lines | field NAME | ndjson | read | write PATH create|replace none|newline [OPERATION-ID] | tasks-add [OPERATION-PREFIX]';
const encoder = new TextEncoder();
const fail = (code, message) => { throw new WorkflowError(code, message); };
const check = ctx => ctx.signal?.throwIfAborted();
function textValue(value) {
  if (typeof value !== 'string') fail('E_INPUT_SCHEMA', 'This action expects records with a text string.');
  return value;
}
function operationId(value) {
  const id = value ?? 'flow:' + crypto.randomUUID();
  if (typeof id !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:/-]{0,99}$/.test(id)) fail('E_OPERATION_ID', 'Use an operation identity of at most 100 supported characters.');
  return id;
}
function ordinaryPath(value, os) {
  if (typeof value !== 'string' || !value.trim() || value.length > 4096 || /[\u0000-\u001f]/.test(value)) fail('E_PATH', 'Enter an ordinary local file path.');
  const home = '/home/' + os.profile.username;
  const source = value === '~' ? home : value.startsWith('~/') ? home + value.slice(1) : value.startsWith('/') ? value : home + '/' + value;
  const parts = [];
  for (const part of source.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') { if (!parts.length) fail('E_PATH', 'The path escapes the root.'); parts.pop(); }
    else parts.push(part);
  }
  const path = '/' + parts.join('/');
  if (['dev', 'sys', 'proc'].includes(parts[0])) fail('E_PATH', 'Save text to an ordinary file, not a system device or status path.');
  return path;
}
async function collectText(ctx, separator = '') {
  const pieces = [];
  let bytes = 0, count = 0;
  for await (const record of ctx.stdin) {
    check(ctx);
    const text = textValue(record.text);
    bytes += encoder.encode(text).byteLength + (count ? encoder.encode(separator).byteLength : 0);
    if (bytes > MAX_TEXT_BYTES) fail('E_TEXT_LIMIT', 'This action accepts up to 1 MiB of combined text.');
    if (++count > MAX_STAGE_RECORDS) fail('E_RECORD_LIMIT', 'This action received too many records.');
    pieces.push(text);
  }
  return pieces.join(separator);
}
async function emitText(ctx, text, metadata = {}) {
  if (encoder.encode(text).byteLength > MAX_TEXT_BYTES) fail('E_TEXT_LIMIT', 'The transformed text exceeds 1 MiB.');
  let start = 0, part = 0;
  do {
    check(ctx);
    let end = Math.min(start + 16384, text.length);
    if (end < text.length && /[\uD800-\uDBFF]/.test(text[end - 1]) && /[\uDC00-\uDFFF]/.test(text[end])) end--;
    await ctx.stdout.write({ ...metadata, text: text.slice(start, end), part: part++, final: end === text.length });
    start = end;
  } while (start < text.length);
}
async function effect(ctx, code, value) {
  await ctx.stderr.write({ level: 'info', code, effect: value });
}

/** Commands own domain work. The editor supplies only typed parameters and streams. */
export async function run(ctx) {
  const args = ctx.args ?? [];
  if (!Array.isArray(args) || args.length > 8 || args.some(value => typeof value !== 'string')) fail('E_USAGE', 'Usage: ' + usage);
  const [action, ...values] = args;
  const os = ctx.os ?? ctx.capabilities?.os;
  const count = (min, max = min) => { if (values.length < min || values.length > max) fail('E_USAGE', 'Usage: ' + usage); };
  check(ctx);
  if (action === 'text') {
    count(1);
    if (!['uppercase', 'lowercase', 'trim'].includes(values[0])) fail('E_USAGE', 'Text transformation must be uppercase, lowercase, or trim.');
    const text = await collectText(ctx);
    await emitText(ctx, values[0] === 'uppercase' ? text.toUpperCase() : values[0] === 'lowercase' ? text.toLowerCase() : text.trim());
  } else if (action === 'replace') {
    count(2);
    if (!values[0] || values.some(value => value.length > 4096)) fail('E_USAGE', 'Enter a nonempty literal to find and a replacement of at most 4,096 characters.');
    const text = await collectText(ctx);
    // Bound expansion before allocating a potentially much larger replacement string.
    let occurrences = 0, offset = 0;
    while ((offset = text.indexOf(values[0], offset)) !== -1) { occurrences++; offset += values[0].length; }
    const expandedBytes = encoder.encode(text).byteLength + occurrences * (encoder.encode(values[1]).byteLength - encoder.encode(values[0]).byteLength);
    if (expandedBytes > MAX_TEXT_BYTES) fail('E_TEXT_LIMIT', 'The replacement would exceed 1 MiB.');
    await emitText(ctx, text.replaceAll(values[0], () => values[1]));
  } else if (action === 'lines') {
    count(0);
    let pending = '', line = 0, inputSeen = false;
    for await (const record of ctx.stdin) {
      check(ctx); inputSeen = true;
      pending += textValue(record.text);
      let end;
      while ((end = pending.indexOf('\n')) !== -1) {
        let text = pending.slice(0, end);
        if (text.endsWith('\r')) text = text.slice(0, -1);
        if (++line > MAX_STAGE_RECORDS) fail('E_RECORD_LIMIT', 'There are too many text lines.');
        if (encoder.encode(text).byteLength > MAX_TEXT_BYTES) fail('E_TEXT_LIMIT', 'One line exceeds 1 MiB.');
        await ctx.stdout.write({ text, line });
        pending = pending.slice(end + 1);
      }
      if (encoder.encode(pending).byteLength > MAX_TEXT_BYTES) fail('E_TEXT_LIMIT', 'One line exceeds 1 MiB.');
    }
    if (pending || inputSeen && !line) await ctx.stdout.write({ text: pending, line: ++line });
  } else if (action === 'field') {
    count(1);
    if (!values[0] || values[0].length > 128) fail('E_USAGE', 'Enter a field name of at most 128 characters.');
    for await (const record of ctx.stdin) {
      check(ctx);
      if (!Object.hasOwn(record, values[0]) || typeof record[values[0]] !== 'string') fail('E_INPUT_SCHEMA', 'The record has no text field named ' + values[0] + '.');
      await emitText(ctx, record[values[0]] + '\n');
    }
  } else if (action === 'ndjson') {
    count(0);
    for await (const record of ctx.stdin) { check(ctx); await emitText(ctx, JSON.stringify(record) + '\n'); }
  } else if (action === 'read') {
    count(0);
    if (!os?.vfs?.read) fail('E_CONTEXT', 'This action needs the local filesystem.');
    for await (const record of ctx.stdin) {
      check(ctx);
      if (['directory', 'device'].includes(record.kind)) continue;
      if (record.kind !== 'file' || typeof record.path !== 'string') fail('E_INPUT_SCHEMA', 'Read each file expects file and folder records with paths.');
      const file = await os.vfs.read(record.path);
      check(ctx);
      await emitText(ctx, file.text, { path: file.path, revision: file.revision });
    }
  } else if (action === 'write') {
    count(3, 4);
    if (!os?.vfs?.write) fail('E_CONTEXT', 'This action needs the local filesystem.');
    const [destination, mode, separator, suppliedOperation] = values;
    if (!['create', 'replace'].includes(mode) || !['none', 'newline'].includes(separator)) fail('E_USAGE', 'Write requires create or replace, and none or newline between records.');
    const path = ordinaryPath(destination, os), id = operationId(suppliedOperation);
    // Capture replacement revision before consuming input. A concurrent writer wins cleanly.
    const opened = mode === 'replace' ? await os.vfs.read(path) : null;
    if (opened?.virtual || opened?.managedBy) fail('E_READ_ONLY', 'This destination is managed by a system service.');
    const revision = opened?.revision ?? 0;
    const text = await collectText(ctx, separator === 'newline' ? '\n' : '');
    const pending = { operationId: id, kind: 'file-write', target: path, expectedRevision: revision };
    await effect(ctx, 'WORKFLOW_EFFECT_PENDING', pending);
    check(ctx);
    const saved = await os.vfs.write(path, text, { expectedRevision: revision, operationId: id });
    const receipt = { ...pending, revision: saved.revision, bytes: saved.bytes ?? encoder.encode(text).byteLength };
    await effect(ctx, 'WORKFLOW_EFFECT_COMMITTED', receipt);
    await ctx.stdout.write({ kind: 'file-saved', path: saved.path, revision: saved.revision, operationId: id, bytes: receipt.bytes });
  } else if (action === 'tasks-add') {
    count(0, 1);
    if (!os?.tasks?.dispatch) fail('E_CONTEXT', 'This action needs the Tasks service.');
    const prefix = operationId(values[0]);
    let index = 0;
    for await (const record of ctx.stdin) {
      check(ctx);
      const title = textValue(record.text).trim();
      if (!title) continue;
      if (title.length > 240 || /[\u0000-\u001f\u007f]/.test(title)) fail('E_TASK_TITLE', 'Each task needs one text line of at most 240 characters. Use Split into lines first for a list.');
      if (++index > MAX_EFFECTS) fail('E_EFFECT_LIMIT', 'A workflow run creates at most ' + MAX_EFFECTS + ' tasks.');
      const id = prefix + ':' + index;
      const pending = { operationId: id, kind: 'task-add', target: title };
      await effect(ctx, 'WORKFLOW_EFFECT_PENDING', pending);
      check(ctx);
      const result = await os.tasks.dispatch('add', { title }, { operationId: id });
      const revision = result.committedRevision ?? result.revision;
      await effect(ctx, 'WORKFLOW_EFFECT_COMMITTED', { ...pending, revision });
      await ctx.stdout.write({ kind: 'task-created', title, revision, operationId: id });
    }
  } else fail('E_USAGE', 'Usage: ' + usage);
}
