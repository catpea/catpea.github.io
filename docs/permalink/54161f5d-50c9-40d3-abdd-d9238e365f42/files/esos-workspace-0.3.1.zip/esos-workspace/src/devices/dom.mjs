import { decodeNdjson, encodeNdjson } from '../protocol/ndjson.mjs';

// A presentation device for trusted bundled applications, not a code sandbox.
const LIMITS = Object.freeze({
  recordBytes: 1024 * 1024,
  operations: 128,
  nodes: 2048,
  depth: 64,
  pendingWrites: 4,
  intents: 8,
  outputRecords: 64,
  outputBytes: 2 * 1024 * 1024 + 2,
  textCharacters: 65536
});
const TAGS = new Set(('div span p main section article header footer nav aside h1 h2 h3 h4 h5 h6 ' +
  'strong em small code pre kbd samp ul ol li dl dt dd form label input textarea select option optgroup ' +
  'button fieldset legend table caption thead tbody tfoot tr th td colgroup col progress meter ' +
  'details summary hr br a time img').split(' '));
const VOID = new Set(['input', 'hr', 'br', 'col', 'img']);
const ATTRS = new Set(('name type placeholder title role for autocomplete inputmode min max step ' +
  'minlength maxlength pattern required readonly multiple size rows cols colspan rowspan scope ' +
  'span href target rel datetime dir lang headers spellcheck src alt width height loading accept').split(' '));
const REFERENCES = new Set(['for', 'headers', 'aria-labelledby', 'aria-describedby', 'aria-controls',
  'aria-activedescendant', 'aria-details', 'aria-errormessage']);
const EVENTS = new Set(['click', 'submit', 'change', 'contextmenu']);
const INPUT_TYPES = new Set(('text search email url tel number date datetime-local month week time ' +
  'checkbox radio range color password file hidden button submit reset').split(' '));
const BOOLEAN_PROPS = new Set(['checked', 'disabled', 'readOnly', 'hidden', 'selected', 'open', 'multiple']);
const VALUE_TAGS = new Set(['input', 'textarea', 'select', 'option', 'progress', 'meter']);
const MUTABLE = ['text', 'class', 'attrs', 'props', 'on', 'data', 'fields'];
const decoder = new TextDecoder();
let nextView = 0;

export class DomDeviceError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'DomDeviceError';
    this.code = code;
  }
}
const fail = (code, message) => { throw new DomDeviceError(code, message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function string(value, name, maximum = LIMITS.textCharacters) {
  if (typeof value !== 'string' || value.length > maximum) fail('E_VALUE', name + ' must be a bounded string.');
}
function localId(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_:-]{1,96}$/.test(value)) {
    fail('E_ID', 'Node IDs use 1–96 letters, digits, underscores, colons, or hyphens.');
  }
}
function keys(value, allowed, name) {
  if (!object(value)) fail('E_RECORD', name + ' must be an object.');
  for (const key of Object.keys(value)) if (!allowed.includes(key)) fail('E_FIELD', name + ': unsupported field ' + key);
}
function freeze(value) {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function snapshot(record) {
  return JSON.parse(decoder.decode(encodeNdjson(record, { maxRecordBytes: LIMITS.recordBytes })));
}
function nodeRecord(id, tag, element = null) {
  return { id, tag, element, parent: null, children: [], attrs: {}, props: {}, on: {}, data: {}, fields: [] };
}

/**
 * One owned DOM root, a record writer, and optional duplex NDJSON bytes.
 * Callback mode and event-stream mode are exclusive: each intent has one consumer.
 */
export function createDomDevice(host, { title = '', onIntent, onFault, eventStream = false } = {}) {
  if (!host || host.nodeType !== 1 || typeof host.append !== 'function') throw new TypeError('A host element is required.');
  if (onIntent !== undefined && typeof onIntent !== 'function') throw new TypeError('onIntent must be a function.');
  if (onFault !== undefined && typeof onFault !== 'function') throw new TypeError('onFault must be a function.');
  if (eventStream && onIntent) throw new TypeError('Choose onIntent or eventStream, not both.');
  string(title, 'title', 256);

  const document = host.ownerDocument;
  const id = 'v' + (++nextView);
  const path = '/dev/view/' + id;
  const domId = name => 'esos-' + id + '-' + name;
  const wrapper = document.createElement('section');
  wrapper.className = 'esos-dom-device';
  wrapper.dataset.view = id;
  if (title) wrapper.setAttribute('aria-label', title);
  const root = document.createElement('div');
  root.id = domId('root');
  root.className = 'esos-view-root';
  const notice = document.createElement('p');
  notice.className = 'small mt-2';
  notice.setAttribute('role', 'status');
  notice.hidden = true;
  wrapper.append(root, notice);
  host.append(wrapper);

  let nodes = new Map([['root', nodeRecord('root', 'div', root)]]);
  const elementIds = new WeakMap([[root, 'root']]);
  const composing = new WeakSet();
  const lifetime = new AbortController();
  let revision = 0;
  let sealed = false;
  let destroyed = false;
  let faulted = false;
  let pendingWrites = 0;
  let tail = Promise.resolve();
  let closing;
  let deferredSelectValues;
  const intents = [];
  let dispatching = false;
  const pendingForms = new Set();

  // With highWaterMark zero the stream's queue does not hide a second buffer.
  const output = [];
  let outputBytes = 0;
  let outputDemand = false;
  let outputEnded = false;
  let outputCancelled = false;
  let outputController;
  let spaceWaiter;
  let rejectedEvents = 0;
  const signalSpace = () => { const wake = spaceWaiter; spaceWaiter = undefined; wake?.(); };
  function flushOutput() {
    if (!eventStream || outputCancelled) return;
    if (outputDemand && output.length) {
      outputDemand = false;
      const bytes = output.shift();
      outputBytes -= bytes.byteLength;
      outputController.enqueue(bytes);
      signalSpace();
    }
    reportRejectedEvents();
    if (outputEnded && output.length === 0) {
      outputController.close();
      outputCancelled = true;
      signalSpace();
    }
  }
  function hasSpace(bytes) {
    return output.length < LIMITS.outputRecords && outputBytes + bytes.byteLength <= LIMITS.outputBytes;
  }
  function enqueueOutput(bytes) {
    output.push(bytes);
    outputBytes += bytes.byteLength;
    flushOutput();
  }
  function reportRejectedEvents() {
    if (!rejectedEvents || outputCancelled) return;
    const bytes = encodeNdjson({ kind: 'rejected', view: id, reason: 'backpressure', count: rejectedEvents });
    if (hasSpace(bytes)) {
      rejectedEvents = 0;
      enqueueOutput(bytes);
    }
  }
  const readable = eventStream ? new ReadableStream({
    start(controller) { outputController = controller; },
    pull() {
      outputDemand = true;
      flushOutput();
      reportRejectedEvents();
    },
    cancel() {
      outputCancelled = true;
      sealed = true;
      output.length = 0;
      outputBytes = 0;
      signalSpace();
    }
  }, { highWaterMark: 0 }) : undefined;

  async function acknowledge(record) {
    if (!eventStream) return;
    const bytes = encodeNdjson(record);
    while (!hasSpace(bytes)) {
      if (outputCancelled || destroyed) fail('E_OUTPUT_CLOSED', 'The view event stream is closed.');
      await new Promise(resolve => { spaceWaiter = resolve; });
    }
    if (outputCancelled || destroyed) fail('E_OUTPUT_CLOSED', 'The view event stream is closed.');
    enqueueOutput(bytes);
  }
  function report(error, context = {}) {
    if (!(error instanceof Error)) error = new DomDeviceError('E_APPLICATION', String(error ?? 'Application action failed.'));
    if (!destroyed) {
      notice.textContent = error.message || String(error);
      notice.hidden = false;
    }
    try { Promise.resolve(onFault?.(error, { view: id, ...context })).catch(() => {}); } catch {}
  }
  function rejectIntent(message, context) {
    report(new DomDeviceError('E_INTENT_REJECTED', message), context);
  }
  function ensureOpen() {
    if (destroyed) fail('E_VIEW_DESTROYED', 'The view has been destroyed.');
    if (faulted) fail('E_VIEW_FAULTED', 'The view must be reopened after a renderer failure.');
    if (sealed) fail('E_VIEW_CLOSED', 'The view input is closed.');
  }
  function get(model, name) {
    localId(name);
    const node = model.get(name);
    if (!node) fail('E_NODE', 'Unknown node: ' + name);
    return node;
  }
  function validateAttributes(node, attrs) {
    if (!object(attrs)) fail('E_ATTRIBUTE', 'attrs must be an object.');
    for (const [name, value] of Object.entries(attrs)) {
      if (!ATTRS.has(name) && !/^(aria|data)-[a-z][a-z0-9-]*$/.test(name)) {
        fail('E_ATTRIBUTE', 'Unsupported attribute: ' + name);
      }
      if (value === null) continue;
      string(value, 'attribute ' + name, name === 'src' ? 350000 : 8192);
      if (REFERENCES.has(name)) for (const ref of value.trim().split(/\s+/)) localId(ref);
      if (name === 'href') {
        if (node.tag !== 'a') fail('E_ATTRIBUTE', 'href belongs on an anchor.');
        const url = new URL(value, document.baseURI);
        if (!['http:', 'https:', 'mailto:', 'tel:'].includes(url.protocol)) fail('E_URL', 'Unsupported link protocol.');
      }
      if (name === 'src') {
        if (node.tag !== 'img') fail('E_ATTRIBUTE', 'src belongs on an image.');
        const url = new URL(value, document.baseURI);
        const dataImage = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(value);
        if (!dataImage && (!['http:', 'https:'].includes(url.protocol) || url.origin !== new URL(document.baseURI).origin)) {
          fail('E_URL', 'Images use a same-origin URL or embedded PNG, JPEG, GIF, or WebP.');
        }
      }
      if (name === 'loading' && !['lazy', 'eager'].includes(value)) fail('E_ATTRIBUTE', 'Image loading must be lazy or eager.');
      if (name === 'target' && !['_blank', '_self'].includes(value)) fail('E_ATTRIBUTE', 'Unsupported link target.');
      if (name === 'spellcheck' && !['true', 'false'].includes(value)) fail('E_ATTRIBUTE', 'spellcheck must be true or false.');
      if (name === 'type' && node.tag === 'input' && !INPUT_TYPES.has(value)) fail('E_ATTRIBUTE', 'Unsupported input type.');
    }
  }
  function validateProps(node, props) {
    if (!object(props)) fail('E_PROPERTY', 'props must be an object.');
    for (const [name, value] of Object.entries(props)) {
      if (BOOLEAN_PROPS.has(name)) {
        if (typeof value !== 'boolean') fail('E_PROPERTY', name + ' must be boolean.');
      } else if (name === 'value' && VALUE_TAGS.has(node.tag)) {
        if (['progress', 'meter'].includes(node.tag)) {
          if (typeof value !== 'number' || !Number.isFinite(value)) fail('E_PROPERTY', 'A meter value must be finite.');
        } else string(value, 'value');
        if (node.tag === 'input' && node.attrs.type === 'file' && value !== '') fail('E_PROPERTY', 'A file input cannot be assigned a value.');
      } else if (name === 'tabIndex') {
        if (!Number.isInteger(value) || value < -1 || value > 32767) fail('E_PROPERTY', 'Invalid tabIndex.');
      } else if (name === 'max' && ['progress', 'meter'].includes(node.tag)) {
        if (typeof value !== 'number' || !Number.isFinite(value) || value <= 0) fail('E_PROPERTY', 'max must be positive.');
      } else fail('E_PROPERTY', 'Unsupported property: ' + name);
      if (name === 'checked' && node.tag !== 'input') fail('E_PROPERTY', 'checked belongs on an input.');
      if (name === 'selected' && node.tag !== 'option') fail('E_PROPERTY', 'selected belongs on an option.');
      if (name === 'open' && node.tag !== 'details') fail('E_PROPERTY', 'open belongs on details.');
      if (name === 'multiple' && !['select', 'input'].includes(node.tag)) fail('E_PROPERTY', 'multiple belongs on a select or input.');
      if (name === 'readOnly' && !['input', 'textarea'].includes(node.tag)) fail('E_PROPERTY', 'readOnly belongs on a text control.');
      if (name === 'disabled' && !['button', 'input', 'select', 'textarea', 'fieldset', 'option', 'optgroup'].includes(node.tag)) {
        fail('E_PROPERTY', 'disabled belongs on a native form control.');
      }
    }
  }
  function update(node, op, live, skipped) {
    if (Object.hasOwn(op, 'text')) {
      string(op.text, 'text');
      if (node.children.length || VOID.has(node.tag) || ['textarea', 'select'].includes(node.tag)) {
        fail('E_TEXT', 'Set text only on a leaf text container.');
      }
    }
    if (Object.hasOwn(op, 'class')) string(op.class, 'class', 4096);
    if (op.attrs !== undefined) {
      validateAttributes(node, op.attrs);
      for (const [name, value] of Object.entries(op.attrs)) {
        if (value === null) delete node.attrs[name]; else node.attrs[name] = value;
      }
    }
    if (op.props !== undefined) validateProps(node, op.props);
    if (op.on !== undefined) {
      if (!object(op.on)) fail('E_EVENT', 'on must be an object.');
      for (const [event, action] of Object.entries(op.on)) {
        if (!EVENTS.has(event)) fail('E_EVENT', 'Unsupported event: ' + event);
        if (event === 'submit' && node.tag !== 'form') fail('E_EVENT', 'submit belongs on a form.');
        if (action !== null && (typeof action !== 'string' || !/^[A-Za-z0-9_.:/-]{1,128}$/.test(action))) {
          fail('E_EVENT', 'An action is a bounded name.');
        }
        if (action === null) delete node.on[event]; else node.on[event] = action;
      }
    }
    if (op.data !== undefined) {
      if (!object(op.data)) fail('E_DATA', 'data must be an object.');
      if (encodeNdjson(op.data).byteLength > 65536) fail('E_LIMIT', 'Node data exceeds 64 KiB.');
      node.data = freeze(op.data);
    }
    if (op.fields !== undefined) {
      if (node.tag !== 'form' || !Array.isArray(op.fields) || op.fields.length > 32 ||
          op.fields.some(name => typeof name !== 'string' || !/^[A-Za-z0-9_.-]{1,96}$/.test(name)) ||
          new Set(op.fields).size !== op.fields.length) fail('E_FIELDS', 'A form declares up to 32 unique field names.');
      node.fields = [...op.fields];
    }
    if (Object.hasOwn(op, 'ifValue')) {
      string(op.ifValue, 'ifValue');
      if (!op.props || !Object.hasOwn(op.props, 'value')) fail('E_PROPERTY', 'ifValue guards props.value.');
    }
    if (live) {
      if (Object.hasOwn(op, 'text')) node.element.textContent = op.text;
      if (Object.hasOwn(op, 'class')) node.element.className = op.class;
      for (const [name, value] of Object.entries(op.attrs ?? {})) {
        if (value === null) node.element.removeAttribute(name);
        else node.element.setAttribute(name, REFERENCES.has(name) ? value.trim().split(/\s+/).map(domId).join(' ') : value);
      }
    }
    for (const [name, value] of Object.entries(op.props ?? {})) {
      if (live && name === 'value') {
        const reason = composing.has(node.element) ? 'composing' :
          Object.hasOwn(op, 'ifValue') && node.element.value !== op.ifValue ? 'value-changed' : null;
        if (reason) { skipped.push({ id: node.id, property: name, reason }); continue; }
      }
      node.props[name] = value;
      if (live && node.tag === 'select' && name === 'value') deferredSelectValues.set(node.element, value);
      else if (live && node.element[name] !== value) node.element[name] = value;
    }
  }
  function detach(model, node) {
    if (node.parent !== null) {
      const siblings = model.get(node.parent).children;
      siblings.splice(siblings.indexOf(node.id), 1);
    }
    node.parent = null;
  }
  function remove(model, node) {
    for (const child of [...node.children]) remove(model, model.get(child));
    detach(model, node);
    model.delete(node.id);
  }
  function containsForm(model, node) {
    return node.tag === 'form' || node.children.some(child => containsForm(model, model.get(child)));
  }
  function height(model, node) {
    return 1 + (node.children.length ? Math.max(...node.children.map(child => height(model, model.get(child)))) : 0);
  }
  function mutate(model, op, live, skipped = []) {
    if (!object(op)) fail('E_OPERATION', 'An operation must be an object.');
    if (op.op === 'create') {
      keys(op, ['op', 'id', 'tag', ...MUTABLE], 'create');
      localId(op.id);
      if (model.has(op.id)) fail('E_NODE_EXISTS', 'Node already exists: ' + op.id);
      if (!TAGS.has(op.tag)) fail('E_TAG', 'Unsupported native tag: ' + op.tag);
      if (model.size >= LIMITS.nodes) fail('E_LIMIT', 'The view node limit has been reached.');
      const node = nodeRecord(op.id, op.tag, live ? document.createElement(op.tag) : null);
      model.set(op.id, node);
      update(node, op, live, skipped);
      if (live) {
        node.element.id = domId(op.id);
        elementIds.set(node.element, op.id);
      }
    } else if (op.op === 'set') {
      keys(op, ['op', 'id', 'ifValue', ...MUTABLE], 'set');
      update(get(model, op.id), op, live, skipped);
    } else if (op.op === 'place') {
      keys(op, ['op', 'id', 'parent', 'before'], 'place');
      const node = get(model, op.id);
      const parent = get(model, op.parent);
      const before = op.before === undefined || op.before === null ? null : get(model, op.before);
      if (node.id === 'root' || VOID.has(parent.tag) || parent.tag === 'textarea') fail('E_PLACE', 'Invalid parent or root move.');
      if (before && (before.parent !== parent.id || before.id === node.id)) fail('E_PLACE', 'before must name a different child of the parent.');
      let depth = 0;
      for (let ancestor = parent; ancestor; ancestor = model.get(ancestor.parent)) {
        depth++;
        if (ancestor.id === node.id) fail('E_CYCLE', 'A node cannot contain itself.');
        if (ancestor.tag === 'form' && containsForm(model, node)) fail('E_PLACE', 'Forms cannot be nested.');
      }
      if (depth + height(model, node) > LIMITS.depth) fail('E_LIMIT', 'The view nesting limit is 64.');
      if (parent.tag === 'select' && !['option', 'optgroup'].includes(node.tag)) fail('E_PLACE', 'A select contains options or option groups.');
      if (parent.tag === 'optgroup' && node.tag !== 'option') fail('E_PLACE', 'An option group contains options.');
      detach(model, node);
      const index = before ? parent.children.indexOf(before.id) : parent.children.length;
      parent.children.splice(index, 0, node.id);
      node.parent = parent.id;
      if (live && (node.element.parentNode !== parent.element || node.element.nextSibling !== (before?.element ?? null))) {
        parent.element.insertBefore(node.element, before?.element ?? null);
      }
    } else if (op.op === 'remove') {
      keys(op, ['op', 'id'], 'remove');
      const node = get(model, op.id);
      if (node.id === 'root') fail('E_ROOT', 'The root is owned by the device.');
      if (live) node.element.remove();
      remove(model, node);
    } else fail('E_OPERATION', 'Unsupported operation: ' + op.op);
  }
  function apply(record) {
    // Accepted writes may finish after close seals the input.
    if (destroyed) fail('E_VIEW_DESTROYED', 'The view has been destroyed.');
    if (faulted) fail('E_VIEW_FAULTED', 'The view must be reopened after a renderer failure.');
    if (outputCancelled) fail('E_OUTPUT_CLOSED', 'The view event stream is closed.');
    keys(record, ['op', 'id', 'base', 'ops'], 'batch');
    if (record.op !== 'batch') fail('E_OPERATION', 'The device accepts batch records.');
    string(record.id, 'batch id', 128);
    if (!record.id) fail('E_ID', 'A batch ID is required.');
    if (record.base !== undefined && record.base !== revision) fail('E_REVISION', 'The view revision changed.');
    if (!Array.isArray(record.ops) || record.ops.length > LIMITS.operations) fail('E_LIMIT', 'A batch has at most 128 operations.');
    const planned = new Map([...nodes].map(([name, node]) => [name, {
      ...node, children: [...node.children], attrs: { ...node.attrs }, props: { ...node.props },
      on: { ...node.on }, fields: [...node.fields]
    }]));
    for (const op of record.ops) mutate(planned, op, false);
    const skipped = [];
    deferredSelectValues = new Map();
    try {
      for (const op of record.ops) mutate(nodes, op, true, skipped);
      for (const [element, value] of deferredSelectValues) {
        if (nodes.get(elementIds.get(element))?.element === element && element.value !== value) element.value = value;
      }
    } catch (error) {
      faulted = true;
      report(error, { phase: 'apply', batch: record.id });
      throw error;
    } finally {
      deferredSelectValues = undefined;
    }
    revision++;
    return freeze({ kind: 'applied', id: record.id, revision, ...(skipped.length ? { skipped } : {}) });
  }
  function write(record) {
    try {
      ensureOpen();
      if (pendingWrites >= LIMITS.pendingWrites) fail('E_BACKPRESSURE', 'Await pending view writes before sending more.');
      record = snapshot(record);
    } catch (error) { return Promise.reject(error); }
    pendingWrites++;
    const result = tail.then(async () => {
      const ack = apply(record);
      await acknowledge(ack);
      return ack;
    }).finally(() => { pendingWrites--; });
    tail = result.catch(() => {});
    return result;
  }

  function fieldsFor(node) {
    const result = Object.create(null);
    for (const name of node.fields) {
      const controls = Array.from(node.element.elements).filter(control => control.name === name);
      if (controls.length !== 1) fail('E_FIELDS', 'A selected form field must name one control: ' + name);
      const control = controls[0];
      if (!['INPUT', 'TEXTAREA', 'SELECT'].includes(control.tagName) || ['password', 'file'].includes(control.type)) {
        fail('E_FIELDS', 'Password, file, and unsupported controls are not serialized.');
      }
      result[name] = control.type === 'checkbox' ? control.checked :
        control.tagName === 'SELECT' && control.multiple ? Array.from(control.selectedOptions, option => option.value) : control.value;
    }
    return result;
  }
  async function dispatch() {
    if (dispatching) return;
    dispatching = true;
    while (intents.length && !destroyed) {
      const { intent, form } = intents.shift();
      try { await onIntent(intent, { signal: lifetime.signal }); }
      catch (error) { report(error, { phase: 'intent', eventId: intent.eventId }); }
      finally {
        if (form) {
          pendingForms.delete(form);
          if (form.isConnected) form.removeAttribute('aria-busy');
        }
      }
    }
    dispatching = false;
  }
  function receive(event) {
    if (event.type === 'submit') event.preventDefault();
    let element = event.target?.nodeType === 1 ? event.target : event.target?.parentElement;
    let node;
    while (element && root.contains(element)) {
      const candidate = nodes.get(elementIds.get(element));
      if (candidate?.on[event.type]) { node = candidate; break; }
      element = element.parentElement;
    }
    if (!node) {
      if (event.type === 'submit') rejectIntent('This form has no submit action.');
      return;
    }
    if (event.type === 'submit' || event.type === 'click' || event.type === 'contextmenu') event.preventDefault();
    if (sealed || faulted || destroyed) return rejectIntent('This view is closed. Reopen it to perform actions.');
    const form = event.type === 'submit' ? node.element : null;
    if (form && pendingForms.has(form)) return rejectIntent('The previous form submission is still being handled.');
    let intent;
    try {
      intent = { kind: 'intent', view: id, eventId: crypto.randomUUID(),
        event: event.type, action: node.on[event.type], target: node.id, data: node.data };
      if (event.type === 'contextmenu') {
        intent.clientX = Math.round(event.clientX ?? 0); intent.clientY = Math.round(event.clientY ?? 0);
      }
      if (form) intent.fields = fieldsFor(node);
      if (['input', 'select', 'textarea'].includes(node.tag) && !['password', 'file'].includes(node.element.type)) {
        intent.value = node.element.value;
        if (node.tag === 'input') intent.checked = node.element.checked;
      }
      intent = freeze(snapshot(intent));
    } catch (error) { report(error, { phase: 'capture' }); return; }
    if (eventStream) {
      const bytes = encodeNdjson(intent);
      if (outputCancelled || !hasSpace(bytes)) {
        rejectedEvents++;
        return rejectIntent('The view event reader is busy. This action was not submitted; try again.', { eventId: intent.eventId });
      }
      notice.hidden = true;
      enqueueOutput(bytes);
    } else {
      if (!onIntent) return rejectIntent('This view has no action handler.');
      if (intents.length + Number(dispatching) >= LIMITS.intents) {
        return rejectIntent('The application is busy. This action was not submitted; try again.', { eventId: intent.eventId });
      }
      if (form) { pendingForms.add(form); form.setAttribute('aria-busy', 'true'); }
      notice.hidden = true;
      intents.push({ intent, form });
      void dispatch();
    }
  }
  for (const event of EVENTS) root.addEventListener(event, receive, { signal: lifetime.signal });
  root.addEventListener('compositionstart', event => composing.add(event.target), { signal: lifetime.signal });
  root.addEventListener('compositionend', event => composing.delete(event.target), { signal: lifetime.signal });

  // Assemble one bounded line at a time; the shared codec owns JSON/UTF-8 validation.
  let fragments = [];
  let fragmentBytes = 0;
  function append(bytes) {
    if (fragmentBytes + bytes.byteLength > LIMITS.recordBytes + 2) fail('E_RECORD_BYTES', 'The NDJSON line exceeds 1 MiB.');
    if (bytes.byteLength) { fragments.push(bytes.slice()); fragmentBytes += bytes.byteLength; }
  }
  const writable = new WritableStream({
    async write(chunk) {
      ensureOpen();
      if (!(chunk instanceof Uint8Array)) fail('E_BYTES', 'The DOM device accepts Uint8Array chunks.');
      let start = 0;
      try {
        for (let end = chunk.indexOf(10, start); end !== -1; end = chunk.indexOf(10, start)) {
          append(chunk.subarray(start, end + 1));
          const line = new Uint8Array(fragmentBytes);
          let offset = 0;
          for (const part of fragments) { line.set(part, offset); offset += part.byteLength; }
          fragments = []; fragmentBytes = 0;
          for await (const record of decodeNdjson([line])) await write(record);
          start = end + 1;
        }
        append(chunk.subarray(start));
      } catch (error) {
        sealed = true;
        fragments = []; fragmentBytes = 0;
        report(error, { phase: 'input' });
        void close();
        throw error;
      }
    },
    async close() {
      try { await close(); }
      catch (error) { report(error, { phase: 'input' }); throw error; }
    },
    abort(reason) {
      sealed = true;
      fragments = []; fragmentBytes = 0;
      report(reason instanceof Error ? reason : new DomDeviceError('E_ABORTED', String(reason ?? 'View input aborted.')), { phase: 'input' });
      outputEnded = true;
      flushOutput();
    }
  }, new ByteLengthQueuingStrategy({ highWaterMark: LIMITS.recordBytes + 2 }));

  function close() {
    // Accepted writes finish after input is sealed; no new call may join the queue.
    if (destroyed) return Promise.resolve();
    if (closing) return closing;
    const pending = tail;
    const incomplete = fragmentBytes ? new DomDeviceError('E_INCOMPLETE_RECORD', 'The final NDJSON record must end with LF.') : null;
    fragments = []; fragmentBytes = 0;
    sealed = true;
    closing = pending.then(() => {
      outputEnded = true;
      flushOutput();
      if (incomplete) throw incomplete;
    });
    return closing;
  }
  function destroy() {
    if (destroyed) return;
    destroyed = true;
    sealed = true;
    lifetime.abort();
    if (intents.length) report(new DomDeviceError('E_VIEW_DESTROYED', 'Queued view actions were cancelled.'), { count: intents.length });
    intents.length = 0;
    pendingForms.clear();
    fragments = []; fragmentBytes = 0;
    wrapper.remove();
    nodes.clear();
    output.length = 0;
    outputBytes = 0;
    if (eventStream && !outputCancelled) {
      outputController.error(new DomDeviceError('E_VIEW_DESTROYED', 'The view was destroyed.'));
      outputCancelled = true;
    }
    signalSpace();
  }
  function inspect() {
    return freeze({ id, path, revision, state: destroyed ? 'destroyed' : faulted ? 'faulted' : sealed ? 'closed' : 'open',
      nodes: nodes.size, pendingWrites, pendingIntents: intents.length + Number(dispatching),
      outputRecords: output.length, outputBytes, eventStream: Boolean(eventStream), limits: LIMITS });
  }
  return Object.freeze({ id, path, get revision() { return revision; }, writable,
    ...(readable ? { readable } : {}), write, close, destroy, inspect });
}
