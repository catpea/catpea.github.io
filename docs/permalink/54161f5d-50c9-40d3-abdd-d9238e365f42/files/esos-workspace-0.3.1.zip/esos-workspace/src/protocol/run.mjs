import { decodeNdjson, encodeNdjson, ProtocolError } from './ndjson.mjs';

function describe(error) {
  if (error instanceof ProtocolError) {
    return {
      code: error.code,
      message: error.message,
      ...(error.line === undefined ? {} : { line: error.line }),
    };
  }
  if (error?.code === 'EPIPE') {
    return { code: 'EPIPE', message: 'The output pipe was closed.' };
  }
  // Do not serialize stacks, arbitrary thrown values, or private object state.
  return {
    code: error instanceof Error && /^E_[A-Z0-9_]{1,63}$/.test(error.code) ? error.code : 'E_COMMAND',
    message: error instanceof Error ? error.message.slice(0, 1000) : 'The command failed.',
  };
}

const failureValue = error => error ?? new Error('The command failed without an error value.');

/**
 * Run trusted command code with object stdin/stdout/stderr.
 *
 * Adapters provide three distinct Web Streams of Uint8Array bytes.
 * This call owns them: it closes successful sinks, aborts failed sinks, cancels
 * unused input, and releases locks. Abort is cooperative, not forced termination.
 * Commands must await each write; at most one write per channel may be active.
 * Accepted writes are drained before return. An adapter must settle its own I/O
 * for cancellation to complete: AbortSignal cannot interrupt arbitrary promises.
 */
export async function runCommand(command, {
  stdin,
  stdout,
  stderr,
  args = {},
  signal = new AbortController().signal,
  capabilities = Object.freeze({}),
  codec = {},
} = {}) {
  const execute = typeof command === 'function' ? command : command?.run;
  if (typeof execute !== 'function') throw new TypeError('A command must export run(ctx).');
  if (!stdin?.getReader || !stdout?.getWriter || !stderr?.getWriter || stdout === stderr) {
    throw new TypeError('stdin, stdout, and stderr must be distinct Web Streams.');
  }
  if (!signal?.throwIfAborted || !signal?.addEventListener) {
    throw new TypeError('signal must be an AbortSignal.');
  }
  // Reject a malformed codec policy before acquiring any streams.
  encodeNdjson({}, codec);

  let reader;
  let out;
  let err;
  try {
    reader = stdin.getReader();
    out = stdout.getWriter();
    err = stderr.getWriter();
  } catch (error) {
    reader?.releaseLock();
    out?.releaseLock();
    err?.releaseLock();
    throw error;
  }

  let inputEnded = false;
  let failure;
  let abortTasks = [];
  const onAbort = () => {
    const reason = signal.reason ?? new DOMException('Aborted', 'AbortError');
    // Observe all rejections immediately; no detached rejected promises.
    abortTasks = [
      reader.cancel(reason),
      out.abort(reason),
      err.abort(reason),
    ].map(task => task.catch(() => {}));
  };
  signal.addEventListener('abort', onAbort, { once: true });
  if (signal.aborted) onAbort();

  const bytes = {
    [Symbol.asyncIterator]() { return this; },
    async next() {
      signal.throwIfAborted();
      const item = await reader.read();
      signal.throwIfAborted();
      if (item.done) inputEnded = true;
      return item;
    },
    async return() {
      if (!inputEnded) await reader.cancel();
      inputEnded = true;
      return { done: true, value: undefined };
    },
  };
  const records = decodeNdjson(bytes, codec);
  let acceptingWrites = true;
  const channels = [];
  function recordWriter(writer) {
    const channel = { pending: null };
    channels.push(channel);
    function refuse(error) {
      failure ??= error;
      const rejected = Promise.reject(error);
      rejected.catch(() => {});
      return rejected;
    }
    return Object.freeze({
      write(record) {
        if (!acceptingWrites) {
          return refuse(new ProtocolError('E_RUN_FINISHED', 'The command has finished.'));
        }
        if (channel.pending) {
          return refuse(new ProtocolError('E_CONCURRENT_WRITE', 'Await each write before writing to the same channel again.'));
        }
        const task = (async () => {
          signal.throwIfAborted();
          await writer.write(encodeNdjson(record, codec));
          signal.throwIfAborted();
        })();
        channel.pending = task;
        // Attach handlers even when a buggy command ignores the returned promise.
        // The original promise still rejects for a caller that correctly awaits it.
        task.then(
          () => { channel.pending = null; },
          error => {
            failure ??= failureValue(error);
            channel.pending = null;
          },
        );
        return task;
      },
    });
  }
  const output = recordWriter(out);
  const diagnostics = recordWriter(err);

  try {
    try {
      signal.throwIfAborted();
      await execute(Object.freeze({
        stdin: records,
        stdout: output,
        stderr: diagnostics,
        args,
        signal,
        capabilities,
      }));
      signal.throwIfAborted();
    } catch (error) {
      failure ??= failureValue(error);
    }
    acceptingWrites = false;
    if (channels.some(channel => channel.pending) && !signal.aborted) {
      failure ??= new ProtocolError('E_UNAWAITED_WRITE', 'The command returned before its write finished.');
    }
    await Promise.all(channels.map(channel => channel.pending?.catch(() => {})));

    // A command may intentionally stop early, or may not read input at all.
    // Cancel the reader first so a forgotten pending next() can settle.
    try {
      if (!inputEnded) await reader.cancel();
      inputEnded = true;
    } catch (error) {
      failure ??= failureValue(error);
    }
    try {
      await records.return();
    } catch (error) {
      failure ??= failureValue(error);
    }

    if (failure === undefined && !signal.aborted) {
      try {
        await out.close();
      } catch (error) {
        failure = failureValue(error);
      }
    } else {
      await out.abort(failure).catch(() => {});
    }

    if (failure !== undefined && !signal.aborted && failure?.code !== 'EPIPE') {
      try {
        await err.write(encodeNdjson({ level: 'error', ...describe(failure) }, codec));
      } catch {
        // The exit result remains authoritative if diagnostics cannot be written.
      }
    }
    if (!signal.aborted) {
      try {
        await err.close();
      } catch (error) {
        failure ??= failureValue(error);
      }
    }
  } finally {
    signal.removeEventListener('abort', onAbort);
    await Promise.all(abortTasks);
    reader.releaseLock();
    out.releaseLock();
    err.releaseLock();
  }

  if (signal.aborted) {
    return { status: 'cancelled', exitCode: 130 };
  }
  if (failure?.code === 'EPIPE') {
    return { status: 'broken-pipe', exitCode: 141, error: describe(failure) };
  }
  if (failure !== undefined) {
    return { status: 'error', exitCode: 1, error: describe(failure) };
  }
  return { status: 'ok', exitCode: 0 };
}
