// A deliberately small NDJSON profile. These checks are not a JavaScript sandbox.
export const DEFAULT_MAX_RECORD_BYTES = 1024 * 1024;
export const DEFAULT_MAX_DEPTH = 64;

export class ProtocolError extends Error {
  constructor(code, message, line) {
    super(message);
    this.name = 'ProtocolError';
    this.code = code;
    if (line !== undefined) this.line = line;
  }
}

function limits(options) {
  const maxRecordBytes = options.maxRecordBytes ?? DEFAULT_MAX_RECORD_BYTES;
  const maxDepth = options.maxDepth ?? DEFAULT_MAX_DEPTH;
  for (const [name, value] of Object.entries({ maxRecordBytes, maxDepth })) {
    if (!Number.isSafeInteger(value) || value < 1) {
      throw new TypeError(name + ' must be a positive safe integer.');
    }
  }
  return { maxRecordBytes, maxDepth };
}

const encoder = new TextEncoder();

function checkString(value) {
  if (!value.isWellFormed()) {
    throw new ProtocolError('E_UNICODE', 'Strings and property names must contain well-formed Unicode.');
  }
}

// Snapshot data descriptors so getters and toJSON hooks are never used to encode.
// Proxies can still execute reflective traps: callers must supply trusted data.
function snapshotRecord(record, { maxRecordBytes, maxDepth }) {
  if (record === null || typeof record !== 'object' || Array.isArray(record)) {
    throw new ProtocolError('E_RECORD_TYPE', 'Each record must be a JSON object.');
  }
  const ancestors = new Set();
  let minimumBytes = 0;
  function budget(bytes) {
    minimumBytes += bytes;
    if (minimumBytes > maxRecordBytes) {
      throw new ProtocolError('E_RECORD_BYTES', 'The record exceeds the byte limit.');
    }
  }
  function copy(value, depth) {
    if (value === null || typeof value === 'boolean') {
      budget(value === null ? 4 : value ? 4 : 5);
      return value;
    }
    if (typeof value === 'string') {
      checkString(value);
      budget(value.length + 2);
      return value;
    }
    if (typeof value === 'number') {
      if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) {
        throw new ProtocolError('E_NUMBER', 'Numbers must be finite; integral numbers must be safe integers.');
      }
      budget(String(value).length);
      return value;
    }
    if (typeof value !== 'object') {
      throw new ProtocolError('E_JSON_VALUE', 'Only plain JSON data is supported.');
    }
    if (depth > maxDepth) {
      throw new ProtocolError('E_DEPTH', 'The record exceeds the nesting limit.');
    }
    if (ancestors.has(value)) {
      throw new ProtocolError('E_CYCLE', 'Cyclic data is not JSON.');
    }
    const array = Array.isArray(value);
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== null && prototype !== (array ? Array.prototype : Object.prototype)) {
      throw new ProtocolError('E_PROTOTYPE', 'Only ordinary objects and arrays are supported.');
    }
    const keys = Reflect.ownKeys(value);
    if (keys.some(key => typeof key !== 'string')) {
      throw new ProtocolError('E_JSON_VALUE', 'Symbol properties are not JSON.');
    }
    if (array && keys.length !== value.length + 1) {
      throw new ProtocolError('E_ARRAY', 'Arrays must be dense and have no extra properties.');
    }
    const result = array ? [] : Object.create(null);
    // Prevent inherited serialization hooks on our private snapshot.
    if (array) Object.setPrototypeOf(result, null);
    ancestors.add(value);
    budget(2);
    let count = 0;
    for (const key of keys) {
      if (array && key === 'length') continue;
      checkString(key);
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !descriptor.enumerable || !Object.hasOwn(descriptor, 'value')) {
        throw new ProtocolError('E_DESCRIPTOR', 'JSON properties must be enumerable data properties.');
      }
      if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)) {
        throw new ProtocolError('E_ARRAY', 'Arrays must have only indexed elements.');
      }
      if (count++ > 0) budget(1);
      if (!array) budget(key.length + 3);
      result[key] = copy(descriptor.value, depth + 1);
    }
    ancestors.delete(value);
    return result;
  }
  return copy(record, 1);
}

/** Encode one object as UTF-8 JSON plus LF. Throws before writing any bytes. */
export function encodeNdjson(record, options = {}) {
  const policy = limits(options);
  const text = JSON.stringify(snapshotRecord(record, policy));
  const bytes = encoder.encode(text);
  if (bytes.byteLength > policy.maxRecordBytes) {
    throw new ProtocolError('E_RECORD_BYTES', 'The record exceeds the byte limit.');
  }
  const framed = new Uint8Array(bytes.byteLength + 1);
  framed.set(bytes);
  framed[bytes.byteLength] = 10;
  return framed;
}

// JSON.parse has already checked syntax. Scan only structure and quoted tokens
// to reject duplicate keys, including keys written with different JSON escapes.
function checkStructure(text, maxDepth) {
  const tokens = /"(?:\\[\s\S]|[^"\\])*"|[{}\[\],:]/g;
  const stack = [];
  for (const match of text.matchAll(tokens)) {
    const token = match[0];
    const parent = stack.at(-1);
    if (token === '{' || token === '[') {
      stack.push(token === '{' ? { keys: new Set(), key: true } : null);
      if (stack.length > maxDepth) {
        throw new ProtocolError('E_DEPTH', 'The record exceeds the nesting limit.');
      }
    } else if (token === '}' || token === ']') {
      stack.pop();
    } else if (token === ',') {
      if (parent) parent.key = true;
    } else if (token === ':') {
      if (parent) parent.key = false;
    } else if (parent?.key) {
      const key = JSON.parse(token);
      if (parent.keys.has(key)) {
        throw new ProtocolError('E_DUPLICATE_KEY', 'Duplicate object keys are not allowed.');
      }
      parent.keys.add(key);
      parent.key = false;
    }
  }
}

/**
 * Decode an async iterable (including a ReadableStream) of Uint8Array chunks.
 * Record bytes exclude LF and its optional preceding CR. Empty input is valid.
 * This generator owns its input iterator and returns it on early termination.
 */
export async function* decodeNdjson(source, options = {}) {
  const policy = limits(options);
  const decoder = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true });
  let buffer = new Uint8Array(Math.min(4096, policy.maxRecordBytes + 1));
  let length = 0;
  let line = 1;

  function append(bytes) {
    const total = length + bytes.byteLength;
    const last = bytes.byteLength ? bytes[bytes.byteLength - 1] : buffer[length - 1];
    if (total > policy.maxRecordBytes + 1 ||
        (total > policy.maxRecordBytes && last !== 13)) {
      throw new ProtocolError('E_RECORD_BYTES', 'The record exceeds the byte limit.', line);
    }
    if (total > buffer.byteLength) {
      const grown = new Uint8Array(Math.min(
        policy.maxRecordBytes + 1, Math.max(total, buffer.byteLength * 2)
      ));
      grown.set(buffer.subarray(0, length));
      buffer = grown;
    }
    buffer.set(bytes, length);
    length = total;
  }

  function parse() {
    const size = length && buffer[length - 1] === 13 ? length - 1 : length;
    if (size === 0) throw new ProtocolError('E_EMPTY_RECORD', 'Empty lines are not allowed.', line);
    if (size > policy.maxRecordBytes) {
      throw new ProtocolError('E_RECORD_BYTES', 'The record exceeds the byte limit.', line);
    }
    if (buffer.subarray(0, size).includes(13)) {
      throw new ProtocolError('E_FRAMING', 'CR is allowed only immediately before LF.', line);
    }
    if (size >= 3 && buffer[0] === 239 && buffer[1] === 187 && buffer[2] === 191) {
      throw new ProtocolError('E_BOM', 'A UTF-8 byte-order mark is not allowed.', line);
    }
    let text;
    try {
      text = decoder.decode(buffer.subarray(0, size));
    } catch {
      throw new ProtocolError('E_UTF8', 'The record contains invalid UTF-8.', line);
    }
    let record;
    try {
      record = JSON.parse(text);
    } catch {
      throw new ProtocolError('E_JSON', 'The record contains malformed JSON.', line);
    }
    try {
      checkStructure(text, policy.maxDepth);
      snapshotRecord(record, policy);
    } catch (error) {
      if (error instanceof ProtocolError) error.line = line;
      throw error;
    }
    return record;
  }

  for await (const chunk of source) {
    if (!(chunk instanceof Uint8Array)) {
      throw new ProtocolError('E_BYTES', 'The byte source must yield Uint8Array chunks.', line);
    }
    let start = 0;
    let end;
    while ((end = chunk.indexOf(10, start)) !== -1) {
      append(chunk.subarray(start, end));
      const record = parse();
      length = 0;
      line++;
      yield record;
      start = end + 1;
    }
    append(chunk.subarray(start));
  }
  if (length !== 0) {
    throw new ProtocolError('E_INCOMPLETE_RECORD', 'The final record must end with LF.', line);
  }
}
