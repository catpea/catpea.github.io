const KINDS = new Set(['application', 'command', 'file', 'directory']);
const fold = value => String(value ?? '').normalize('NFC').toLowerCase();

/** One local search over installed entry points and persisted filesystem metadata. */
export function createSearch({ storage, username,
  getApplications = () => [], getCommands = () => new Map() } = {}) {
  if (typeof storage?.call !== 'function') throw new TypeError('A storage client is required.');
  if (typeof getApplications !== 'function' || typeof getCommands !== 'function') {
    throw new TypeError('Search catalogs must be supplied as functions.');
  }
  const home = typeof username === 'string' ? '/home/' + username + '/' : null;
  return Object.freeze({
    async query(text, { limit = 30, signal, kinds = [...KINDS] } = {}) {
      if (typeof text !== 'string' || text.length > 128 || /[\u0000-\u001f\u007f]/.test(text)) {
        throw new TypeError('A search query is at most 128 characters and cannot contain control characters.');
      }
      if (!Number.isSafeInteger(limit) || limit < 1 || limit > 100) throw new RangeError('Search returns 1–100 results.');
      if (!Array.isArray(kinds) || kinds.some(kind => !KINDS.has(kind))) throw new TypeError('Unsupported search result kind.');
      signal?.throwIfAborted();
      const selected = new Set(kinds), query = text.trim(), needle = fold(query);
      const results = [];
      const matches = (title, description) => !needle || fold(title).includes(needle) || fold(description).includes(needle);
      if (selected.has('application')) {
        for (const application of getApplications()) {
          const name = application.id ?? application.name;
          const title = application.title ?? name;
          const description = application.description ?? 'Open ' + title;
          if (matches(title, description)) results.push({ kind: 'application', id: 'application:' + name,
            title, description, application: name });
        }
      }
      if (selected.has('command')) {
        for (const [name, command] of getCommands()) {
          const description = command.summary ?? command.usage ?? '';
          if (matches(name, description)) results.push({ kind: 'command', id: 'command:' + name,
            title: name, description, command: name });
        }
      }
      if (query && (selected.has('file') || selected.has('directory'))) {
        const found = await storage.call('find', { query, limit: 100 });
        signal?.throwIfAborted();
        for (const entry of found.entries) if (selected.has(entry.kind)) {
          results.push({ kind: entry.kind, id: entry.kind + ':' + entry.id, title: entry.name,
            description: entry.path, path: entry.path, application: 'files' });
        }
      }
      const priority = { application: 0, command: 1, file: 2, directory: 3 };
      const relevance = result => {
        const title = fold(result.title);
        return needle && title === needle ? 0 : needle && title.startsWith(needle) ? 1 : 2;
      };
      results.sort((a, b) => relevance(a) - relevance(b) || priority[a.kind] - priority[b.kind] ||
        (home ? Number(!a.path?.startsWith(home)) - Number(!b.path?.startsWith(home)) : 0) ||
        a.title.localeCompare(b.title) || a.id.localeCompare(b.id));
      signal?.throwIfAborted();
      return results.slice(0, limit);
    }
  });
}
