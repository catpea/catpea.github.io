const APP = 'desktop.session';
const MAX_WINDOWS = 12;
const MAX_BYTES = 48 * 1024;
const SAVE_DELAY = 600;
const MODES = new Set(['normal', 'maximized', 'left', 'right']);
const encoder = new TextEncoder();

export class DesktopSessionError extends Error {
  constructor(code, message) { super(message); this.name = 'DesktopSessionError'; this.code = code; }
}
const fail = (code, message) => { throw new DesktopSessionError(code, message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function id(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/.test(value)) {
    fail('E_SESSION_ID', 'A window ID is a bounded identifier.');
  }
  return value;
}
function string(value, label, limit) {
  if (typeof value !== 'string' || value.length > limit || /[\u0000-\u001f\u007f]/.test(value) ||
      (value.isWellFormed && !value.isWellFormed())) {
    fail('E_SESSION_VALUE', label + ' must be a bounded string without control characters.');
  }
  return value;
}
function rectangle(value) {
  if (!object(value)) fail('E_SESSION_BOUNDS', 'A window needs x, y, width, and height.');
  const result = {};
  for (const key of ['x', 'y', 'width', 'height']) {
    const number = value[key];
    if (!Number.isFinite(number) || Math.abs(number) > 100000 ||
        ((key === 'width' || key === 'height') && number < 1)) {
      fail('E_SESSION_BOUNDS', 'Window coordinates and sizes must be finite and bounded.');
    }
    result[key] = Math.round(number);
  }
  return result;
}
function snapshot(value) {
  if (!object(value) || value.schema !== 1 || !Array.isArray(value.windows) || value.windows.length > MAX_WINDOWS) {
    fail('E_SESSION_FORMAT', 'A desktop session uses schema 1 and at most 12 windows.');
  }
  const windows = value.windows.map(window => {
    if (!object(window) || typeof window.app !== 'string' || !/^[A-Za-z][A-Za-z0-9_.:-]{0,127}$/.test(window.app)) {
      fail('E_SESSION_APP', 'A saved application uses a bounded registered application ID.');
    }
    const options = {};
    if (window.options !== undefined && !object(window.options)) fail('E_SESSION_VALUE', 'Window options must be an object.');
    for (const key of ['path', 'directory', 'filter']) {
      if (window.options?.[key] !== undefined) {
        options[key] = string(window.options[key], 'Window ' + key, key === 'filter' ? 128 : 4096);
      }
    }
    const windowId = id(window.id);
    if (window.options?.id !== undefined) {
      if (id(window.options.id) !== windowId) fail('E_SESSION_ID', 'A restored option ID must match its window ID.');
      options.id = windowId;
    }
    if (window.options?.newWindow !== undefined) {
      if (typeof window.options.newWindow !== 'boolean') fail('E_SESSION_VALUE', 'newWindow must be boolean.');
      options.newWindow = window.options.newWindow;
    }
    const mode = window.mode ?? 'normal';
    if (!MODES.has(mode)) fail('E_SESSION_VALUE', 'Unknown window mode.');
    if (window.minimized !== undefined && typeof window.minimized !== 'boolean') fail('E_SESSION_VALUE', 'minimized must be boolean.');
    if (window.chrome !== undefined && typeof window.chrome !== 'boolean') fail('E_SESSION_VALUE', 'chrome must be boolean.');
    return { id: windowId, app: window.app, options, bounds: rectangle(window.bounds), mode,
      ...(window.restoreBounds ? { restoreBounds: rectangle(window.restoreBounds) } : {}),
      minimized: window.minimized ?? false, chrome: window.chrome ?? true };
  });
  const ids = new Set(windows.map(window => window.id));
  if (ids.size !== windows.length) fail('E_SESSION_ID', 'Desktop window IDs must be unique.');
  const activeId = value.activeId ?? null;
  if (activeId !== null && (!ids.has(id(activeId)))) fail('E_SESSION_ID', 'The active window must belong to the saved session.');
  const result = { schema: 1, activeId, windows };
  if (encoder.encode(JSON.stringify(result)).byteLength > MAX_BYTES) {
    fail('E_SESSION_LIMIT', 'The desktop session exceeds its 48 KiB configuration limit.');
  }
  return result;
}

/** A small committed configuration, separate from application drafts and file bodies. */
export function createDesktopSession(storage, { username, onStatus = () => {} } = {}) {
  if (typeof storage?.call !== 'function') throw new TypeError('A storage client is required.');
  if (typeof username !== 'string' || !/^[a-z][a-z0-9_-]{0,31}$/.test(username)) {
    fail('E_PROFILE', 'A valid local username is required.');
  }
  const directory = '/home/' + username + '/.config/desktop';
  const path = directory + '/session.json';
  let saved = null, serialized = null, revision = 0;
  let pending = null, timer = null, queued = 0, closing = false, closed = false, closeTask;
  let tail = Promise.resolve();
  function notify(state, message, error) {
    const status = { state, message, revision, path, ...(error?.code ? { code: error.code } : {}) };
    try { Promise.resolve(onStatus(status)).catch(() => {}); } catch {}
  }
  function open() { if (closed || closing) fail('E_SESSION_CLOSED', 'The desktop session service is closing.'); }
  function clearTimer() { if (timer !== null) clearTimeout(timer); timer = null; }
  const ready = (async () => {
    for (const name of ['/home/' + username, '/home/' + username + '/.config', directory]) {
      await storage.call('mkdir', { path: name });
    }
    const state = await storage.call('getState', { app: APP });
    saved = state.state === null ? null : snapshot(state.state);
    serialized = saved === null ? null : JSON.stringify(saved);
    revision = state.revision;
    notify('ready', saved ? 'Saved desktop session loaded.' : 'A new desktop session is ready.');
    return saved === null ? null : structuredClone(saved);
  })();
  ready.catch(error => notify('error', error.message, error));

  function enqueue(next) {
    if (queued >= 4) return Promise.reject(new DesktopSessionError('E_SESSION_BUSY', 'Await the pending desktop save before saving again.'));
    queued++;
    const work = tail.then(async () => {
      await ready;
      const encoded = JSON.stringify(next);
      if (encoded === serialized) {
        notify('saved', 'Desktop layout is already saved locally.');
        return { saved: true, unchanged: true, revision, path };
      }
      notify('saving', 'Saving desktop layout…');
      const operationId = crypto.randomUUID();
      const result = await storage.call('commit', {
        app: APP, expectedRevision: revision, state: next,
        events: [{ type: 'desktop.session.saved', data: { session: next } }],
        writes: [{ path, text: JSON.stringify(next, null, 2) + '\n' }], operationId
      });
      saved = next;
      serialized = encoded;
      revision = result.revision;
      notify('saved', 'Desktop layout saved locally.');
      return { saved: true, unchanged: false, revision, operationId, path };
    }).catch(error => {
      notify('error', 'Desktop layout was not saved: ' + error.message, error);
      throw error;
    }).finally(() => {
      queued--;
      // schedule() coalesces changes while a save is in flight.
      if (pending && queued === 0 && timer === null && !closed && !closing) arm(0);
    });
    tail = work.catch(() => {});
    return work;
  }
  function arm(delay = SAVE_DELAY) {
    clearTimer();
    timer = setTimeout(() => {
      timer = null;
      if (queued) return; // The settled write will drain the latest pending snapshot.
      void flush().catch(() => {});
    }, delay);
  }
  async function flush() {
    clearTimer();
    await ready;
    while (queued) await tail;
    if (pending) {
      const next = pending;
      pending = null;
      return enqueue(next);
    }
    return { saved: saved !== null, unchanged: true, revision, path };
  }
  return Object.freeze({
    ready, path,
    limits: Object.freeze({ windows: MAX_WINDOWS, bytes: MAX_BYTES, delayMs: SAVE_DELAY }),
    async read() {
      await ready;
      await tail;
      return saved === null ? null : structuredClone(saved);
    },
    save(value) {
      try {
        open();
        const next = snapshot(value);
        if (queued >= 4) fail('E_SESSION_BUSY', 'Await the pending desktop save before saving again.');
        clearTimer();
        pending = null;
        return enqueue(next);
      } catch (error) { return Promise.reject(error); }
    },
    schedule(value) {
      open();
      pending = snapshot(value);
      notify('pending', 'Desktop layout changed.');
      arm();
      return { scheduled: true };
    },
    flush,
    status() { return { revision, path, pending: pending !== null, writing: queued > 0, closed }; },
    close() {
      if (closeTask) return closeTask;
      closing = true;
      clearTimer();
      closeTask = flush().finally(() => { closed = true; closing = false; notify('closed', 'Desktop session closed.'); });
      return closeTask;
    }
  });
}
