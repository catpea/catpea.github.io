import { runCommand } from '../protocol/run.mjs';
import { decodeNdjson, encodeNdjson } from '../protocol/ndjson.mjs';

const pipe = () => new TransformStream(undefined,
  new ByteLengthQueuingStrategy({ highWaterMark: 65536 }),
  new ByteLengthQueuingStrategy({ highWaterMark: 65536 }));
const errorResult = error => ({ status: 'error', exitCode: 1,
  error: { code: error?.code ?? 'E_COMMAND', message: error?.message ?? String(error) } });

function inputStream(source = []) {
  const iterator = source?.[Symbol.asyncIterator]?.() ?? source?.[Symbol.iterator]?.();
  if (!iterator) throw new TypeError('Command input must be an iterable of JSON records.');
  return new ReadableStream({
    async pull(controller) {
      try {
        const item = await iterator.next();
        if (item.done) controller.close(); else controller.enqueue(encodeNdjson(item.value));
      } catch (error) { controller.error(error); }
    },
    async cancel() { await iterator.return?.(); }
  }, new ByteLengthQueuingStrategy({ highWaterMark: 65536 }));
}

/** Structured command invocation. All callers use the same object-NDJSON runner. */
export function createCommandService({ getCommands, onChange = () => {} }) {
  if (typeof getCommands !== 'function') throw new TypeError('A command registry is required.');
  const jobs = new Map();
  const describeJob = job => ({ id: job.id, commands: job.commands, status: job.status,
    startedAt: job.startedAt, finishedAt: job.finishedAt ?? null,
    ...(job.result ? { result: job.result } : {}) });
  const notify = () => { try { onChange({ kind: 'jobs.changed' }); } catch {} };

  function list() {
    return [...getCommands()].map(([name, command]) => ({ name,
      summary: command.summary ?? '', usage: command.usage ?? name,
      ...(command.packageId ? { packageId: command.packageId, version: command.version } : {}),
      ...(command.input ? { input: command.input } : {}),
      ...(command.output ? { output: command.output } : {}),
      ...(command.effects ? { effects: command.effects } : {}) }));
  }

  async function pipeline(stages, { stdin = [], signal, onRecord, onDiagnostic } = {}) {
    if (!Array.isArray(stages) || !stages.length || stages.length > 12) {
      throw new RangeError('A pipeline contains 1–12 commands.');
    }
    if ([...jobs.values()].filter(job => job.status === 'running').length >= 32) {
      throw new Error('Too many running command jobs; finish or cancel an existing job.');
    }
    const selected = stages.map(stage => {
      if (!stage || typeof stage.command !== 'string' || !Array.isArray(stage.args ?? []) ||
          (stage.args ?? []).some(arg => typeof arg !== 'string')) {
        throw new TypeError('A command stage has a name and an array of string arguments.');
      }
      const command = getCommands().get(stage.command);
      if (!command) throw new Error('Unknown or uninstalled command: ' + stage.command);
      return { command, name: stage.command, args: [...(stage.args ?? [])] };
    });
    signal?.throwIfAborted();
    const input = inputStream(stdin);
    const controller = new AbortController();
    const abort = () => controller.abort(signal.reason);
    signal?.addEventListener('abort', abort, { once: true });
    if (signal?.aborted) abort();
    const job = { id: crypto.randomUUID(), commands: selected.map(item => item.name),
      startedAt: new Date().toISOString(), status: 'running', controller };
    jobs.set(job.id, job); notify();
    let firstFailure;
    const fail = error => {
      firstFailure ??= errorResult(error);
      if (!controller.signal.aborted) controller.abort(error);
    };
    const streams = selected.map(pipe);
    const consume = (async () => {
      try {
        for await (const record of decodeNdjson(streams.at(-1).readable)) await onRecord?.(record);
      } catch (error) { if (!controller.signal.aborted) fail(error); }
    })();
    const runs = selected.map((item, index) => runCommand(item.command, {
      stdin: index ? streams[index - 1].readable : input,
      stdout: streams[index].writable,
      stderr: new WritableStream({ async write(bytes) {
        await onDiagnostic?.({ command: item.name, ...JSON.parse(new TextDecoder().decode(bytes)) });
      } }),
      args: item.args, signal: controller.signal
    }).then(result => {
      if (result.exitCode && result.status !== 'cancelled' && !firstFailure) {
        firstFailure = result;
        controller.abort(new Error('A command stage failed.'));
      }
      return result;
    }).catch(error => { fail(error); return errorResult(error); }));
    try {
      const results = await Promise.all(runs);
      await consume;
      const result = firstFailure ?? (controller.signal.aborted
        ? { status: 'cancelled', exitCode: 130 }
        : results.find(value => value.exitCode) ?? { status: 'ok', exitCode: 0 });
      job.status = result.status; job.result = result;
      return { ...result, jobId: job.id };
    } finally {
      signal?.removeEventListener('abort', abort);
      job.finishedAt = new Date().toISOString();
      if (job.status === 'running') job.status = 'error';
      for (const [id, value] of jobs) {
        if (jobs.size <= 100) break;
        if (value.status !== 'running') jobs.delete(id);
      }
      notify();
    }
  }
  return Object.freeze({ list,
    inspect(name) { const entry = list().find(item => item.name === name); if (!entry) throw new Error('Unknown command: ' + name); return entry; },
    invoke(name, args = [], options = {}) { return pipeline([{ command: name, args }], options); },
    pipeline,
    jobs() { return [...jobs.values()].map(describeJob); },
    cancel(id) {
      const job = jobs.get(id);
      if (!job || job.status !== 'running') return { id, cancelled: false };
      job.controller.abort(new DOMException('Stopped by user', 'AbortError'));
      return { id, cancelled: true };
    }
  });
}
