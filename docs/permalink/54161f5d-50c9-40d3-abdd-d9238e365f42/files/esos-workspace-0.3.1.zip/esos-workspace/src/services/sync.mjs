import { resolvePath } from '../ui/apps/common.mjs';

const MAX_FILES = 1000, MAX_BYTES = 1024 * 1024;
const encoder = new TextEncoder();
const digest = async text => [...new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(text)))].map(x => x.toString(16).padStart(2, '0')).join('');
const error = (code, message) => Object.assign(new Error(message), { code });
function relative(value) {
  if (typeof value !== 'string' || !value || value.length > 4096 || /[\\\u0000-\u001f\u007f]/.test(value) ||
      value.split('/').some(part => !part || part.startsWith('.') || part.length > 255)) throw error('E_SYNC_PATH', 'Invalid visible relative file path.');
  return value;
}

/** Compare UTF-8 files with a conventional directory through an optional localhost adapter. */
export function createSync({ os, storage, fetcher = globalThis.fetch.bind(globalThis) }) {
  const home = '/home/' + os.profile.username;
  let running = false;
  const rootPath = value => {
    const root = resolvePath(value ?? '~', home, os.profile.username);
    if (root !== home && (!root.startsWith(home + '/') || root.slice(home.length + 1).split('/').some(part => part.startsWith('.')))) {
      throw error('E_SYNC_ROOT', 'Choose your home directory or a visible folder inside it.');
    }
    return root;
  };
  async function request(path, options = {}) {
    const response = await fetcher('/__peer/' + path, { cache: 'no-store', ...options });
    let value;
    try { value = await response.json(); } catch { throw error('E_SYNC_PEER', 'The optional Linux folder adapter is unavailable.'); }
    if (!response.ok) throw error(response.status === 409 ? 'E_CONFLICT' : 'E_SYNC_PEER', value.error ?? 'The Linux folder request failed.');
    return value;
  }
  async function status() {
    try { return await request('status'); }
    catch (failure) { return { enabled: false, message: failure.message }; }
  }
  async function localFiles(root, signal) {
    const files = new Map(); let entries = 0;
    async function walk(path, prefix = '', depth = 0) {
      if (depth > 64) throw error('E_SYNC_LIMIT', 'The selected folder is too deeply nested.');
      for (const entry of await os.vfs.list(path)) {
        signal?.throwIfAborted();
        if (entry.name.startsWith('.')) continue;
        if (++entries > 2000) throw error('E_SYNC_LIMIT', 'Choose a smaller folder with at most 2,000 visible entries.');
        const name = relative(prefix + entry.name);
        if (entry.kind === 'directory') await walk(entry.path, name + '/', depth + 1);
        else if (entry.kind === 'file' && !entry.virtual) {
          if (files.size >= MAX_FILES) throw error('E_SYNC_LIMIT', 'Choose a folder with at most 1,000 files.');
          const file = await os.vfs.read(entry.path);
          if (encoder.encode(file.text).length > MAX_BYTES) throw error('E_SYNC_LIMIT', 'The file exceeds 1 MiB: ' + name);
          files.set(name, { hash: await digest(file.text), revision: file.revision, managedBy: file.managedBy ?? null });
        }
      }
    }
    await walk(root); return files;
  }
  async function compare({ root: value = '~', signal } = {}) {
    signal?.throwIfAborted();
    const root = rootPath(value);
    const peer = await request('manifest', { signal });
    if (!peer.enabled || typeof peer.id !== 'string' || !Array.isArray(peer.files) || peer.files.length > MAX_FILES) {
      throw error('E_SYNC_PEER', 'The peer is unavailable or exceeds the 1,000-file synchronization limit.');
    }
    const local = await localFiles(root, signal), remote = new Map();
    for (const file of peer.files) {
      const path = relative(file.path);
      if (!/^[a-f0-9]{64}$/.test(file.hash) || remote.has(path)) throw error('E_SYNC_PEER', 'The peer manifest contains an invalid file record.');
      remote.set(path, { hash: file.hash, bytes: file.bytes });
    }
    const key = (await digest(peer.id + '\n' + root)).slice(0, 32);
    const app = 'system.sync.' + key;
    const saved = await storage.call('getState', { app });
    if (saved.state && (saved.state.schema !== 1 || saved.state.peerId !== peer.id || saved.state.root !== root)) {
      throw error('E_SYNC_STATE', 'The saved synchronization baseline is incompatible.');
    }
    const hashes = saved.state?.hashes ?? {}, rows = [];
    for (const path of [...new Set([...local.keys(), ...remote.keys()])].sort()) {
      const left = local.get(path), right = remote.get(path), base = Object.hasOwn(hashes, path) ? hashes[path] : undefined;
      const localHash = left?.hash ?? null, remoteHash = right?.hash ?? null;
      let action = 'same', reason = '';
      if (localHash !== remoteHash) {
        if (base === undefined) action = !left ? 'pull' : !right ? 'push' : 'conflict';
        else if (!left || !right) { action = 'conflict'; reason = 'A file was removed on one side; deletion is explicit.'; }
        else action = localHash === base ? 'pull' : remoteHash === base ? 'push' : 'conflict';
      }
      if (action === 'pull' && left?.managedBy) { action = 'conflict'; reason = 'Use the owning application to replace its managed projection.'; }
      rows.push({ path, action, reason, local: left ?? null, remote: right ?? null, base: base ?? null });
    }
    if (encoder.encode(JSON.stringify(Object.fromEntries(rows.map(row => [row.path, row.local?.hash ?? row.remote?.hash])))).length > 512 * 1024) {
      throw error('E_SYNC_LIMIT', 'Choose a smaller folder so its synchronization baseline fits.');
    }
    return { root, peer: { id: peer.id, label: peer.label }, rows, skipped: peer.skipped ?? [],
      baseline: { app, key, revision: saved.revision, hashes } };
  }
  async function mkdirs(path) {
    let current = '';
    for (const part of path.split('/').filter(Boolean)) { current += '/' + part; await os.vfs.mkdir(current); }
  }
  async function transfer(plan, row, action, signal) {
    signal?.throwIfAborted();
    const path = plan.root + '/' + relative(row.path);
    if (action === 'push') {
      const file = await os.vfs.read(path);
      if (await digest(file.text) !== row.local?.hash) throw error('E_CONFLICT', 'The browser file changed after comparison.');
      const result = await request('file?path=' + encodeURIComponent(row.path), { method: 'PUT', signal,
        headers: { 'Content-Type': 'application/json', 'X-ESOS-Peer': '1' },
        body: JSON.stringify({ text: file.text, expectedHash: row.remote?.hash ?? null }) });
      if (result.hash !== row.local.hash) throw error('E_SYNC_PEER', 'The peer did not acknowledge the expected content.');
      return { path: row.path, action, hash: result.hash, bytes: result.bytes };
    }
    const file = await request('file?path=' + encodeURIComponent(row.path), { signal });
    if (typeof file.text !== 'string' || encoder.encode(file.text).length > MAX_BYTES ||
        file.hash !== row.remote?.hash || await digest(file.text) !== file.hash) throw error('E_CONFLICT', 'The Linux file changed after comparison.');
    await mkdirs(path.slice(0, path.lastIndexOf('/')));
    const result = await os.vfs.write(path, file.text, { expectedRevision: row.local?.revision ?? 0, operationId: crypto.randomUUID() });
    return { path: row.path, action, hash: file.hash, bytes: file.bytes, revision: result.revision };
  }
  async function perform(options = {}, resolution) {
    if (running) throw error('E_SYNC_BUSY', 'A synchronization is already running.');
    running = true;
    try {
      const plan = await compare(options), hashes = Object.create(null), results = [];
      for (const row of plan.rows) {
        if (row.action === 'same') hashes[row.path] = row.local.hash;
        else if (row.base) hashes[row.path] = row.base;
      }
      for (const row of plan.rows) {
        options.signal?.throwIfAborted();
        if (row.action === 'same') continue;
        let action = row.action;
        if (resolution) {
          if (row.path !== resolution.path) continue;
          action = resolution.choice === 'local' ? 'push' : 'pull';
          if ((action === 'push' && !row.local) || (action === 'pull' && !row.remote)) throw error('E_SYNC_RESOLVE', 'Choose the side that contains the file; deletion is never inferred.');
        }
        if (action === 'conflict') {
          const result = { path: row.path, action: 'conflict', message: row.reason || 'Both copies differ; choose which version to retain.' };
          results.push(result); await options.onProgress?.(result); continue;
        }
        try {
          const result = await transfer(plan, row, action, options.signal);
          hashes[row.path] = result.hash; results.push(result); await options.onProgress?.(result);
        } catch (failure) {
          if (options.signal?.aborted) throw failure;
          const result = { path: row.path, action: 'error', code: failure.code ?? 'E_SYNC', message: failure.message };
          results.push(result); await options.onProgress?.(result);
        }
      }
      if (resolution && !plan.rows.some(row => row.path === resolution.path)) throw error('E_SYNC_PATH', 'That file is no longer present on either side.');
      const state = { schema: 1, peerId: plan.peer.id, root: plan.root, hashes };
      if (JSON.stringify(hashes) !== JSON.stringify(plan.baseline.hashes)) {
        const directory = home + '/.config/sync'; await mkdirs(directory);
        await storage.call('commit', { app: plan.baseline.app, expectedRevision: plan.baseline.revision, state,
          events: [{ type: 'sync.completed', data: { peerId: plan.peer.id, root: plan.root,
            transferred: results.filter(row => ['push','pull'].includes(row.action)).length,
            unresolved: results.filter(row => ['conflict','error'].includes(row.action)).length } }],
          writes: [{ path: directory + '/' + plan.baseline.key + '.json', text: JSON.stringify(state, null, 2) + '\n' }], operationId: crypto.randomUUID() });
      }
      return { root: plan.root, peer: plan.peer, results, skipped: plan.skipped,
        transferred: results.filter(row => ['push','pull'].includes(row.action)).length,
        unresolved: results.filter(row => ['conflict','error'].includes(row.action)).length };
    } finally { running = false; }
  }
  return Object.freeze({ status, compare: async options => { const { baseline, ...plan } = await compare(options); return plan; },
    run: options => perform(options),
    resolve: (path, choice, options = {}) => {
      relative(path); if (!['local', 'remote'].includes(choice)) throw error('E_SYNC_RESOLVE', 'Choose local or remote.');
      return perform(options, { path, choice });
    },
    get busy() { return running; }
  });
}
