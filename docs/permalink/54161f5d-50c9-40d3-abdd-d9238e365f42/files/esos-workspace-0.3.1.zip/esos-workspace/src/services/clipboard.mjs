const MAX_BYTES = 1024 * 1024;
const encoder = new TextEncoder();

export class ClipboardError extends Error {
  constructor(code, message) { super(message); this.name = 'ClipboardError'; this.code = code; }
}

function checkedText(value) {
  if (typeof value !== 'string' || (value.isWellFormed && !value.isWellFormed())) {
    throw new ClipboardError('E_CLIPBOARD_TEXT', 'Clipboard text must be a well-formed string.');
  }
  if (encoder.encode(value).byteLength > MAX_BYTES) {
    throw new ClipboardError('E_CLIPBOARD_LIMIT', 'The text clipboard is limited to 1 MiB.');
  }
  return value;
}

/** Explicit text transfers; no permission polling, background reads, or history. */
export function createClipboard({ onStatus = () => {}, clipboard = globalThis.navigator?.clipboard } = {}) {
  let workspaceText = null;
  let copyVersion = 0;
  let lastCopySource = null;
  let busy = false;
  const nativeRead = () => typeof clipboard?.readText === 'function';
  const nativeWrite = () => typeof clipboard?.writeText === 'function';
  function notify(value) {
    try { Promise.resolve(onStatus(value)).catch(() => {}); } catch {}
  }
  function permissionError(action) {
    return new ClipboardError('E_CLIPBOARD_PERMISSION', action === 'read'
      ? 'The browser did not allow reading the system clipboard. Use the editor’s native Paste shortcut or choose Paste workspace copy explicitly.'
      : 'The browser did not allow writing the system clipboard. The text is available in the workspace clipboard.');
  }
  function takeNative() {
    if (busy) throw new ClipboardError('E_CLIPBOARD_BUSY', 'A clipboard request is still being handled. Try again after it finishes.');
    busy = true;
  }
  return Object.freeze({
    limits: Object.freeze({ bytes: MAX_BYTES }),
    status() {
      return { nativeRead: nativeRead(), nativeWrite: nativeWrite(), busy,
        hasWorkspaceText: workspaceText !== null,
        workspaceCharacters: workspaceText?.length ?? 0, lastCopySource,
        persistence: 'session-memory', byteLimit: MAX_BYTES };
    },
    async writeText(text, { source = 'auto' } = {}) {
      checkedText(text);
      if (!['auto', 'system', 'workspace'].includes(source)) {
        throw new ClipboardError('E_CLIPBOARD_SOURCE', 'Choose auto, system, or workspace as the clipboard destination.');
      }
      if (source !== 'workspace' && nativeWrite()) takeNative();
      const version = ++copyVersion;
      workspaceText = text;
      lastCopySource = 'workspace';
      let receipt = { copied: true, characters: text.length, source: 'workspace' };
      if (source === 'workspace') { notify(receipt); return receipt; }
      if (!nativeWrite()) {
        receipt.reason = 'System clipboard writing is unavailable; copied to the workspace clipboard.';
        notify(receipt);
        if (source === 'system') throw new ClipboardError('E_CLIPBOARD_UNAVAILABLE', receipt.reason);
        return receipt;
      }
      try {
        // Call before the first await so a native user activation is not queued away.
        await clipboard.writeText(text);
        receipt = { copied: true, characters: text.length, source: 'system' };
        if (version === copyVersion) lastCopySource = 'system';
        notify(receipt);
        return receipt;
      } catch (error) {
        receipt.reason = 'System clipboard writing was refused; copied to the workspace clipboard.';
        notify(receipt);
        if (source === 'system') throw permissionError('write');
        return receipt;
      } finally { busy = false; }
    },
    async readText({ source = 'system' } = {}) {
      if (source === 'workspace') {
        if (workspaceText === null) throw new ClipboardError('E_CLIPBOARD_EMPTY', 'The workspace clipboard is empty. Use Copy text first.');
        return { text: workspaceText, source: 'workspace' };
      }
      if (source !== 'system') throw new ClipboardError('E_CLIPBOARD_SOURCE', 'Choose system or workspace as the clipboard source.');
      if (!nativeRead()) {
        throw new ClipboardError('E_CLIPBOARD_UNAVAILABLE', 'System clipboard reading is unavailable. Use the editor’s native Paste shortcut or choose Paste workspace copy explicitly.');
      }
      takeNative();
      let text;
      try {
        // A failed native read never substitutes an older workspace copy.
        text = await clipboard.readText();
      } catch (error) {
        throw permissionError('read');
      } finally { busy = false; }
      return { text: checkedText(text), source: 'system' };
    }
  });
}
