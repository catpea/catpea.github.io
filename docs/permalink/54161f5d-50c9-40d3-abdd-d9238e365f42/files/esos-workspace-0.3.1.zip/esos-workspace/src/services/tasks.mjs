const MAX_TASKS = 200;
const MAX_TITLE = 240;
const MAX_UNDO = 32;
const MAX_UNDO_BYTES = 128 * 1024;
const encoder = new TextEncoder();

export class TaskError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'TaskError';
    this.code = code;
  }
}

export function emptyTasks() {
  return { schema: 1, items: [], undo: [] };
}

function copyState(value) {
  if (value === null || value === undefined) return emptyTasks();
  if (value.schema !== 1 || !Array.isArray(value.items) || !Array.isArray(value.undo)) {
    throw new TaskError('E_TASK_STATE', 'The saved Tasks state has an unsupported format.');
  }
  return structuredClone(value);
}

function requireTask(state, id) {
  const index = state.items.findIndex(item => item.id === id);
  if (index < 0) throw new TaskError('E_TASK_NOT_FOUND', 'That task no longer exists.');
  return { index, task: state.items[index] };
}

function remember(state, eventId, inverse) {
  state.undo.push({ eventId, inverse });
  while (state.undo.length > MAX_UNDO ||
    (state.undo.length > 1 && encoder.encode(JSON.stringify(state.undo)).byteLength > MAX_UNDO_BYTES)) {
    state.undo.shift();
  }
}

function applyInverse(state, inverse, at) {
  switch (inverse.kind) {
    case 'remove': {
      const { index } = requireTask(state, inverse.id);
      state.items.splice(index, 1);
      break;
    }
    case 'restore': {
      const current = state.items.findIndex(item => item.id === inverse.task.id);
      const restored = { ...structuredClone(inverse.task), updatedAt: at };
      if (current >= 0) state.items.splice(current, 1, restored);
      else state.items.splice(Math.min(inverse.index, state.items.length), 0, restored);
      break;
    }
    case 'restore-many': {
      for (const entry of inverse.entries) {
        if (state.items.some(item => item.id === entry.task.id)) {
          throw new TaskError('E_TASK_STATE', 'Undo would duplicate a task identity.');
        }
        state.items.splice(Math.min(entry.index, state.items.length), 0, {
          ...structuredClone(entry.task), updatedAt: at,
        });
      }
      break;
    }
    default:
      throw new TaskError('E_TASK_STATE', 'The saved undo operation is unsupported.');
  }
}

/**
 * Pure domain reducer. IDs and timestamps arrive in the committed event.
 * Replaying history never emits an intent, performs I/O, or creates a new ID.
 */
export function reduceTasks(previous, event) {
  const state = copyState(previous);
  const data = event?.data;
  if (!data || typeof data.eventId !== 'string' || typeof data.at !== 'string') {
    throw new TaskError('E_TASK_EVENT', 'A task event needs its recorded identity and time.');
  }
  switch (event.type) {
    case 'tasks.initialized':
      if (state.items.length || state.undo.length) {
        throw new TaskError('E_TASK_EVENT', 'An initialized Tasks state cannot be reset by replay.');
      }
      break;
    case 'task.added': {
      const task = data.task;
      if (!task || typeof task.id !== 'string' || typeof task.title !== 'string' ||
          typeof task.done !== 'boolean' || state.items.some(item => item.id === task.id)) {
        throw new TaskError('E_TASK_EVENT', 'The added task is invalid or already exists.');
      }
      if (state.items.length >= MAX_TASKS) {
        throw new TaskError('E_TASK_LIMIT', 'This workspace supports up to ' + MAX_TASKS + ' tasks.');
      }
      state.items.push(structuredClone(task));
      remember(state, data.eventId, { kind: 'remove', id: task.id });
      break;
    }
    case 'task.completed':
    case 'task.reopened': {
      const { index, task } = requireTask(state, data.id);
      remember(state, data.eventId, { kind: 'restore', index, task: structuredClone(task) });
      state.items[index] = { ...task, done: event.type === 'task.completed', updatedAt: data.at };
      break;
    }
    case 'task.removed': {
      const { index, task } = requireTask(state, data.id);
      remember(state, data.eventId, { kind: 'restore', index, task: structuredClone(task) });
      state.items.splice(index, 1);
      break;
    }
    case 'tasks.completed-cleared': {
      if (!Array.isArray(data.ids) || new Set(data.ids).size !== data.ids.length) {
        throw new TaskError('E_TASK_EVENT', 'The cleared task identities are invalid.');
      }
      const entries = data.ids.map(id => {
        const { index, task } = requireTask(state, id);
        if (!task.done) throw new TaskError('E_TASK_EVENT', 'Only completed tasks can be cleared.');
        return { index, task: structuredClone(task) };
      }).sort((a, b) => a.index - b.index);
      if (entries.length) {
        remember(state, data.eventId, { kind: 'restore-many', entries });
        const removed = new Set(data.ids);
        state.items = state.items.filter(item => !removed.has(item.id));
      }
      break;
    }
    case 'tasks.undone': {
      const last = state.undo.at(-1);
      if (!last || last.eventId !== data.undoOf) {
        throw new TaskError('E_TASK_EVENT', 'Undo does not match the current application history.');
      }
      applyInverse(state, last.inverse, data.at);
      state.undo.pop();
      break;
    }
    case 'tasks.unchanged':
      break;
    default:
      throw new TaskError('E_TASK_EVENT', 'Unsupported task event: ' + String(event.type));
  }
  if (state.items.length > MAX_TASKS) {
    throw new TaskError('E_TASK_LIMIT', 'Undo would exceed the workspace task limit.');
  }
  return state;
}

function normaliseIntent(action, args) {
  if (typeof action !== 'string') throw new TaskError('E_TASK_ACTION', 'A task action is required.');
  action = action.replace(/^tasks\./, '');
  if (!args || typeof args !== 'object' || Array.isArray(args)) {
    throw new TaskError('E_TASK_ARGUMENT', 'Task arguments must be an object.');
  }
  switch (action) {
    case 'add': {
      const title = typeof args.title === 'string' ? args.title.trim() : '';
      if (!title || title.length > MAX_TITLE) {
        throw new TaskError('E_TASK_TITLE', 'Enter a task title between 1 and ' + MAX_TITLE + ' characters.');
      }
      return { action, title };
    }
    case 'toggle':
    case 'remove': {
      if (typeof args.id !== 'string' || !args.id || args.id.length > 128) {
        throw new TaskError('E_TASK_ID', 'Supply a task ID or a unique ID prefix.');
      }
      if (action === 'toggle' && args.done !== undefined && typeof args.done !== 'boolean') {
        throw new TaskError('E_TASK_ARGUMENT', 'The desired completion state must be true or false.');
      }
      return { action, id: args.id, ...(action !== 'toggle' || args.done === undefined ? {} : { done: args.done }) };
    }
    case 'undo':
    case 'clear-completed':
      return { action };
    default:
      throw new TaskError('E_TASK_ACTION', 'Unknown task action: ' + action);
  }
}

function resolveTask(state, prefix) {
  const exact = state.items.find(item => item.id === prefix);
  if (exact) return exact;
  const matches = state.items.filter(item => item.id.startsWith(prefix));
  if (matches.length === 1) return matches[0];
  throw new TaskError(matches.length ? 'E_TASK_AMBIGUOUS' : 'E_TASK_NOT_FOUND',
    matches.length ? 'That ID prefix matches several tasks.' : 'No task matches that ID.');
}

function acceptedEvent(state, intent, operationId) {
  const at = new Date().toISOString();
  const common = { eventId: 'event:' + operationId, at, intentKey: JSON.stringify(intent) };
  switch (intent.action) {
    case 'add':
      return { type: 'task.added', data: {
        ...common,
        task: { id: crypto.randomUUID(), title: intent.title, done: false, createdAt: at, updatedAt: at },
      } };
    case 'toggle': {
      const task = resolveTask(state, intent.id);
      const done = intent.done ?? !task.done;
      return task.done === done
        ? { type: 'tasks.unchanged', data: { ...common, id: task.id, reason: 'Completion already matches.' } }
        : { type: done ? 'task.completed' : 'task.reopened', data: { ...common, id: task.id, title: task.title } };
    }
    case 'remove': {
      const task = resolveTask(state, intent.id);
      return { type: 'task.removed', data: { ...common, id: task.id, title: task.title } };
    }
    case 'clear-completed': {
      const ids = state.items.filter(item => item.done).map(item => item.id);
      return ids.length
        ? { type: 'tasks.completed-cleared', data: { ...common, ids } }
        : { type: 'tasks.unchanged', data: { ...common, reason: 'There are no completed tasks.' } };
    }
    case 'undo': {
      const last = state.undo.at(-1);
      if (!last) throw new TaskError('E_NOTHING_TO_UNDO', 'There is no task change to undo.');
      return { type: 'tasks.undone', data: { ...common, undoOf: last.eventId } };
    }
  }
}

/**
 * One local profile's Tasks service. It commits accepted events, state, and
 * the inspectable state.json projection in one storage transaction.
 */
export function createTaskService(storage, {
  username,
  onChange,
  onListenerError = error => console.error('Tasks view update failed:', error),
} = {}) {
  if (!storage || typeof storage.call !== 'function') throw new TypeError('A storage client is required.');
  if (typeof username !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,31}$/.test(username)) {
    throw new TaskError('E_PROFILE', 'Use a profile name of 1–32 letters, digits, hyphens, or underscores.');
  }
  const app = 'tasks';
  const directory = '/home/' + username + '/.local/share/tasks';
  const statePath = directory + '/state.json';
  const listeners = new Set();
  if (typeof onChange === 'function') listeners.add(onChange);
  let tail = Promise.resolve();

  async function readDirect() {
    const stored = await storage.call('getState', { app });
    return { app, state: copyState(stored.state), revision: stored.revision, path: statePath };
  }

  function listenerFailed(error) {
    try {
      Promise.resolve(onListenerError(error)).catch(() => {});
    } catch {
      // A view/error reporter cannot replace an already committed result.
    }
  }

  function notify(snapshot) {
    for (const listener of listeners) {
      try {
        Promise.resolve(listener(structuredClone(snapshot))).catch(listenerFailed);
      } catch (error) {
        listenerFailed(error);
      }
    }
  }

  async function commitState(state, revision, event, operationId) {
    return storage.call('commit', {
      app,
      state,
      expectedRevision: revision,
      events: [event],
      writes: [{ path: statePath, text: JSON.stringify(state, null, 2) + '\n' }],
      operationId,
    });
  }

  const ready = (async () => {
    for (const path of [
      '/home/' + username,
      '/home/' + username + '/.local',
      '/home/' + username + '/.local/share',
      directory,
    ]) await storage.call('mkdir', { path });
    const saved = await storage.call('getState', { app });
    if (saved.state === null) {
      const operationId = crypto.randomUUID();
      const event = { type: 'tasks.initialized', data: {
        eventId: 'event:' + operationId, at: new Date().toISOString(),
      } };
      await commitState(emptyTasks(), 0, event, operationId);
    } else {
      copyState(saved.state);
    }
    return readDirect();
  })();
  // The caller still receives this rejection by awaiting ready/read/dispatch.
  ready.catch(() => {});

  async function outcome(operationId, intentKey) {
    const operation = await storage.call('operation', { operationId });
    if (operation.status !== 'committed') return null;
    const result = operation.result;
    if (operation.method !== 'commit' || result?.app !== app ||
        result.events?.[0]?.data?.intentKey !== intentKey) {
      throw new TaskError('E_OPERATION_REUSED', 'That operation ID belongs to a different request.');
    }
    return result;
  }

  async function perform(intent, operationId) {
    await ready;
    const intentKey = JSON.stringify(intent);
    let committed = await outcome(operationId, intentKey);
    let replayed = Boolean(committed);
    if (!committed) {
      const before = await readDirect();
      const event = acceptedEvent(before.state, intent, operationId);
      const state = reduceTasks(before.state, event);
      try {
        committed = await commitState(state, before.revision, event, operationId);
      } catch (error) {
        // Resolve a lost reply when the storage executor is still reachable.
        try { committed = await outcome(operationId, intentKey); } catch {}
        if (!committed) throw error;
        replayed = true;
      }
    }
    const current = await readDirect();
    const result = {
      ...current,
      committedRevision: committed.revision,
      events: committed.events,
      operationId,
      replayed,
    };
    notify(result);
    return result;
  }

  return Object.freeze({
    ready,
    path: statePath,
    limits: Object.freeze({ tasks: MAX_TASKS, title: MAX_TITLE, undo: MAX_UNDO }),
    async read() {
      const preceding = tail;
      await ready;
      await preceding;
      return readDirect();
    },
    dispatch(action, args = {}, { operationId = crypto.randomUUID() } = {}) {
      let intent;
      try {
        intent = normaliseIntent(action, args);
        if (typeof operationId !== 'string' || !operationId || operationId.length > 128) {
          throw new TaskError('E_OPERATION_ID', 'A bounded operation ID is required.');
        }
      } catch (error) {
        return Promise.reject(error);
      }
      const task = tail.then(() => perform(intent, operationId));
      tail = task.catch(() => {});
      return task;
    },
    subscribe(listener) {
      if (typeof listener !== 'function') throw new TypeError('A state listener must be a function.');
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    async history({ after = 0, limit = 100 } = {}) {
      const preceding = tail;
      await ready;
      await preceding;
      return storage.call('events', { app, after, limit });
    },
  });
}
