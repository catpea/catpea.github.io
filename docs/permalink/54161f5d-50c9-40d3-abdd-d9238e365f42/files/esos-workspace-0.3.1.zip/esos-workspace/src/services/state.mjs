/** Public project data commits reuse the existing event/state/projection transaction. */
export function createStateService({ storage, username }) {
  const directory = '/home/' + username + '/.local/share/programs';
  const application = value => {
    if (typeof value !== 'string' || !/^(project|program|applications)\.[A-Za-z0-9_.:-]{1,100}$/.test(value)) {
      throw new TypeError('Application data uses a project.*, program.*, or applications.* namespace.');
    }
    return value;
  };
  const path = app => directory + '/' + application(app) + '/state.json';
  async function mkdirs(target) {
    let current = '';
    for (const part of target.split('/').filter(Boolean)) { current += '/' + part; await storage.call('mkdir', { path: current }); }
  }
  return Object.freeze({
    async read(app) { app = application(app); return { ...await storage.call('getState', { app }), path: path(app) }; },
    async commit({ app, expectedRevision, state, events, operationId = crypto.randomUUID() }) {
      app = application(app);
      if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0) throw new TypeError('Supply the data revision that was read.');
      const projection = path(app);
      const text = JSON.stringify(state, null, 2);
      if (text === undefined) throw new TypeError('Application data must be JSON data.');
      await mkdirs(projection.slice(0, projection.lastIndexOf('/')));
      return storage.call('commit', { app, expectedRevision, state,
        events: events ?? [{ type: 'data.saved', data: {} }],
        writes: [{ path: projection, text: text + '\n' }], operationId });
    }
  });
}
