// Shared by the page and the generated service worker.
export const OFFLINE_PROTOCOL = 1;
export const OFFLINE_MESSAGE = 'esos.offline.v1';
