import { OFFLINE_MESSAGE, OFFLINE_PROTOCOL } from './offline-protocol.mjs';
import { PACKAGE_ROUTE } from './software/paths.mjs';

export class OfflineError extends Error {
  constructor(code, message, cause) {
    super(message, cause ? { cause } : undefined);
    this.name = 'OfflineError'; this.code = code;
  }
}
const detail = error => String(error?.message ?? error ?? 'Unknown browser error.').slice(0, 600);

/** One lifecycle owns both the Offline indicator and executable package delivery. */
export function createOfflineService({ baseURL = new URL('../', import.meta.url).href,
  workers = globalThis.navigator?.serviceWorker, secure = globalThis.isSecureContext,
  makeChannel = () => new MessageChannel(), installTimeout = 120000, replyTimeout = 5000 } = {}) {
  const base = new URL(baseURL).href, scriptURL = new URL('service-worker.mjs', base).href;
  const subscribers = new Set(), installErrors = new WeakMap(), observedWorkers = new WeakSet(), observedRegistrations = new WeakSet();
  let registration, registrationTask, routeTask, readyWorker, route, updateError, lastInstaller, observing = false;
  let status = Object.freeze({ state: 'idle', ready: false, message: 'Offline installation has not started.' });

  function publish(state, message, extra = {}) {
    status = Object.freeze({ state, ready: Boolean(readyWorker && readyWorker === workers?.controller), message, ...extra });
    for (const callback of subscribers) {
      try { callback(status); } catch (error) { console.error('Offline status observer:', error); }
    }
  }
  function readyNotice() {
    if (!readyWorker || readyWorker !== workers?.controller) return;
    let message = 'Available offline · installed applications ready';
    if (registration?.waiting) message += ' · update ready; save work and close workspace tabs to activate';
    else if (registration?.installing) message += ' · downloading an update';
    else if (updateError) message += ' · update failed: ' + updateError.message;
    publish('ready', message, { build: route.build, updateWaiting: Boolean(registration?.waiting),
      ...(updateError ? { updateError: { code: updateError.code, message: updateError.message } } : {}) });
  }
  function onMessage(event) {
    const data = event.data, worker = event.source;
    if (!worker || worker.scriptURL !== scriptURL || data?.type !== OFFLINE_MESSAGE || data.protocol !== OFFLINE_PROTOCOL) return;
    if (registration && !observedWorkers.has(worker) &&
        ![registration.installing, registration.waiting, registration.active, workers.controller].includes(worker)) return;
    if (data.event === 'install-error') {
      const code = /^E_OFFLINE_[A-Z_]{1,40}$/.test(data.code) ? data.code : 'E_OFFLINE_INSTALL';
      const error = new OfflineError(code, detail(data.message));
      installErrors.set(worker, error);
      if (readyWorker === workers.controller && readyWorker) { updateError = error; readyNotice(); }
      else publish('error', error.message, { code });
    } else if (data.event === 'install-progress') {
      const completed = Number.isSafeInteger(data.completed) ? data.completed : 0;
      const total = Number.isSafeInteger(data.total) ? data.total : 0;
      const prefix = readyWorker === workers.controller && readyWorker ? 'Available offline · downloading update' : 'Installing offline assets';
      publish('installing', prefix + ' · ' + completed + '/' + total,
        { completed, total, path: typeof data.path === 'string' ? data.path : '' });
    }
  }
  function observe() {
    if (observing) return;
    observing = true;
    workers.addEventListener('message', onMessage);
    workers.addEventListener('controllerchange', () => {
      if (readyWorker && readyWorker !== workers.controller) {
        readyWorker = null; route = null;
        publish('connecting', 'Connecting the installed application route…');
      }
      if (workers.controller && !routeTask) ensurePackageRoute().catch(() => {});
    });
    workers.startMessages?.();
  }
  function watchRegistration() {
    if (observedRegistrations.has(registration)) return;
    observedRegistrations.add(registration);
    const watchedRegistration = registration;
    function watch() {
      const worker = watchedRegistration.installing;
      if (worker && !observedWorkers.has(worker)) {
        observedWorkers.add(worker); lastInstaller = worker; updateError = null;
        worker.addEventListener('statechange', () => {
          if (worker.state === 'redundant' && watchedRegistration.active !== worker) {
            updateError = installErrors.get(worker) ?? new OfflineError('E_OFFLINE_INSTALL',
              'Offline installation failed. Check the browser console for the failing asset or storage error.');
            if (registration === watchedRegistration && !watchedRegistration.active) registrationTask = null;
          }
          readyNotice();
          if (worker.state === 'activated' && !routeTask) ensurePackageRoute().catch(() => {});
        });
      }
      readyNotice();
    }
    registration.addEventListener('updatefound', watch); watch();
  }
  async function register() {
    if (!secure) throw new OfflineError('E_OFFLINE_CONTEXT', 'Installed applications require localhost or HTTPS. Open the address printed by npm start.');
    if (!workers?.register) throw new OfflineError('E_OFFLINE_UNAVAILABLE', 'Service workers are unavailable in this browser context. Installed applications need a browser profile that permits service workers.');
    observe();
    if (registration && !registration.active && !registration.installing && !registration.waiting) registrationTask = null;
    if (!registrationTask) {
      registrationTask = Promise.resolve().then(async () => {
        publish('registering', 'Starting offline installation…');
        try {
          registration = await workers.register(scriptURL, { type: 'classic', scope: base, updateViaCache: 'none' });
        } catch (cause) {
          // A failed network update must not disable an already installed worker.
          const existing = await workers.getRegistration?.(base).catch(() => null);
          if (existing?.scope === base && existing.active?.scriptURL === scriptURL) {
            registration = existing;
            updateError = new OfflineError('E_OFFLINE_REGISTER', detail(cause), cause);
          } else throw new OfflineError('E_OFFLINE_REGISTER', 'The browser could not register the offline worker: ' + detail(cause), cause);
        }
        if (registration.scope !== base) throw new OfflineError('E_OFFLINE_SCOPE', 'The offline worker has a different scope from this workspace. Open the workspace at its original address.');
        watchRegistration();
        return registration;
      });
      // Explicitly trying to open again may retry a failed registration.
      registrationTask.catch(() => { registrationTask = null; });
    }
    return registrationTask;
  }
  function waitForActive(reg) {
    if (reg.active?.state === 'activated') return Promise.resolve(reg.active);
    publish('installing', 'Installing and verifying offline assets…');
    return new Promise((resolve, reject) => {
      const watched = new Set();
      let diagnosticTimer, settled = false;
      const timer = setTimeout(() => finish(new OfflineError('E_OFFLINE_TIMEOUT',
        'Offline installation has not completed. Check the Offline progress and connection, then try opening the application again.')), installTimeout);
      function finish(error, worker) {
        if (settled) return;
        settled = true;
        clearTimeout(timer); clearTimeout(diagnosticTimer);
        reg.removeEventListener('updatefound', check);
        workers.removeEventListener('message', check);
        for (const item of watched) item.removeEventListener('statechange', check);
        error ? reject(error) : resolve(worker);
      }
      function check() {
        if (reg.active?.state === 'activated') return finish(null, reg.active);
        const worker = reg.active ?? reg.installing ?? reg.waiting ?? lastInstaller;
        const failure = worker && installErrors.get(worker);
        if (failure) return finish(failure);
        if (!worker || worker.state === 'redundant') {
          // Browser worker-state notifications and message delivery use different
          // task sources. Give an already-posted failure diagnostic time to arrive.
          diagnosticTimer ??= setTimeout(() => finish((worker && installErrors.get(worker)) ??
            new OfflineError('E_OFFLINE_INSTALL', 'The offline worker could not finish installation. Check the browser console for the failing asset or storage error.')), 100);
          return;
        }
        if (!watched.has(worker)) { watched.add(worker); worker.addEventListener('statechange', check); }
      }
      reg.addEventListener('updatefound', check);
      workers.addEventListener('message', check);
      check();
    });
  }
  function unavailableRoute() {
    if (registration?.waiting) return new OfflineError('E_OFFLINE_UPDATE',
      'The installed worker needs this update before it can open applications. Save work, close all eSOS tabs, and reopen the same address.');
    if (registration?.installing) return new OfflineError('E_OFFLINE_UPDATE',
      'The application route update is still installing. When Offline reports the update is ready, save work, close all eSOS tabs, and reopen the same address.');
    return new OfflineError('E_OFFLINE_HANDSHAKE',
      'The active worker did not acknowledge the application route. Save work and reload normally (without Shift). If it persists, check the browser service-worker console.');
  }
  function handshake(worker, claim) {
    if (worker?.scriptURL !== scriptURL) return Promise.reject(new OfflineError('E_OFFLINE_SCOPE',
      'A different service worker controls this page. Open eSOS at its original address.'));
    return new Promise((resolve, reject) => {
      const { port1, port2 } = makeChannel();
      const timer = setTimeout(() => finish(unavailableRoute()), replyTimeout);
      function finish(error, value) {
        clearTimeout(timer); port1.close(); port2.close();
        error ? reject(error) : resolve(value);
      }
      port1.onmessage = ({ data }) => {
        if (data?.type !== OFFLINE_MESSAGE || data.protocol !== OFFLINE_PROTOCOL || data.scope !== base ||
            data.packageRoute !== PACKAGE_ROUTE || typeof data.build !== 'string' || !/^[a-f0-9]{24}$/.test(data.build)) {
          finish(new OfflineError('E_OFFLINE_PROTOCOL', 'The active worker uses an incompatible application route. Save work, close all eSOS tabs, and reopen the same address.')); return;
        }
        if (data.ready !== true) { finish(new OfflineError('E_OFFLINE_CLAIM', detail(data.message))); return; }
        finish(null, Object.freeze({ build: data.build, protocol: data.protocol, scope: data.scope }));
      };
      port1.onmessageerror = () => finish(new OfflineError('E_OFFLINE_PROTOCOL', 'The offline worker returned an unreadable route acknowledgement.'));
      try { worker.postMessage({ type: OFFLINE_MESSAGE, protocol: OFFLINE_PROTOCOL, claim }, [port2]); }
      catch (cause) { finish(new OfflineError('E_OFFLINE_HANDSHAKE', 'The offline worker could not be contacted: ' + detail(cause), cause)); }
    });
  }
  function waitForControl(expected) {
    if (workers.controller === expected) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => finish(new OfflineError('E_OFFLINE_CONTROL',
        'The offline worker is active, but this page is not under its control. Save work and reload normally (without Shift).')), replyTimeout);
      function finish(error) {
        clearTimeout(timer); workers.removeEventListener('controllerchange', changed);
        error ? reject(error) : resolve();
      }
      function changed() { if (workers.controller === expected) finish(); }
      workers.addEventListener('controllerchange', changed); changed();
    });
  }
  function ensurePackageRoute() {
    if (readyWorker && readyWorker === workers?.controller) return Promise.resolve(route);
    if (!routeTask) {
      // Store the shared promise before notifying observers or calling browser
      // adapters, which may themselves synchronously request application launch.
      routeTask = Promise.resolve().then(async () => {
        const reg = await register(), active = await waitForActive(reg);
        publish('connecting', 'Connecting the installed application route…');
        if (!workers.controller) {
          // An already-active worker gets no new activate event after a bypassed
          // navigation. Ask that worker to claim; never activate a waiting update.
          await handshake(active, true);
          await waitForControl(active);
        }
        const controller = workers.controller;
        const result = await handshake(controller, false);
        if (workers.controller !== controller) throw new OfflineError('E_OFFLINE_CONTROL', 'The application route changed during startup. Try opening the application again.');
        readyWorker = controller; route = result; readyNotice();
        return result;
      });
      routeTask.then(() => { routeTask = null; }, error => {
        routeTask = null;
        if (!registration?.active && (!registration?.installing || registration.installing.state === 'redundant')) registrationTask = null;
        publish('error', error.message, { code: error.code ?? 'E_OFFLINE' });
      });
    }
    return routeTask;
  }
  return Object.freeze({ start: ensurePackageRoute, ensurePackageRoute,
    status: () => status,
    subscribe(callback) { subscribers.add(callback); callback(status); return () => subscribers.delete(callback); }
  });
}

// Boot and every package loader use this one instance in a document.
export const offline = createOfflineService();
