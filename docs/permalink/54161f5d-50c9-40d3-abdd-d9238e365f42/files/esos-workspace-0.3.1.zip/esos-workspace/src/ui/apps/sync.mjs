import { element as el, text, button, field, form, submitButton, dataTable } from '../components.mjs';
import { heading, message } from './common.mjs';

export async function buildSync({ os, frame }, options = {}) {
  let active = null, operation = null, root = options.path ?? '~';
  const app = frame('sync', 'Sync', async intent => {
    if (intent.action === 'sync.stop') { active?.abort(new DOMException('Stopped by user', 'AbortError')); return; }
    if (intent.action === 'sync.import') {
      try {
        const file = await os.vfs.read(root.replace(/\/$/, '') + '/' + intent.data.path);
        const result = await os.software.importBundle(JSON.parse(file.text));
        await app.say('Added ' + result.id + ' to Software. Install it there when ready.');
      } catch (error) { await app.say(error.message, true); }
      return;
    }
    if (!['sync.compare', 'sync.run', 'sync.resolve'].includes(intent.action) || operation) return;
    root = intent.fields?.root ?? app.container.querySelector('[name="root"]').value;
    active = new AbortController();
    const signal = active.signal;
    const work = (async () => {
      await app.say(intent.action === 'sync.compare' ? 'Comparing files…' : 'Synchronizing files…');
      await app.ui.set('sync-stop', { props: { disabled: false } });
      await app.ui.set('sync-root', { props: { disabled: true } });
      try {
        if (intent.action === 'sync.run') await os.sync.run({ root, signal, onProgress: value => app.say(value.action + ' · ' + value.path) });
        else if (intent.action === 'sync.resolve') await os.sync.resolve(intent.data.path, intent.data.choice, { root, signal });
        const plan = await os.sync.compare({ root, signal }); root = plan.root;
        await app.ui.set('sync-root', { props: { value: root } });
        app.changed();
        const changed = plan.rows.filter(row => row.action !== 'same');
        await table.update(changed.slice(0, 200).map(row => ({ key: row.path, cells: [row.path, row.action,
          row.action === 'conflict' && row.local ? button('local', 'Keep browser', 'sync.resolve', { path: row.path, choice: 'local' }) : '',
          row.action === 'conflict' && row.remote ? button('remote', 'Use Linux', 'sync.resolve', { path: row.path, choice: 'remote' }) : '' ] })));
        const packages = plan.rows.filter(row => row.path.endsWith('.esospkg.json') && row.local);
        await packageTable.update(packages.slice(0, 100).map(row => ({ key: row.path, cells: [row.path,
          button('import', 'Add to Software', 'sync.import', { path: row.path })] })));
        await app.say(plan.rows.length + ' files compared with ' + plan.peer.label + '. ' + changed.length +
          ' differences; ' + plan.skipped.length + ' Linux entries skipped. ' + (changed.length > 200 ? 'Showing the first 200 differences.' : ''));
      } catch (failure) { await app.say(signal.aborted ? 'Synchronization stopped. Completed file writes remain saved.' : failure.message, !signal.aborted); }
      finally {
        await app.ui.set('sync-stop', { props: { disabled: true } });
        await app.ui.set('sync-root', { props: { disabled: false } }); active = null; operation = null;
      }
    })();
    operation = work;
    work.catch(failure => { if (!app.disposed) app.say(failure.message, true).catch(() => {}); });
  });
  const table = dataTable(app.ui, { id: 'sync-table', caption: 'File differences', columns: ['File', 'Change', 'Browser copy', 'Linux copy'], limit: 200 });
  const packageTable = dataTable(app.ui, { id: 'shared-programs', caption: 'Shared program bundles', columns: ['Program bundle', 'Software'], limit: 100 });
  await app.ui.tree([
    heading('Sync', 'Compare ordinary files with a Linux folder. Changed files transfer only after comparison; conflicts remain available for a deliberate choice.'),
    form('sync-form', { action: 'sync.compare', fields: ['root'], className: 'component-inline-form' }, [
      field('sync-root', { name: 'root', label: 'Browser folder', value: root, attrs: { maxlength: '4096' } }), submitButton('sync-compare', 'Compare')]),
    el('div', 'sync-actions', { class: 'app-actions' }, [button('sync-run', 'Synchronize', 'sync.run'),
      el('button', 'sync-stop', { text: 'Stop', attrs: { type: 'button' }, class: 'btn-text btn-sm', props: { disabled: true }, on: { click: 'sync.stop' } })]),
    message(), table.tree,
    text('p', 'sync-policy', 'Hidden configuration, devices, and application state are excluded. Deletions are never propagated automatically. Choose Keep browser or Use Linux to resolve a conflict.', 'app-note'),
    text('h3', 'shared-title', 'Shared programs', 'section-title'), packageTable.tree,
    text('p', 'sync-setup', 'To connect a dedicated Linux folder, start the local server with ESOS_PEER_DIR=/path/to/shared npm start. The browser remains usable without this connection. You can synchronize that ordinary directory with rsync.', 'app-note')
  ]);
  const peer = await os.sync.status();
  await app.say(peer.enabled ? 'Connected to ' + peer.label + '. Compare before transferring.' : (peer.message ?? 'No Linux folder is connected.'));
  app.beforeClose = async () => { active?.abort(new DOMException('Window closed', 'AbortError')); await operation; return true; };
  app.cleanup.push(() => active?.abort());
  app.sessionOptions = () => ({ path: root });
  return app;
}
