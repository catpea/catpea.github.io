import { element as el, text, button, submitButton, form, field, dataTable } from '../components.mjs';
import { heading, message, formatError, resolvePath, filterText, refresher } from './common.mjs';

const EDITOR_LIMIT = 65536;
const parentPath = path => path.slice(0, path.lastIndexOf('/')) || '/';
const programFile = entry => entry.kind === 'file' && /\.(esos|esospkg)\.json$/i.test(entry.name);

export async function buildFiles({ frame, os, onError }, options = {}) {
  const home = '/home/' + os.profile.username;
  let app, listing;
  let directory = resolvePath(options.directory ?? home, home, os.profile.username);
  const initialPath = options.path ? resolvePath(options.path, home, os.profile.username) : null;
  if (initialPath && options.directory === undefined) directory = parentPath(initialPath);
  let editorBase = directory;
  let filter = filterText(options.filter);
  let editor = { path: null, revision: 0, text: '', displayPath: directory + '/untitled.txt', readOnly: false };
  let documentGeneration = crypto.randomUUID();
  let changing = false, composing = false, draftVersion = 0;
  const nativeLifetime = new AbortController();
  const resolveName = value => resolvePath(value, editorBase, os.profile.username);
  const controls = () => ({
    name: app.container.querySelector('[name="path"]'),
    content: app.container.querySelector('[name="content"]')
  });
  function draft() {
    const { name, content } = controls();
    return { path: name?.value ?? editor.displayPath, text: content?.value ?? editor.text,
      start: content?.selectionStart ?? 0, end: content?.selectionEnd ?? 0, version: draftVersion };
  }
  function hasDraft() {
    if (!app || app.disposed) return false;
    const value = draft();
    return value.path !== editor.displayPath || value.text !== editor.text;
  }
  function updateMetadata() {
    if (app.disposed) return;
    app.setTitle(editor.path ? editor.path.split('/').at(-1) + ' — Files' : 'Untitled — Files');
    app.setDirty(hasDraft());
  }
  function projectKind() {
    try { const value = JSON.parse(editor.text); return value.format === 'esos.project' ? value.kind : null; }
    catch { return null; }
  }
  async function updateProgramActions() {
    let program = false;
    try { program = ['esos.project', 'esos.package'].includes(JSON.parse(editor.text)?.format); } catch {}
    await app.ui.send([
      { op: 'set', id: 'open-program', props: { disabled: !editor.path || !program } },
      { op: 'set', id: 'edit-project', props: { disabled: !editor.path || !projectKind() } }
    ]);
  }
  const mayReplaceDraft = () => !hasDraft() || window.confirm('Discard the unsaved changes in this Files window?');
  function beforeUnload(event) {
    if (hasDraft()) { event.preventDefault(); event.returnValue = ''; }
  }

  async function renderListing(entries) {
    if (app.disposed) return;
    const needle = filter.trim().toLocaleLowerCase();
    const matching = entries.filter(entry => !needle || entry.name.toLocaleLowerCase().includes(needle));
    const shown = matching.slice(0, 300);
    await listing.update(shown.map(entry => ({
      key: entry.path,
      cells: [
        button('entry', (entry.kind === 'directory' ? '▸ ' : entry.kind === 'device' ? '◇ ' : '') + entry.name,
          entry.kind === 'directory' ? 'files.directory' : programFile(entry) ? 'files.program' : 'files.open', { path: entry.path }, 'btn-text table-name'),
        entry.kind === 'directory' ? 'Folder' : entry.kind === 'device' ? 'Device' : programFile(entry) ? 'Program' : 'Text',
        entry.revision ? String(entry.revision) : '—'
      ]
    })));
    await app.ui.send([
      { op: 'set', id: 'directory', text: directory },
      { op: 'set', id: 'parent-directory', props: { disabled: directory === '/' } },
      { op: 'set', id: 'directory-empty', props: { hidden: shown.length > 0 },
        text: entries.length ? 'No entries match this filter.' : 'This directory is empty.' },
      { op: 'set', id: 'directory-count', text: matching.length > 300
        ? 'Showing 300 of ' + matching.length + ' matching entries. Use ls for the complete listing.'
        : shown.length + ' shown · ' + entries.length + ' entries' }
    ]);
  }
  const refreshList = refresher(async () => {
    if (app.disposed) return;
    const requested = directory;
    const entries = await os.vfs.list(requested);
    if (!app.disposed && directory === requested) await renderListing(entries);
  }, error => { if (!app.disposed) onError(error); });

  async function browse(path) {
    const next = resolvePath(path, directory, os.profile.username);
    const entries = await os.vfs.list(next);
    if (app.disposed) return;
    directory = next;
    await renderListing(entries);
    app.changed();
  }
  async function replaceEditor(loader, { confirm = true } = {}) {
    if (composing) throw new Error('Finish composing text before replacing this document.');
    if (confirm && !mayReplaceDraft()) return false;
    const version = draftVersion;
    changing = true;
    try {
      await app.ui.send([
        { op: 'set', id: 'editor-fields', props: { disabled: true } },
        { op: 'set', id: 'save', props: { disabled: true } }
      ]);
      if (draftVersion !== version) throw new Error('The draft changed while the document was opening. Try again.');
      const next = await loader();
      if (app.disposed) return false;
      if (next.text.length > EDITOR_LIMIT) throw new Error('This editor opens up to 65,536 characters. Use cat to read this larger file.');
      const generation = crypto.randomUUID();
      const acknowledgements = await app.ui.send([
        { op: 'set', id: 'file-name', props: { value: next.displayPath, readOnly: next.readOnly } },
        { op: 'set', id: 'file-text', props: { value: next.text, readOnly: next.readOnly } },
        { op: 'set', id: 'document-generation', props: { value: generation } },
        { op: 'set', id: 'reload-file', props: { disabled: !next.path } }
      ]);
      if (acknowledgements.some(ack => ack.skipped?.length)) throw new Error('The editor is still composing text. Finish the input and open the document again.');
      editor = next;
      documentGeneration = generation;
      editorBase = next.path ? parentPath(next.path) : directory;
      draftVersion++;
      updateMetadata(); app.changed();
      return true;
    } finally {
      changing = false;
      if (!app.disposed) await app.ui.send([
        { op: 'set', id: 'editor-fields', props: { disabled: false } },
        { op: 'set', id: 'save', props: { disabled: editor.readOnly } }
      ]);
    }
  }
  async function openFile(path, confirm = true) {
    const opened = await replaceEditor(async () => {
      const file = await os.vfs.read(path);
      return { path: file.path, revision: file.revision, text: file.text,
        displayPath: file.path, readOnly: Boolean(file.managedBy || file.virtual) };
    }, { confirm });
    if (opened) {
      await updateProgramActions();
      await app.say(editor.readOnly
        ? 'Read-only system or application state. Use its commands to change it.'
        : 'Opened revision ' + editor.revision + '.');
    }
  }
  async function paste(source) {
    if (editor.readOnly) throw new Error('This document is read-only. Open a new file to paste text.');
    if (composing) throw new Error('Finish composing text before using a paste button.');
    const before = draft();
    // Call the native service before awaiting anything, while the click is active.
    const copied = await os.clipboard.readText(source === 'workspace' ? { source: 'workspace' } : {});
    if (app.disposed) return;
    const current = draft();
    if (current.version !== before.version || current.path !== before.path || current.text !== before.text ||
        current.start !== before.start || current.end !== before.end || composing) {
      throw new Error('The draft or selection changed while reading the clipboard. Your text was kept; paste again.');
    }
    const next = before.text.slice(0, before.start) + copied.text + before.text.slice(before.end);
    if (next.length > EDITOR_LIMIT) throw new Error('The pasted text would exceed this editor’s 65,536-character limit.');
    const acknowledgements = await app.ui.send([
      { op: 'set', id: 'file-text', ifValue: before.text, props: { value: next } }
    ]);
    if (acknowledgements.some(ack => ack.skipped?.length)) throw new Error('The draft changed before paste completed. Your text was kept; paste again.');
    draftVersion++;
    updateMetadata();
    const content = controls().content;
    content.focus({ preventScroll: true });
    const caret = before.start + copied.text.length;
    content.setSelectionRange(caret, caret);
    await app.say('Pasted ' + copied.text.length + ' characters from the ' +
      (copied.source === 'workspace' ? 'workspace copy' : 'system clipboard') + '. Save to commit this draft.');
  }

  app = frame('files', 'Files', async intent => {
    try {
      if (intent.action === 'files.directory') await browse(intent.data.path);
      else if (intent.action === 'files.parent') await browse(parentPath(directory));
      else if (intent.action === 'files.open') await openFile(intent.data.path);
      else if (intent.action === 'files.program') await os.views.openDocument(intent.data.path, { newWindow: true });
      else if (intent.action === 'files.reload') { if (editor.path) await openFile(editor.path); }
      else if (intent.action === 'files.new') {
        const replaced = await replaceEditor(async () => ({ path: null, revision: 0, text: '',
          displayPath: directory.replace(/\/$/, '') + '/untitled.txt', readOnly: false }));
        if (replaced) { await updateProgramActions(); await app.say('New local text file.'); }
      } else if (intent.action === 'files.new-window') {
        await os.views.open('files', { directory, newWindow: true });
      } else if (intent.action === 'files.filter') {
        filter = filterText(intent.fields.query);
        await refreshList(); app.changed();
      } else if (intent.action === 'files.refresh') await refreshList();
      else if (intent.action === 'files.save') {
        if (changing || editor.readOnly) throw new Error('This editor is not writable right now.');
        if (intent.fields.generation !== documentGeneration) throw new Error('That save belonged to the previous document. The current document was kept unchanged.');
        const path = resolveName(intent.fields.path);
        const result = await os.vfs.write(path, intent.fields.content, {
          expectedRevision: path === editor.path ? editor.revision : 0, operationId: intent.eventId
        });
        if (app.disposed) return;
        editor = { path: result.path, revision: result.revision, text: intent.fields.content,
          displayPath: intent.fields.path, readOnly: false };
        updateMetadata(); app.changed();
        await app.ui.set('reload-file', { props: { disabled: false } });
        await updateProgramActions();
        await app.say('Saved locally · revision ' + result.revision + (hasDraft() ? '. Newer typing is still an unsaved draft.' : '.'));
        await refreshList();
      } else if (intent.action === 'files.run-program' || intent.action === 'files.edit-project') {
        if (hasDraft()) throw new Error('Save this document before opening it in another application.');
        if (!editor.path) throw new Error('Open a saved project or program bundle first.');
        if (intent.action === 'files.run-program') await os.views.openDocument(editor.path, { newWindow: true });
        else {
          const application = ({ form: 'workbench', cards: 'cards', workflow: 'automate' })[projectKind()];
          if (!application) throw new Error('This is not an editable project document.');
          if (!os.views.list().some(item => item.id === application)) throw new Error('Install ' + application + ' from Software to edit this project.');
          await os.views.open(application, { path: editor.path, newWindow: true });
        }
      } else if (intent.action === 'files.copy' || intent.action === 'files.copy-path') {
        const value = draft();
        const copied = await os.clipboard.writeText(intent.action === 'files.copy' ? value.text : resolveName(value.path));
        await app.say(copied.source === 'system'
          ? 'Copied to the system clipboard and workspace copy.'
          : 'Copied within this workspace. Use Paste workspace copy; the system clipboard was unavailable.');
      } else if (intent.action === 'files.paste') await paste('system');
      else if (intent.action === 'files.paste-workspace') await paste('workspace');
      else if (intent.action === 'files.export') {
        await os.system.export(); await app.say('Workspace export downloaded.');
      }
    } catch (error) { await app.say(formatError(error), true); }
  });
  listing = dataTable(app.ui, { id: 'files-table', caption: 'Directory entries', columns: ['Name', 'Kind', 'Revision'], limit: 300 });
  await app.ui.tree([
    heading('Your files, here.', 'Keep documents in separate windows. Each editor retains its own draft and opened revision.'),
    el('div', 'file-toolbar', { class: 'app-toolbar' }, [
      el('div', 'file-navigation', { class: 'app-actions' }, [
        button('parent-directory', 'Parent folder', 'files.parent'), button('refresh-files', 'Refresh', 'files.refresh')
      ]),
      el('div', 'file-actions', { class: 'app-actions' }, [
        button('new-file', 'New file', 'files.new'), button('new-window', 'New window', 'files.new-window')
      ])
    ]),
    text('p', 'directory', directory, 'file-path'),
    el('div', 'file-workspace', { class: 'file-workspace' }, [
      el('section', 'directory-pane', { class: 'directory-pane', attrs: { 'aria-label': 'Directory browser' } }, [
        form('filter-form', { action: 'files.filter', fields: ['query'], className: 'component-inline-form' }, [
          field('file-filter', { label: 'Filter this folder', name: 'query', type: 'search', value: filter,
            attrs: { maxlength: '128', placeholder: 'Filename contains…', autocomplete: 'off' } }),
          submitButton('filter-button', 'Filter', 'btn-outline theme-secondary btn-sm')
        ]),
        listing.tree,
        text('p', 'directory-empty', '', 'empty-state'), text('p', 'directory-count', '', 'app-note')
      ]),
      el('section', 'document-pane', { class: 'document-pane', attrs: { 'aria-label': 'Text editor' } }, [
        form('editor', { action: 'files.save', fields: ['path', 'content', 'generation'], className: 'editor-form' }, [
          el('input', 'document-generation', { attrs: { type: 'hidden', name: 'generation' }, props: { value: documentGeneration } }),
          el('fieldset', 'editor-fields', { class: 'editor-fields' }, [
            field('file-name', { label: 'File path', name: 'path', value: editor.displayPath,
              attrs: { required: '', autocomplete: 'off', maxlength: '4096' } }),
            field('file-text', { label: 'Contents', name: 'content', multiline: true,
              attrs: { spellcheck: 'false', maxlength: String(EDITOR_LIMIT) } })
          ]),
          el('div', 'save-actions', { class: 'app-actions' }, [
            submitButton('save', 'Save locally', 'btn-solid theme-primary'),
            { ...button('reload-file', 'Reload saved', 'files.reload'), props: { disabled: true } }
          ])
        ]),
        el('div', 'clipboard-actions', { class: 'app-actions clipboard-actions' }, [
          button('copy-text', 'Copy text', 'files.copy'), button('paste-text', 'Paste text', 'files.paste'),
          button('paste-workspace', 'Paste workspace copy', 'files.paste-workspace'), button('copy-path', 'Copy path', 'files.copy-path')
        ]),
        el('div', 'project-actions', { class: 'app-actions' }, [
          { ...button('open-program', 'Open program / bundle', 'files.run-program'), props: { disabled: true } },
          { ...button('edit-project', 'Edit project', 'files.edit-project'), props: { disabled: true } }
        ]),
        text('p', 'files-note', 'Ctrl+S saves this editor. Native Ctrl+C and Ctrl+V still work. A newer stored revision is preserved if another window or command changes the file.', 'app-note')
      ])
    ]),
    message(),
    el('div', 'file-footer', { class: 'app-actions' }, [button('export', 'Export workspace', 'files.export', {}, 'btn-text btn-sm')])
  ]);

  app.beforeClose = mayReplaceDraft;
  app.resourcePath = () => editor.path;
  app.sessionOptions = () => ({ directory, filter, ...(editor.path ? { path: editor.path } : {}) });
  app.didMount = updateMetadata;
  app.container.addEventListener('input', event => {
    if (event.target.matches('[name="path"],[name="content"]')) { draftVersion++; updateMetadata(); }
  }, { signal: nativeLifetime.signal });
  app.container.addEventListener('compositionstart', event => {
    if (event.target.matches('[name="path"],[name="content"]')) composing = true;
  }, { signal: nativeLifetime.signal });
  app.container.addEventListener('compositionend', () => { composing = false; }, { signal: nativeLifetime.signal });
  app.container.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 's' && !event.altKey && !event.isComposing) {
      event.preventDefault();
      if (!changing && !editor.readOnly) app.container.querySelector('form.editor-form').requestSubmit();
    }
  }, { signal: nativeLifetime.signal });
  window.addEventListener('beforeunload', beforeUnload);
  app.cleanup.push(() => nativeLifetime.abort(), () => window.removeEventListener('beforeunload', beforeUnload));
  app.cleanup.push(os.observe(() => { refreshList().catch(() => {}); }));
  if (initialPath) await openFile(initialPath, false);
  await refreshList();
  updateMetadata();
  return app;
}
