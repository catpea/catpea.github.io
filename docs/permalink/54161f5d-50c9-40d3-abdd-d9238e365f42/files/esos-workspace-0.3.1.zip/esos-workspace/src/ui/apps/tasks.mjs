import { element as el, text, button, submitButton, form, field, compileTree } from '../components.mjs';
import { heading, message, formatError, refresher } from './common.mjs';

export async function buildTasks({ frame, os, onError }, options = {}) {
  let app;
  let known = new Set(), renderedOrder = [];
  let filter = ['all', 'open', 'completed'].includes(options.filter) ? options.filter : 'all';

  async function refresh() {
    if (app.disposed) return;
    const snapshot = await os.tasks.read();
    if (app.disposed) return;
    const state = snapshot.state;
    const all = state.items;
    const items = all.filter(item => filter === 'all' || (filter === 'completed' ? item.done : !item.done));
    const current = new Set(items.map(item => item.id));
    const nextKnown = new Set(known);
    const nextOrder = renderedOrder.filter(id => current.has(id));
    const ops = [
      { op: 'set', id: 'count', text: all.filter(item => !item.done).length + ' open · ' + all.length + ' total' },
      { op: 'set', id: 'revision', text: 'Committed revision ' + snapshot.revision },
      { op: 'set', id: 'empty', props: { hidden: items.length > 0 },
        text: all.length ? 'No tasks match this view.' : 'Add a task here or use tasks add in the terminal.' },
      { op: 'set', id: 'undo', props: { disabled: !state.undo.length } },
      { op: 'set', id: 'clear-completed', props: { disabled: !all.some(item => item.done) } }
    ];
    for (const id of known) if (!current.has(id)) {
      ops.push({ op: 'remove', id: 'task-' + id }); nextKnown.delete(id);
    }
    for (const item of items) {
      const id = item.id;
      if (!known.has(id)) {
        ops.push(...compileTree(el('li', 'task-' + id, { class: 'task-row' }, [
          el('input', 'check-' + id, {
            attrs: { type: 'checkbox', 'aria-label': 'Complete ' + item.title },
            props: { checked: item.done }, on: { change: 'tasks.toggle' }, data: { id }
          }),
          el('label', 'label-' + id, { text: item.title,
            class: 'task-label' + (item.done ? ' complete' : ''), attrs: { for: 'check-' + id } }),
          text('span', 'short-' + id, id.slice(0, 6), 'task-id'),
          button('remove-' + id, 'Remove', 'tasks.remove', { id }, 'btn-text btn-xs')
        ]), 'list'));
        nextKnown.add(id); nextOrder.push(id);
      } else {
        ops.push(
          { op: 'set', id: 'check-' + id, props: { checked: item.done } },
          { op: 'set', id: 'label-' + id, text: item.title, class: 'task-label' + (item.done ? ' complete' : '') }
        );
      }
    }
    for (const [index, item] of items.entries()) {
      if (nextOrder[index] === item.id) continue;
      const before = nextOrder[index];
      ops.push({ op: 'place', id: 'task-' + item.id, parent: 'list', ...(before ? { before: 'task-' + before } : {}) });
      nextOrder.splice(nextOrder.indexOf(item.id), 1); nextOrder.splice(index, 0, item.id);
    }
    await app.ui.send(ops);
    known = nextKnown; renderedOrder = nextOrder;
  }
  const schedule = refresher(refresh, error => { if (!app.disposed) onError(error); });

  app = frame('tasks', 'Tasks', async intent => {
    try {
      if (intent.action === 'tasks.add') {
        const title = intent.fields.title;
        await os.tasks.dispatch('add', { title }, { operationId: intent.eventId });
        if (app.disposed) return;
        await app.ui.send([{ op: 'set', id: 'task-title', ifValue: title, props: { value: '' } }]);
        await app.say('Task saved locally.');
      } else if (intent.action === 'tasks.toggle') {
        await os.tasks.dispatch('toggle', { id: intent.data.id, done: intent.checked }, { operationId: intent.eventId });
        await app.say('Change saved locally.');
      } else if (intent.action === 'tasks.remove') {
        await os.tasks.dispatch('remove', { id: intent.data.id }, { operationId: intent.eventId });
        await app.say('Task removed. Undo restores it.');
      } else if (intent.action === 'tasks.undo') {
        await os.tasks.dispatch('undo', {}, { operationId: intent.eventId });
        await app.say('Previous change undone. Its history is retained.');
      } else if (intent.action === 'tasks.clear-completed') {
        await os.tasks.dispatch('clear-completed', {}, { operationId: intent.eventId });
        await app.say('Completed tasks cleared. Undo restores them.');
      } else if (intent.action === 'tasks.filter') {
        if (['all', 'open', 'completed'].includes(intent.value)) { filter = intent.value; app.changed(); }
      } else if (intent.action === 'tasks.new-window') {
        await os.views.open('tasks', { newWindow: true, filter });
      }
      await schedule();
    } catch (error) {
      await app.say(formatError(error), true);
      await schedule().catch(() => {});
    }
  });
  app.sessionOptions = () => ({ filter });
  await app.ui.tree([
    heading('Make room for the next thing.', 'Every Tasks window and terminal command uses the same committed state.'),
    form('add-form', { action: 'tasks.add', fields: ['title'], className: 'task-add' }, [
      field('task-title', { label: 'Next task', name: 'title', className: 'field-grow',
        attrs: { placeholder: 'What would you like to do?', maxlength: '240', required: '', autocomplete: 'off' } }),
      submitButton('add-button', 'Add task', 'btn-solid theme-primary')
    ]),
    el('div', 'task-tools', { class: 'app-toolbar' }, [
      el('div', 'task-filter-field', { class: 'component-field compact-field' }, [
        el('label', 'task-filter-label', { text: 'Show', attrs: { for: 'task-filter' } }),
        el('select', 'task-filter', { class: 'form-control', props: { value: filter }, on: { change: 'tasks.filter' } },
          [['all', 'All tasks'], ['open', 'Open tasks'], ['completed', 'Completed tasks']].map(([value, label]) =>
            el('option', 'filter-' + value, { text: label, props: { value } })))
      ]),
      button('new-window', 'New window', 'tasks.new-window')
    ]),
    el('div', 'summary', { class: 'task-summary' }, [
      text('strong', 'list-label', 'Your tasks'), text('span', 'count', '', 'task-count'),
      button('undo', 'Undo', 'tasks.undo', {}, 'btn-text btn-sm')
    ]),
    el('ul', 'list', { class: 'task-list' }),
    text('p', 'empty', '', 'empty-state'), message(),
    el('div', 'task-footer', { class: 'app-toolbar' }, [
      text('p', 'revision', '', 'app-note'), button('clear-completed', 'Clear completed', 'tasks.clear-completed', {}, 'btn-text btn-sm')
    ])
  ]);
  app.cleanup.push(os.tasks.subscribe(() => { schedule().catch(() => {}); }));
  await schedule();
  return app;
}
