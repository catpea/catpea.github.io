// Components compile to the same small device protocol used by commands.
// This module does not mutate the DOM.
export const element = (tag, id, options = {}, children = []) => ({ tag, id, ...options, children });
export const text = (tag, id, value, className = '') => element(tag, id, { text: value, class: className });
export const button = (id, label, action, data = {}, className = 'btn-outline theme-secondary btn-sm') =>
  element('button', id, { text: label, class: className, attrs: { type: 'button' }, on: { click: action }, data });

export const submitButton = (id, label, className = 'btn-solid theme-primary btn-sm') =>
  element('button', id, { text: label, class: className, attrs: { type: 'submit' } });

/** Native form semantics; the device serializes only these named fields. */
export function form(id, { action, fields = [], className = '', attrs = {} }, children = []) {
  return element('form', id, { class: className, attrs, fields, on: { submit: action } }, children);
}

/** A labelled native field. Control values are explicit, not render-owned drafts. */
export function field(id, { label, name, type = 'text', multiline = false, value,
  attrs = {}, props = {}, className = '', on, hint } = {}) {
  const control = element(multiline ? 'textarea' : 'input', id, {
    class: 'form-control', attrs: { ...(multiline ? {} : { type }), name, ...attrs,
      ...(hint ? { 'aria-describedby': id + '-hint' } : {}) },
    props: { ...props, ...(value === undefined ? {} : { value }) }, ...(on ? { on } : {})
  });
  return element('div', id + '-field', { class: 'component-field ' + className }, [
    element('label', id + '-label', { text: label, attrs: { for: id } }), control,
    ...(hint ? [text('p', id + '-hint', hint, 'field-hint')] : [])
  ]);
}

/**
 * A bounded native table with stable keyed rows. A row has {key,cells:[]}; a cell
 * is text or a leaf element definition. Unchanged rows keep their native elements.
 */
export function dataTable(ui, { id, caption, columns, limit = 300, className = '' }) {
  if (!/^[A-Za-z][A-Za-z0-9_-]{0,48}$/.test(id) || !Array.isArray(columns) || !columns.length || columns.length > 8) {
    throw new TypeError('A table needs a short local ID and named columns.');
  }
  if (!Number.isInteger(limit) || limit < 1 || limit > 300) throw new RangeError('A table supports 1–300 rows.');
  columns = Object.freeze([...columns]);
  let rows = new Map(), order = [], sequence = 0, tail = Promise.resolve();
  const tree = element('div', id + '-scroll', { class: 'data-table-scroll' }, [
    element('table', id, { class: 'table data-table ' + className }, [
      text('caption', id + '-caption', caption, 'visually-hidden'),
      element('thead', id + '-head', {}, [
        element('tr', id + '-head-row', {}, columns.map((column, index) =>
          element('th', id + '-heading-' + index, { text: column, attrs: { scope: 'col' } })))
      ]),
      element('tbody', id + '-body')
    ])
  ]);
  function rowTree(row, rowId) {
    return element('tr', rowId, {}, row.cells.map((cell, index) => {
      const cellId = rowId + '-c' + index;
      return typeof cell === 'object' && cell !== null
        ? element('td', cellId, {}, [{ ...cell, id: cellId + '-value' }])
        : element('td', cellId, { text: String(cell ?? '') });
    }));
  }
  return Object.freeze({
    tree,
    update(values) {
      if (!Array.isArray(values) || values.length > limit) return Promise.reject(new RangeError('Too many table rows.'));
      const records = structuredClone(values);
      const work = tail.then(async () => {
        const next = new Map(), desired = [], ops = [];
        let nodes = 7 + columns.length;
        for (const row of records) {
          if (typeof row.key !== 'string' || !Array.isArray(row.cells) || row.cells.length !== columns.length || next.has(row.key)) {
            throw new TypeError('A table row needs a unique key and one cell for each column.');
          }
          nodes += 1 + row.cells.length;
          for (const cell of row.cells) {
            if (cell && typeof cell === 'object') {
              if (Array.isArray(cell) || typeof cell.tag !== 'string' ||
                  (cell.children !== undefined && (!Array.isArray(cell.children) || cell.children.length))) {
                throw new TypeError('An element table cell must be a leaf definition.');
              }
              nodes++;
            }
          }
          if (nodes > 1800) throw new RangeError('This table exceeds its 1,800-node budget.');
          const previous = rows.get(row.key);
          const fingerprint = JSON.stringify(row.cells);
          const entry = { id: previous?.id ?? id + '-r' + (++sequence), fingerprint };
          next.set(row.key, entry);
          desired.push(row.key);
        }
        const present = order.filter(key => next.has(key) && rows.get(key).fingerprint === next.get(key).fingerprint);
        for (const [key, value] of rows) {
          if (!next.has(key) || value.fingerprint !== next.get(key).fingerprint) ops.push({ op: 'remove', id: value.id });
        }
        for (const row of records) {
          const entry = next.get(row.key);
          if (!rows.has(row.key) || rows.get(row.key).fingerprint !== entry.fingerprint) {
            ops.push(...compileTree(rowTree(row, entry.id), id + '-body'));
            present.push(row.key);
          }
        }
        for (const [index, key] of desired.entries()) {
          if (present[index] === key) continue;
          const before = next.get(present[index]);
          ops.push({ op: 'place', id: next.get(key).id, parent: id + '-body', ...(before ? { before: before.id } : {}) });
          present.splice(present.indexOf(key), 1);
          present.splice(index, 0, key);
        }
        if (ops.length) await ui.send(ops);
        rows = next; order = desired;
        return { rows: desired.length };
      });
      tail = work.catch(() => {});
      return work;
    }
  });
}

export function compileTree(tree, parent = 'root') {
  const ops = [];
  function visit(node, target) {
    const { children = [], ...definition } = node;
    ops.push({ op: 'create', ...definition }, { op: 'place', id: node.id, parent: target });
    for (const child of children) visit(child, node.id);
  }
  for (const node of Array.isArray(tree) ? tree : [tree]) visit(node, parent);
  return ops;
}

export function writer(device) {
  let tail = Promise.resolve();
  const send = ops => {
    const work = tail.then(async () => {
      const acknowledgements = [];
      for (let offset = 0; offset < ops.length; offset += 128) {
        acknowledgements.push(await device.write({
          op: 'batch', id: crypto.randomUUID(), base: device.revision,
          ops: ops.slice(offset, offset + 128)
        }));
      }
      return acknowledgements;
    });
    tail = work.catch(() => {});
    return work;
  };
  return {
    send,
    tree: (tree, parent) => send(compileTree(tree, parent)),
    set: (id, values) => send([{ op: 'set', id, ...values }])
  };
}
