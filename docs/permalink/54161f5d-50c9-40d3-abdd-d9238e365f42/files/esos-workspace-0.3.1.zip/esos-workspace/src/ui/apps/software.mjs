import { element as el, text, button, submitButton, form, field, dataTable } from '../components.mjs';
import { heading, message, formatError, refresher } from './common.mjs';

function download(filename, value) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(value) + '\n'], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = filename; anchor.hidden = true;
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** The repair/install surface is part of core; optional editors never are. */
export async function buildSoftware({ frame, os, onError }, options = {}) {
  let app, table, selected = null, filter = 'all', path = typeof options.path === 'string' ? options.path : '', picker = null;
  const software = os.software;
  function choose(id) { selected = id; app.changed(); }
  async function refresh() {
    if (app.disposed) return;
    const rows = software.list();
    if (selected && !rows.some(item => item.id === selected)) selected = null;
    if (!selected && rows.length) selected = rows.find(item => item.id === 'applications.automate')?.id ?? rows[0].id;
    const visible = rows.filter(item => filter === 'all' || (filter === 'installed' ? item.installed : item.kind === 'project'));
    await table.update(visible.map(item => ({ key: item.id, cells: [
      button('select', item.title, 'software.select', { id: item.id }, 'btn-text btn-sm'),
      item.kind === 'project' ? 'Your program' : item.applications.length ? 'Application' : 'Shared runtime',
      item.state === 'repair-required' ? 'Repair required' : item.state === 'installed' ? 'Installed' : item.state === 'disabled' ? 'Disabled' : 'Available',
      item.kind === 'project' ? 'Local data' : Math.ceil(item.bytes / 1024) + ' KiB',
      button('action', item.installed && item.enabled && item.applications.length ? 'Open' : item.installed ? 'Details' : 'Install',
        item.installed && item.enabled && item.applications.length ? 'software.open' : item.installed ? 'software.select' : 'software.install', { id: item.id })
    ] })));
    const details = selected ? software.inspect(selected) : null;
    await app.ui.send([
      { op: 'set', id: 'catalog-count', text: rows.filter(item => item.installed).length + ' installed packages · ' + rows.filter(item => item.kind === 'project').length + ' published programs' },
      { op: 'set', id: 'package-title', text: details?.title ?? 'Choose a package' },
      { op: 'set', id: 'package-description', text: details?.description ?? 'Available software is listed above.' },
      { op: 'set', id: 'package-id', text: details ? details.id + ' · ' + details.version + (details.updateAvailable ? ' · available: ' + details.availableVersion : '') : '' },
      { op: 'set', id: 'package-status', text: details ? (details.problem ?? (details.installed ? (details.enabled ? 'Available to launch.' : 'Disabled; executable assets and data are retained.') : 'Available to install.')) : '' },
      { op: 'set', id: 'package-dependencies', text: details?.dependencies.length ? 'Requires: ' + details.dependencies.map(item => item.id + '@' + item.version).join(', ') : 'No optional package dependencies.' },
      { op: 'set', id: 'package-reasons', text: details?.reasons.length ? 'Installed for: ' + details.reasons.join(', ') : '' },
      { op: 'set', id: 'package-dependents', text: details?.dependents.length ? 'Required by: ' + details.dependents.join(', ') : '' },
      { op: 'set', id: 'package-path', text: details?.bundlePath ? 'Portable bundle: ' + details.bundlePath : '' },
      { op: 'set', id: 'install-selected', props: { disabled: !details || (details.installed && !details.updateAvailable) } },
      { op: 'set', id: 'open-selected', props: { disabled: !details?.installed || !details.enabled || !details.applications.length } },
      { op: 'set', id: 'enable-selected', props: { disabled: !details?.installed || details.enabled } },
      { op: 'set', id: 'disable-selected', props: { disabled: !details?.installed || !details.enabled } },
      { op: 'set', id: 'remove-selected', props: { disabled: !details?.installed } },
      { op: 'set', id: 'repair-selected', props: { disabled: !details?.installed } },
      { op: 'set', id: 'export-selected', props: { disabled: details?.kind !== 'project' } },
      { op: 'set', id: 'view-bundle', props: { disabled: !details?.bundlePath } }
    ]);
  }
  const schedule = refresher(refresh, error => { if (!app.disposed) onError(error); });
  async function imported(bundle) {
    const result = await software.importBundle(bundle);
    if (app.disposed) return;
    choose(result.id);
    await schedule();
    await app.say('Added ' + result.id + ' to your local catalog. Review its dependencies, then choose Install. No program was run.');
  }
  async function pickFile() {
    if (picker) return;
    const input = document.createElement('input');
    input.type = 'file'; input.accept = '.esospkg.json,.json,application/json'; input.hidden = true;
    picker = input; document.body.append(input);
    const finish = () => { input.remove(); if (picker === input) picker = null; };
    input.addEventListener('cancel', finish, { once: true });
    input.addEventListener('change', async () => {
      const file = input.files?.[0]; finish();
      if (!file || app.disposed) return;
      try {
        if (file.size > software.limits.bundleBytes) throw new Error('This bundle exceeds the 768 KiB portable package limit.');
        let bundle;
        try { bundle = JSON.parse(await file.text()); } catch { throw new Error('Choose a JSON eSOS program bundle.'); }
        if (!app.disposed) await imported(bundle);
      } catch (error) { await app.say(formatError(error), true); }
    }, { once: true });
    input.click();
  }
  app = frame('software', 'Software', async intent => {
    try {
      const id = intent.data?.id ?? selected;
      if (intent.action === 'software.select') choose(id);
      else if (intent.action === 'software.filter') filter = ['all', 'installed', 'programs'].includes(intent.value) ? intent.value : 'all';
      else if (intent.action === 'software.open') {
        const item = software.inspect(id), application = item.applications[0];
        if (!application) throw new Error('This package supplies a runtime. Open an application that uses it.');
        await os.views.open(application.id);
      } else if (['software.install', 'software.enable', 'software.disable', 'software.remove', 'software.repair'].includes(intent.action)) {
        choose(id);
        const method = intent.action.slice('software.'.length);
        if (method === 'install') {
          const plan = software.plan(id);
          await app.say('Preparing ' + plan.packages.filter(item => item.action !== 'keep').length + ' package(s). Each asset is verified before the installed registry changes.');
        }
        const result = await software[method](id);
        await app.say(method === 'remove' ? 'Removed executable installation. Documents, published bundles, and application data are retained.'
          : method === 'install' ? 'Installed ' + result.packages.join(', ') + '. Its applications are now in the launcher.'
          : method === 'repair' ? 'Verified package assets are available again.' : 'Package ' + (method === 'enable' ? 'enabled.' : 'disabled.'));
      } else if (intent.action === 'software.import-file') {
        await pickFile();
      } else if (intent.action === 'software.import-path') {
        path = intent.fields.path.trim(); app.changed();
        const file = await os.vfs.read(path);
        let bundle;
        try { bundle = JSON.parse(file.text); } catch { throw new Error('This VFS file is not a JSON program bundle.'); }
        await imported(bundle);
      } else if (intent.action === 'software.export') {
        const bundle = await software.exportBundle(id);
        download(id + '.esospkg.json', bundle);
        await app.say('Portable program bundle downloaded. It contains validated project data and runtime requirements, with no executable JavaScript.');
      } else if (intent.action === 'software.view-bundle') {
        await os.views.open('files', { path: software.inspect(id).bundlePath });
      }
      await schedule();
    } catch (error) {
      const owners = error.details?.owners;
      await app.say(formatError(error) + (owners?.length ? ' Running: ' + owners.map(owner => owner.title ?? owner.id).join(', ') : ''), true);
      await schedule().catch(() => {});
    }
  });
  app.sessionOptions = () => path ? { path } : {};
  app.cleanup.push(() => { picker?.remove(); picker = null; });
  table = dataTable(app.ui, { id: 'software-catalog', caption: 'Available and installed software', columns: ['Package', 'Kind', 'Status', 'Download', 'Action'], limit: 96 });
  await app.ui.tree([
    heading('Choose the tools you need.', 'Optional applications load after installation. Your desktop, files, and Software remain available throughout.'),
    el('div', 'software-toolbar', { class: 'app-toolbar' }, [
      el('div', 'software-filter-field', { class: 'component-field compact-field' }, [
        el('label', 'software-filter-label', { text: 'Show', attrs: { for: 'software-filter' } }),
        el('select', 'software-filter', { class: 'form-control', on: { change: 'software.filter' } },
          [['all', 'All packages'], ['installed', 'Installed'], ['programs', 'Your programs']].map(([value, label]) => el('option', 'show-' + value, { text: label, props: { value } })))
      ]),
      button('software-refresh', 'Refresh', 'software.refresh'), text('p', 'catalog-count', '', 'app-note')
    ]),
    table.tree,
    el('section', 'package-details', { class: 'system-card' }, [
      text('h3', 'package-title', 'Choose a package', 'section-title'), text('p', 'package-description', ''),
      text('p', 'package-id', '', 'app-note'), text('p', 'package-status', ''),
      text('p', 'package-dependencies', '', 'app-note'), text('p', 'package-reasons', '', 'app-note'),
      text('p', 'package-dependents', '', 'app-note'), text('p', 'package-path', '', 'app-note'),
      el('div', 'package-actions', { class: 'app-actions' }, [
        button('install-selected', 'Install', 'software.install', {}, 'btn-solid theme-primary'),
        button('open-selected', 'Open', 'software.open'), button('enable-selected', 'Enable', 'software.enable'),
        button('disable-selected', 'Disable', 'software.disable'), button('repair-selected', 'Repair', 'software.repair'),
        button('remove-selected', 'Remove', 'software.remove'), button('export-selected', 'Download bundle', 'software.export'),
        button('view-bundle', 'View bundle in Files', 'software.view-bundle')
      ])
    ]),
    message(),
    el('section', 'import-section', { class: 'system-card' }, [
      text('h3', 'import-title', 'Add a shared program', 'section-title'),
      text('p', 'import-description', 'Import a portable .esospkg.json bundle from your computer or from Files. Import adds a catalog entry; Install remains a separate action.', 'app-note'),
      button('import-native', 'Choose a bundle file…', 'software.import-file'),
      form('import-path-form', { action: 'software.import-path', fields: ['path'], className: 'app-toolbar' }, [
        field('import-path', { label: 'Bundle path in Files', name: 'path', value: path, className: 'field-grow',
          attrs: { placeholder: '~/Published/example.esospkg.json', maxlength: '4096', required: '' } }),
        submitButton('import-path-submit', 'Add to Software')
      ])
    ]),
    text('p', 'software-trust', 'Bundled executable packages are curated and trusted; they have page authority. Shared programs contain validated declarative data. Removing a package retains your files and data; close its windows and finish its jobs first.', 'app-note')
  ]);
  app.cleanup.push(software.subscribe(() => { schedule().catch(() => {}); }));
  await schedule();
  if (path) await app.say('A bundle path is ready. Choose Add to Software to validate it, then install the imported program explicitly.');
  return app;
}
