import { element as el, text, button, submitButton, form, field, dataTable } from '../components.mjs';
import { heading, message, formatError, filterText, refresher } from './common.mjs';

export async function buildJournal({ frame, os, onError }, options = {}) {
  let app, table;
  let filter = filterText(options.filter);
  let records = [], selected = null;
  async function showSelection(record) {
    if (app.disposed || !record) return;
    selected = record;
    const json = JSON.stringify(record, null, 2);
    await app.ui.send([
      { op: 'set', id: 'event-selection', props: { hidden: false } },
      { op: 'set', id: 'event-title', text: '#' + record.sequence + ' · ' + record.type },
      { op: 'set', id: 'event-data', text: json.length > 60000
        ? json.slice(0, 60000) + '\n…Display shortened. Copy event JSON contains the complete record.' : json },
      { op: 'set', id: 'copy-event', props: { disabled: false } }
    ]);
  }
  async function refresh() {
    if (app.disposed) return;
    const result = await os.journal({ limit: 100 });
    if (app.disposed) return;
    records = [...result].reverse();
    const needle = filter.trim().toLocaleLowerCase();
    const matching = records.filter(record => !needle ||
      (record.sequence + ' ' + record.app + ' ' + record.type).toLocaleLowerCase().includes(needle));
    await table.update(matching.map(record => ({ key: String(record.sequence), cells: [
      String(record.sequence), record.app ?? 'system', record.type,
      button('inspect', 'Inspect', 'journal.inspect', { sequence: record.sequence }, 'btn-text btn-sm')
    ] })));
    await app.ui.send([
      { op: 'set', id: 'journal-count', text: matching.length + ' shown from the latest ' + records.length + ' events' },
      { op: 'set', id: 'journal-empty', props: { hidden: matching.length > 0 },
        text: records.length ? 'No recent events match this filter.' : 'Accepted changes will appear here.' },
      { op: 'set', id: 'latest', props: { disabled: !records.length } }
    ]);
    if (!selected && records.length) await showSelection(records[0]);
  }
  const schedule = refresher(refresh, error => { if (!app.disposed) onError(error); });
  app = frame('journal', 'Journal', async intent => {
    try {
      if (intent.action === 'journal.refresh') await schedule();
      else if (intent.action === 'journal.filter') {
        filter = filterText(intent.fields.query);
        await schedule(); app.changed();
      } else if (intent.action === 'journal.inspect') {
        const found = records.find(record => record.sequence === intent.data.sequence);
        if (found) await showSelection(found);
        else await app.say('That event left the recent window. Use events in the terminal to read older history.');
      } else if (intent.action === 'journal.latest') {
        await schedule(); await showSelection(records[0]);
      } else if (intent.action === 'journal.copy' && selected) {
        const receipt = await os.clipboard.writeText(JSON.stringify(selected, null, 2) + '\n');
        await app.say(receipt.source === 'system'
          ? 'Complete event JSON copied to the system clipboard and workspace copy.'
          : 'Complete event JSON copied within this workspace. Use Paste workspace copy in Files.');
      } else if (intent.action === 'journal.new-window') {
        await os.views.open('journal', { newWindow: true, filter });
      }
    } catch (error) { await app.say(formatError(error), true); }
  });
  app.sessionOptions = () => ({ filter });
  table = dataTable(app.ui, { id: 'journal-table', caption: 'Latest committed events', columns: ['Sequence', 'Application', 'Event', 'Details'], limit: 100 });
  await app.ui.tree([
    heading('A history you can read.', 'Inspect accepted events while you work. A selected record stays in place as new events arrive.'),
    el('div', 'journal-toolbar', { class: 'app-toolbar' }, [
      text('span', 'journal-caption', 'Latest 100 committed events', 'app-description'),
      el('div', 'journal-actions', { class: 'app-actions' }, [
        button('refresh', 'Refresh', 'journal.refresh'), button('new-window', 'New window', 'journal.new-window')
      ])
    ]),
    form('journal-filter-form', { action: 'journal.filter', fields: ['query'], className: 'component-inline-form' }, [
      field('journal-filter', { label: 'Filter by application, event, or sequence', name: 'query', type: 'search', value: filter,
        attrs: { maxlength: '128', autocomplete: 'off', placeholder: 'For example: tasks' } }),
      submitButton('filter-button', 'Filter', 'btn-outline theme-secondary btn-sm')
    ]),
    table.tree,
    text('p', 'journal-empty', '', 'empty-state'), text('p', 'journal-count', '', 'app-note'),
    el('section', 'event-selection', { class: 'event-selection', props: { hidden: true }, attrs: { 'aria-label': 'Selected committed event' } }, [
      el('div', 'event-toolbar', { class: 'app-toolbar' }, [
        text('h3', 'event-title', '', 'journal-title'),
        el('div', 'event-actions', { class: 'app-actions' }, [
          button('latest', 'Select latest', 'journal.latest'),
          { ...button('copy-event', 'Copy event JSON', 'journal.copy'), props: { disabled: true } }
        ])
      ]),
      text('pre', 'event-data', '', 'journal-data')
    ]),
    message(),
    text('p', 'journal-note', 'The filter applies to this recent event window. Use events in the terminal for earlier sequences. Selecting an event never replays its effects.', 'app-note')
  ]);
  app.cleanup.push(os.observe(() => { schedule().catch(() => {}); }));
  await schedule();
  return app;
}
