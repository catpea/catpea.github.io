import { element as el, text, button, dataTable } from '../components.mjs';
import { heading, message, formatError, refresher } from './common.mjs';

export async function buildSystem({ frame, os, onError }) {
  let app, table;
  async function refresh() {
    if (app.disposed) return;
    const status = await os.system.status();
    const desktop = os.desktop?.list ? await os.desktop.list() : [];
    if (app.disposed) return;
    await app.ui.send([
      { op: 'set', id: 'release-detail', text: 'eSOS ' + status.version + ' · ' + status.runtime },
      { op: 'set', id: 'storage-detail', text: 'SQLite ' + (status.storage?.sqliteVersion ?? 'WASM') +
        ' · OPFS · ' + (status.persistent ? 'persistent storage granted' : 'browser-managed storage') },
      { op: 'set', id: 'desktop-detail', text: desktop.length + ' open windows. Minimized windows retain their applications and drafts.' },
      { op: 'set', id: 'installed-detail', text: (status.installedGroups ?? []).join(' · ') }
    ]);
    await table.update(desktop.slice(0, 12).map(window => ({ key: window.id, cells: [
      window.title, window.app, window.minimized ? 'Minimized' : window.mode,
      button('focus', 'Focus', 'system.focus-window', { id: window.id }, 'btn-text btn-sm')
    ] })));
  }
  const schedule = refresher(refresh, error => { if (!app.disposed) onError(error); });
  app = frame('system', 'System', async intent => {
    try {
      if (intent.action === 'system.export') {
        await os.system.export(); await app.say('Workspace export downloaded.');
      } else if (intent.action === 'system.persist') {
        if (typeof navigator.storage.persist !== 'function') throw new Error('This browser does not expose a persistent-storage request.');
        const granted = await navigator.storage.persist();
        await app.say(granted ? 'Persistent storage granted by this browser.' : 'The browser kept its current storage policy. Export remains available.');
        await schedule();
      } else if (intent.action === 'system.refresh') await schedule();
      else if (intent.action === 'system.focus-window') await os.desktop.focus(intent.data.id);
    } catch (error) { await app.say(formatError(error), true); }
  });
  table = dataTable(app.ui, { id: 'windows-table', caption: 'Open desktop windows', columns: ['Window', 'Application', 'State', 'Action'], limit: 12 });
  await app.ui.tree([
    heading('A working desktop.', 'Two coherent groups share the same local volume, command protocol, and DOM device.'),
    el('div', 'system-grid', { class: 'system-grid' }, [
      el('section', 'release-card', { class: 'system-card' }, [
        text('strong', 'release-title', 'Installed system'), text('p', 'release-detail', '')
      ]),
      el('section', 'storage-card', { class: 'system-card' }, [
        text('strong', 'storage-title', 'Local storage'), text('p', 'storage-detail', '')
      ]),
      el('section', 'desktop-card', { class: 'system-card' }, [
        text('strong', 'desktop-title', 'Retained windows'), text('p', 'desktop-detail', '')
      ]),
      el('section', 'profile-card', { class: 'system-card' }, [
        text('strong', 'profile-title', 'Local profile · ' + os.profile.username),
        text('p', 'profile-detail', 'One active workspace tab owns this volume. Protected profiles are a later complete group.')
      ])
    ]),
    text('p', 'installed-detail', '', 'app-note'),
    el('div', 'system-window-toolbar', { class: 'app-toolbar' }, [
      text('h3', 'windows-title', 'Open windows', 'section-title'), button('system-refresh', 'Refresh', 'system.refresh')
    ]),
    table.tree,
    el('div', 'system-actions', { class: 'app-actions' }, [
      button('system-export', 'Export workspace', 'system.export', {}, 'btn-solid theme-primary'),
      button('system-persist', 'Request persistent storage', 'system.persist')
    ]),
    message(),
    text('p', 'system-note', 'Bootstrap 6.0.0-alpha.1 is pinned locally. Native controls and Web APIs provide the desktop behavior; the browser stores committed data.', 'app-note')
  ]);
  app.cleanup.push(os.observe(() => { schedule().catch(() => {}); }));
  await schedule();
  app.didMount = () => { schedule().catch(() => {}); };
  return app;
}
