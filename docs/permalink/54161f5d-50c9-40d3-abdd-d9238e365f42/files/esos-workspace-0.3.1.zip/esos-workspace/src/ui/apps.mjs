import { createDomDevice } from '../devices/dom.mjs';
import * as components from './components.mjs';
import { buildTasks } from './apps/tasks.mjs';
import { buildFiles } from './apps/files.mjs';
import { buildJournal } from './apps/journal.mjs';
import { buildSystem } from './apps/system.mjs';
import { buildSoftware } from './apps/software.mjs';
import { buildSync } from './apps/sync.mjs';
import * as helpers from './apps/common.mjs';
const { writer } = components;
const { formatError, resolvePath } = helpers;

const builders = new Map([
  ['tasks', buildTasks], ['files', buildFiles], ['journal', buildJournal], ['system', buildSystem],
  ['software', buildSoftware], ['sync', buildSync]
]);

/** Application instances own devices; desktop windows own their visible lifetime. */
export function createApplications({ os, windows, onError = console.error, onSessionChange = () => {}, registry = new Map(),
  resolveApplication, knownApplications = () => [] }) {
  if (!windows?.create) throw new TypeError('A desktop window manager is required.');
  const instances = new Map();
  let opening = Promise.resolve();

  function report(error) {
    try { onError(formatError(error)); } catch { /* Reporting must not interrupt cleanup. */ }
  }
  function frame(name, title, onIntent, eventStream = false) {
    const container = document.createElement('div');
    container.className = 'application-content application-' + name;
    let disposed = false;
    const cleanup = [];
    const device = createDomDevice(container, {
      title, eventStream,
      onIntent: eventStream || !onIntent ? undefined : (intent, context) => {
        if (!disposed) return onIntent(intent, context);
      },
      onFault: error => { if (!disposed) report(error); }
    });
    const ui = writer(device);
    const app = {
      name, title, container, device, ui, cleanup, window: null, dirty: false,
      get disposed() { return disposed; },
      beforeClose: () => true,
      sessionOptions: () => ({}),
      resourcePath: () => null,
      changed() {
        if (!disposed && app.window) {
          try { onSessionChange(); } catch (error) { report(error); }
        }
      },
      setTitle(value) {
        if (disposed) return;
        app.title = String(value).slice(0, 180);
        app.window?.setTitle(app.title);
      },
      setDirty(value) {
        if (disposed) return;
        app.dirty = Boolean(value);
        app.window?.setDirty(app.dirty);
      },
      async say(value, failure = false) {
        if (disposed) return;
        await ui.set('message', { text: value, class: 'inline-message' + (failure ? ' failure' : '') });
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        for (const fn of cleanup.splice(0)) {
          try { Promise.resolve(fn()).catch(report); } catch (error) { report(error); }
        }
        if (app.window) instances.delete(app.window.id);
        registry.delete(device.id);
        device.destroy();
      }
    };
    return app;
  }
  function describe(app) {
    const state = app.window.describe();
    return {
      application: app.name, title: app.title, window: state.id, device: app.device.path,
      minimized: state.minimized, dirty: state.dirty, chrome: state.chrome,
      ...(app.packageId ? { packageId: app.packageId } : {}),
      ...(app.resourcePath() ? { path: app.resourcePath() } : {})
    };
  }
  function mount(app, options) {
    try {
      if (app.appMode) app.container.classList.add('application-program');
      app.window = windows.create({
        id: options.id, app: app.name, title: app.title, content: app.container,
        bounds: options.bounds, restoreBounds: options.restoreBounds,
        mode: options.mode ?? app.preferredMode, minimized: options.minimized,
        chrome: options.chrome ?? app.chrome ?? true,
        beforeClose: () => app.beforeClose(), onClose: () => app.dispose()
      });
      instances.set(app.window.id, app);
      registry.set(app.device.id, app.device);
      app.window.setDirty(app.dirty);
      app.didMount?.();
      app.changed();
      return describe(app);
    } catch (error) {
      app.dispose();
      throw error;
    }
  }
  function enqueue(action) {
    const work = opening.then(action);
    opening = work.catch(() => {});
    return work;
  }
  function optionsValue(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Application options must be an object.');
    return { ...value };
  }

  return Object.freeze({
    open(name, value = {}) {
      const options = optionsValue(value);
      if (!builders.has(name) && !knownApplications().some(item => item.id === name)) {
        return Promise.reject(new Error('Unknown or uninstalled application: ' + name + '. Open Software to install applications.'));
      }
      return enqueue(async () => {
        if (!options.newWindow && !options.id) {
          const target = options.path
            ? resolvePath(options.path, '/home/' + os.profile.username, os.profile.username) : null;
          const targetDirectory = name === 'files' && !target && options.directory
            ? resolvePath(options.directory, '/home/' + os.profile.username, os.profile.username) : null;
          const candidates = [...instances.values()].filter(app => app.name === name &&
            (!target || app.resourcePath() === target) &&
            (!targetDirectory || app.sessionOptions().directory === targetDirectory));
          const existing = candidates.find(app => app.window.id === windows.activeId) ?? candidates.at(-1);
          if (existing) { windows.focus(existing.window.id); return describe(existing); }
        }
        const building = [];
        try {
          const builder = builders.get(name) ?? await resolveApplication(name);
          if (typeof builder !== 'function') throw new Error('The application has no available builder: ' + name);
          const app = await builder({
            os, components, helpers, projects: os.projects, application: name, onError: report,
            frame(...args) { const created = frame(...args); building.push(created); return created; }
          }, options);
          app.name = name;
          app.packageId ??= os.software?.ownerOfApplication(name) ?? null;
          return mount(app, options);
        } catch (error) {
          for (const app of building) app.dispose();
          throw error;
        }
      });
    },
    openDevice(title = 'Document', value = {}) {
      const options = optionsValue(value);
      return enqueue(() => {
        const app = frame('device', title, undefined, options.eventStream !== false);
        mount(app, options);
        return app.device;
      });
    },
    list() { return [...instances.values()].map(describe); },
    session() {
      return [...instances.values()].filter(app => app.persistSession !== false &&
        (builders.has(app.name) || knownApplications().some(item => item.id === app.name)) &&
        (app.name !== 'project' || app.resourcePath())).map(app => {
        const state = app.window.describe();
        return {
          id: state.id, app: app.name, options: app.sessionOptions(), bounds: state.bounds,
          restoreBounds: state.restoreBounds ?? state.bounds, mode: state.mode, minimized: state.minimized, chrome: state.chrome
        };
      });
    },
    async closeAll() {
      await opening;
      const results = [];
      for (const app of [...instances.values()]) results.push(await windows.close(app.window.id));
      return results;
    },
    get active() { return instances.get(windows.activeId) ?? null; }
  });
}
