import { element as el, text } from '../components.mjs';

export const heading = (title, description) => el('header', 'heading', { class: 'app-heading' }, [
  text('p', 'eyebrow', 'LOCAL WORKSPACE', 'app-eyebrow'),
  text('h2', 'heading-title', title), text('p', 'description', description, 'app-description')
]);
export const message = () => el('p', 'message', { class: 'inline-message', attrs: { role: 'status', 'aria-live': 'polite' } });
export const formatError = error => (error?.code ? error.code + ' · ' : '') + (error?.message ?? String(error));

export function filterText(value) {
  let result = '';
  for (const character of typeof value === 'string' ? value : '') {
    const clean = /[\u0000-\u001f\u007f]/.test(character) ? ' '
      : /^[\uD800-\uDFFF]$/.test(character) ? '\uFFFD' : character;
    if (result.length + clean.length > 128) break;
    result += clean;
  }
  return result;
}

export function resolvePath(value, directory, username) {
  if (typeof value !== 'string' || !value.trim()) throw new Error('Enter a file or directory path.');
  const home = '/home/' + username;
  const source = value === '~' ? home : value.startsWith('~/') ? home + value.slice(1)
    : value.startsWith('/') ? value : directory.replace(/\/$/, '') + '/' + value;
  const parts = [];
  for (const part of source.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') {
      if (!parts.length) throw new Error('The path escapes the root.');
      parts.pop();
    } else parts.push(part);
  }
  return '/' + parts.join('/');
}

/** Coalesce view notifications while a previous render is waiting on I/O. */
export function refresher(work, report) {
  let running = null;
  let requested = false;
  return () => {
    requested = true;
    if (running) return running;
    running = (async () => {
      try {
        while (requested) { requested = false; await work(); }
      } catch (error) { report(error); throw error; }
      finally { running = null; }
    })();
    return running;
  };
}
