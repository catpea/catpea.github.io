const MODES = new Set(['normal', 'maximized', 'left', 'right']);
const ARROWS = Object.freeze({ ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] });
const TITLEBAR_HEIGHT = 44;
const REACHABLE_GRIP = 96;
const CAPTION_INSET = 14;
const copy = bounds => ({ x: bounds.x, y: bounds.y, width: bounds.width, height: bounds.height });
const same = (a, b) => a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
const clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));

export class WindowError extends Error {
  constructor(code, message) { super(message); this.name = 'WindowError'; this.code = code; }
}
const fail = (code, message) => { throw new WindowError(code, message); };
function boundedString(value, label, limit) {
  if (typeof value !== 'string' || !value.length || value.length > limit) fail('E_WINDOW_ARGUMENT', label + ' must be a nonempty string of at most ' + limit + ' characters.');
  return value;
}
function number(value, label) {
  if (typeof value !== 'number' || !Number.isFinite(value) || Math.abs(value) > 1000000) fail('E_WINDOW_ARGUMENT', label + ' must be a finite bounded number.');
  return Math.round(value);
}
function boundsValue(value, defaults) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) fail('E_WINDOW_ARGUMENT', 'Window bounds must be an object.');
  const result = Object.fromEntries(['x', 'y', 'width', 'height'].map(key => [key, number(value[key] ?? defaults[key], 'bounds.' + key)]));
  if (result.width < 1 || result.height < 1) fail('E_WINDOW_ARGUMENT', 'Window dimensions must be positive.');
  return result;
}

/** Fit the whole rectangle inside a workspace-relative usable area. */
export function fitBounds(bounds, area, { minWidth = 320, minHeight = 240 } = {}) {
  const availableWidth = Math.max(1, Math.round(area.width));
  const availableHeight = Math.max(1, Math.round(area.height));
  const left = Math.round(area.x ?? 0), top = Math.round(area.y ?? 0);
  const width = clamp(Math.round(bounds.width), Math.min(minWidth, availableWidth), availableWidth);
  const height = clamp(Math.round(bounds.height), Math.min(minHeight, availableHeight), availableHeight);
  return {
    x: clamp(Math.round(bounds.x), left, left + availableWidth - width),
    y: clamp(Math.round(bounds.y), top, top + availableHeight - height), width, height
  };
}

/** Keep a draggable caption segment reachable while allowing normal windows beyond the edges. */
export function reachableBounds(bounds, area, limits = {}) {
  const fitted = fitBounds(bounds, area, limits);
  const left = Math.round(area.x ?? 0), top = Math.round(area.y ?? 0);
  const width = fitted.width, height = fitted.height;
  // Conservative control-strip widths match the compact chrome rules in windows.css.
  const controls = width <= 140 ? 40 : width <= 200 ? 72 : width <= 280 ? 100 : 160;
  const captionLeft = Math.min(CAPTION_INSET, Math.max(0, width - 1));
  const captionRight = Math.max(captionLeft + 1, width - controls);
  const grip = Math.min(REACHABLE_GRIP, area.width, captionRight - captionLeft);
  const chromeHeight = Math.min(TITLEBAR_HEIGHT + 2, height, area.height);
  return {
    x: clamp(Math.round(bounds.x), left + grip - captionRight, left + area.width - grip - captionLeft),
    y: clamp(Math.round(bounds.y), top, top + area.height - chromeHeight), width, height
  };
}
function resizeBounds(start, width, height, area, limits) {
  return reachableBounds({ ...start, width, height }, area, limits);
}

/** Native window chrome. Application contents remain mounted until an accepted close. */
export function createWindowManager({ workspace, taskbar, onChange, onError, maxWindows = 12, getInsets = () => ({}) } = {}) {
  if (workspace?.nodeType !== 1 || taskbar?.nodeType !== 1 || workspace.ownerDocument !== taskbar.ownerDocument) {
    throw new TypeError('A workspace and taskbar in the same document are required.');
  }
  if (workspace === taskbar || workspace.contains(taskbar) || taskbar.contains(workspace)) {
    throw new TypeError('The workspace and taskbar must be separate surfaces.');
  }
  if (!Number.isInteger(maxWindows) || maxWindows < 1 || maxWindows > 32) throw new RangeError('maxWindows must be 1–32.');
  if (onChange !== undefined && typeof onChange !== 'function') throw new TypeError('onChange must be a function.');
  if (onError !== undefined && typeof onError !== 'function') throw new TypeError('onError must be a function.');
  if (typeof getInsets !== 'function') throw new TypeError('getInsets must be a function.');

  const document = workspace.ownerDocument;
  const platform = document.defaultView ?? globalThis;
  const Controller = platform.AbortController;
  const lifetime = new Controller();
  const entries = new Map();
  const order = [];
  const prefix = 'wm-' + crypto.randomUUID();
  let activeId = null, destroyed = false, gesture = null;
  workspace.classList.add('desktop-window-area');
  taskbar.classList.add('wm-taskbar');

  const report = error => {
    try { Promise.resolve(onError?.(error)).catch(() => {}); } catch {}
  };
  const safe = action => (...args) => {
    try { Promise.resolve(action(...args)).catch(report); } catch (error) { report(error); }
  };
  function area() {
    const width = Math.max(1, workspace.clientWidth), height = Math.max(1, workspace.clientHeight);
    const insets = getInsets();
    if (!insets || typeof insets !== 'object' || Array.isArray(insets)) fail('E_WINDOW_ARGUMENT', 'Desktop insets must be an object.');
    const inset = name => Math.max(0, number(insets[name] ?? 0, 'insets.' + name));
    const left = Math.min(inset('left'), width - 1), top = Math.min(inset('top'), height - 1);
    const right = Math.min(inset('right'), width - left - 1), bottom = Math.min(inset('bottom'), height - top - 1);
    return { x: left, y: top, width: width - left - right, height: height - top - bottom };
  }
  const limits = entry => ({ minWidth: entry.minWidth, minHeight: entry.minHeight });
  const describe = entry => ({
    id: entry.id, app: entry.app, title: entry.title, bounds: copy(entry.bounds),
    restoreBounds: copy(entry.normalBounds), mode: entry.mode, minimized: entry.minimized,
    dirty: entry.dirty, closable: entry.closable, chrome: entry.chrome
  });
  const list = () => order.map(id => describe(entries.get(id)));
  const emit = reason => {
    if (destroyed || !onChange) return;
    try { Promise.resolve(onChange({ activeId, windows: list() }, reason)).catch(report); } catch (error) { report(error); }
  };
  function requireEntry(id) {
    if (destroyed) fail('E_DESKTOP_CLOSED', 'The desktop window manager has been destroyed.');
    const entry = entries.get(id);
    if (!entry) fail('E_WINDOW_NOT_FOUND', 'No open window has id ' + String(id) + '.');
    return entry;
  }
  function requireOwned(entry) {
    if (destroyed || entries.get(entry.id) !== entry) fail('E_WINDOW_CLOSED', 'This window handle is closed.');
    return entry;
  }
  function element(tag, className, text) {
    const result = document.createElement(tag);
    result.className = className;
    if (text !== undefined) result.textContent = text;
    return result;
  }
  function geometry(entry) {
    const space = area();
    if (entry.mode === 'normal') return reachableBounds(entry.normalBounds, space, limits(entry));
    const full = copy(space);
    if (entry.mode === 'maximized') return full;
    const half = Math.floor((space.width - 8) / 2);
    if (half < entry.minWidth) return full;
    return { x: space.x + (entry.mode === 'left' ? 0 : space.width - half), y: space.y, width: half, height: space.height };
  }
  function paint(entry) {
    entry.bounds = geometry(entry);
    const { x, y, width, height } = entry.bounds;
    Object.assign(entry.element.style, { left: x + 'px', top: y + 'px', width: width + 'px', height: height + 'px' });
    entry.element.hidden = entry.minimized;
    entry.element.dataset.mode = entry.mode;
    entry.element.classList.toggle('is-chromeless', !entry.chrome);
    entry.titlebar.hidden = !entry.chrome;
    entry.revealChrome.hidden = entry.chrome;
    entry.element.classList.toggle('is-dirty', entry.dirty);
    entry.heading.textContent = entry.title;
    entry.dirtyMark.hidden = !entry.dirty;
    entry.titlebar.setAttribute('aria-label', entry.title + ' window position');
    entry.resize.setAttribute('aria-label', 'Resize ' + entry.title);
    entry.resize.hidden = entry.mode !== 'normal';
    entry.taskLabel.textContent = entry.title;
    entry.taskButton.title = entry.title + (entry.minimized ? ' · Minimized' : '') + (entry.dirty ? ' · Unsaved changes' : '');
    entry.taskButton.setAttribute('aria-label', entry.title + (entry.dirty ? ', unsaved changes' : '') + (entry.minimized ? ', minimized' : ''));
    entry.taskButton.classList.toggle('is-minimized', entry.minimized);
    entry.taskButton.classList.toggle('is-dirty', entry.dirty);
    for (const { button, label } of entry.controls) button.setAttribute('aria-label', label + ' ' + entry.title);
    entry.maximizeButton.textContent = entry.mode === 'maximized' ? '❐' : '□';
    entry.maximizeButton.title = entry.mode === 'maximized' ? 'Restore window size' : 'Maximize window';
    entry.maximizeButton.setAttribute('aria-label', entry.mode === 'maximized' ? 'Restore ' + entry.title : 'Maximize ' + entry.title);
  }
  function paintOrder() {
    order.forEach((id, index) => {
      const entry = entries.get(id), active = id === activeId && !entry.minimized;
      entry.element.style.zIndex = String(index + 10);
      entry.element.classList.toggle('is-active', active);
      entry.taskButton.classList.toggle('is-active', active);
      entry.taskButton.setAttribute('aria-pressed', String(active));
    });
  }
  function rememberFocus(entry) {
    const focused = document.activeElement;
    if (entry.body.contains(focused)) entry.lastFocus = focused;
  }
  function returnFocus(entry) {
    if (entry.element.contains(document.activeElement)) return;
    const previous = entry.lastFocus;
    if (previous?.isConnected && entry.element.contains(previous) && !previous.disabled) previous.focus({ preventScroll: true });
    if (!entry.element.contains(document.activeElement)) entry.titlebar.focus({ preventScroll: true });
  }
  function raise(entry, moveFocus = true, notify = true) {
    const changed = activeId !== entry.id || entry.minimized || order.at(-1) !== entry.id;
    if (activeId && activeId !== entry.id) rememberFocus(entries.get(activeId));
    entry.minimized = false;
    activeId = entry.id;
    order.splice(order.indexOf(entry.id), 1);
    order.push(entry.id);
    paint(entry); paintOrder();
    if (moveFocus) returnFocus(entry);
    if (changed && notify) emit('focus');
    return describe(entry);
  }
  function focusNext() {
    const next = [...order].reverse().map(id => entries.get(id)).find(entry => !entry.minimized);
    activeId = next?.id ?? null;
    paintOrder();
    if (next) returnFocus(next);
    else taskbar.querySelector('.wm-task')?.focus({ preventScroll: true });
  }
  function needsRecovery(entry) {
    return entry.mode === 'normal' && !same(entry.bounds, fitBounds(entry.bounds, area(), limits(entry)));
  }
  function recover(id) {
    const entry = requireEntry(id);
    if (gesture?.id === id) finishGesture(true);
    entry.chrome = true;
    if (entry.mode === 'normal') entry.normalBounds = fitBounds(entry.bounds, area(), limits(entry));
    raise(entry, false, false);
    entry.titlebar.focus({ preventScroll: true });
    emit('recover');
    return describe(entry);
  }
  function setChrome(id, visible) {
    if (typeof visible !== 'boolean') fail('E_WINDOW_ARGUMENT', 'Window chrome must be true or false.');
    const entry = requireEntry(id);
    if (gesture?.id === id) finishGesture(true);
    if (!visible && entry.mode === 'normal') entry.normalBounds = fitBounds(entry.bounds, area(), limits(entry));
    entry.chrome = visible; paint(entry); emit('chrome');
    if (visible) entry.titlebar.focus({ preventScroll: true });
    else if (entry.titlebar.contains(document.activeElement)) entry.revealChrome.focus({ preventScroll: true });
    return describe(entry);
  }
  function revealFocusedControl(entry, target) {
    if (gesture || target === entry.titlebar || !needsRecovery(entry)) return false;
    const canvas = workspace.getBoundingClientRect(), space = area(), control = target.getBoundingClientRect();
    const left = canvas.left + workspace.clientLeft + space.x, top = canvas.top + workspace.clientTop + space.y;
    // Clipping must not leave a keyboard-focused control wholly outside the visible desktop.
    if (control.right > left && control.left < left + space.width && control.bottom > top && control.top < top + space.height) return false;
    entry.normalBounds = fitBounds(entry.bounds, space, limits(entry));
    paint(entry);
    return true;
  }

  function finishGesture(cancelled = false) {
    if (!gesture) return;
    const current = gesture;
    gesture = null;
    current.listeners.abort();
    try { if (current.capture.hasPointerCapture(current.pointerId)) current.capture.releasePointerCapture(current.pointerId); } catch {}
    workspace.classList.remove('wm-moving', 'wm-resizing');
    const entry = entries.get(current.id);
    if (!entry) return;
    if (cancelled) {
      entry.mode = current.originalMode;
      entry.normalBounds = current.originalNormal;
    }
    paint(entry);
    if (!cancelled && (entry.mode !== current.originalMode || !same(entry.normalBounds, current.originalNormal))) emit(current.kind);
  }
  function beginGesture(entry, event, kind) {
    if (event.button !== 0 || event.isPrimary === false || gesture || entry.minimized) return;
    if (kind === 'move' && event.target.closest('button')) return;
    if (kind === 'resize' && entry.mode !== 'normal') return;
    event.preventDefault();
    raise(entry, false);
    const capture = kind === 'move' ? entry.titlebar : entry.resize;
    capture.focus({ preventScroll: true });
    const originalMode = entry.mode, originalNormal = copy(entry.normalBounds);
    const frame = entry.element.getBoundingClientRect();
    const listeners = new Controller();
    const current = { id: entry.id, kind, pointerId: event.pointerId, capture, listeners,
      startX: event.clientX, startY: event.clientY, start: copy(entry.bounds), originalMode, originalNormal, started: false,
      ratio: clamp((event.clientX - frame.left) / Math.max(1, frame.width), 0, 1),
      offsetY: clamp(event.clientY - frame.top, 0, TITLEBAR_HEIGHT) };
    gesture = current;
    workspace.classList.add(kind === 'move' ? 'wm-moving' : 'wm-resizing');
    const move = move => {
      if (move.pointerId !== current.pointerId || gesture !== current) return;
      const dx = move.clientX - current.startX, dy = move.clientY - current.startY;
      if (!current.started && Math.hypot(dx, dy) < 3) return;
      if (!current.started && kind === 'move' && entry.mode !== 'normal') {
        const canvas = workspace.getBoundingClientRect();
        const restored = reachableBounds(entry.normalBounds, area(), limits(entry));
        entry.mode = 'normal';
        current.start = reachableBounds({ ...restored,
          x: current.startX - canvas.left - workspace.clientLeft - current.ratio * restored.width,
          y: current.startY - canvas.top - workspace.clientTop - current.offsetY }, area(), limits(entry));
      }
      current.started = true;
      entry.normalBounds = kind === 'move'
        ? reachableBounds({ ...current.start, x: current.start.x + dx, y: current.start.y + dy }, area(), limits(entry))
        : resizeBounds(current.start, current.start.width + dx, current.start.height + dy, area(), limits(entry));
      paint(entry);
    };
    capture.addEventListener('pointermove', move, { signal: listeners.signal });
    capture.addEventListener('pointerup', up => { if (up.pointerId === current.pointerId) { move(up); finishGesture(false); } }, { signal: listeners.signal });
    capture.addEventListener('pointercancel', cancel => { if (cancel.pointerId === current.pointerId) finishGesture(true); }, { signal: listeners.signal });
    capture.addEventListener('lostpointercapture', lost => { if (lost.pointerId === current.pointerId) finishGesture(true); }, { signal: listeners.signal });
    try { capture.setPointerCapture(event.pointerId); }
    catch (error) { finishGesture(true); report(error); }
  }
  function keyboardGeometry(entry, event, resizeOnly = false) {
    if (event.key === 'Home' && event.target === (resizeOnly ? entry.resize : entry.titlebar) &&
        !event.altKey && !event.ctrlKey && !event.metaKey && !event.isComposing) {
      event.preventDefault(); recover(entry.id); return;
    }
    const direction = ARROWS[event.key];
    if (!direction || event.altKey || event.ctrlKey || event.metaKey || event.isComposing) return;
    if (!resizeOnly && event.target !== entry.titlebar) return;
    event.preventDefault();
    if (gesture) finishGesture(true);
    const resizing = resizeOnly || event.shiftKey;
    const start = entry.mode === 'normal' ? copy(entry.bounds) : reachableBounds(entry.normalBounds, area(), limits(entry));
    entry.mode = 'normal';
    const dx = direction[0] * 10, dy = direction[1] * 10;
    entry.normalBounds = resizing
      ? resizeBounds(start, start.width + dx, start.height + dy, area(), limits(entry))
      : reachableBounds({ ...start, x: start.x + dx, y: start.y + dy }, area(), limits(entry));
    paint(entry); raise(entry, false, false); emit(resizing ? 'resize' : 'move');
  }
  function setMode(id, mode) {
    const entry = requireEntry(id);
    if (gesture?.id === id) finishGesture(true);
    const changed = entry.mode !== mode || entry.minimized;
    entry.mode = mode;
    raise(entry, true, false);
    if (changed) emit(mode);
    else emit('focus');
    return describe(entry);
  }
  function minimize(id) {
    const entry = requireEntry(id);
    if (entry.minimized) return describe(entry);
    if (gesture?.id === id) finishGesture(true);
    rememberFocus(entry);
    entry.minimized = true;
    paint(entry);
    if (activeId === id) focusNext(); else paintOrder();
    emit('minimize');
    return describe(entry);
  }
  function restore(id) {
    const entry = requireEntry(id);
    return entry.minimized ? raise(entry) : setMode(id, 'normal');
  }
  function setBounds(id, bounds) {
    const entry = requireEntry(id);
    const next = boundsValue(bounds, entry.normalBounds);
    if (gesture?.id === id) finishGesture(true);
    if (!same(next, entry.normalBounds)) {
      entry.normalBounds = next;
      paint(entry); emit('bounds');
    }
    return describe(entry);
  }
  function remove(entry) {
    if (gesture?.id === entry.id) finishGesture(true);
    entry.listeners.abort();
    entry.element.remove(); entry.taskButton.remove();
    entries.delete(entry.id);
    order.splice(order.indexOf(entry.id), 1);
    if (activeId === entry.id) focusNext(); else paintOrder();
  }
  function close(id) {
    const entry = requireEntry(id);
    if (!entry.closable) return Promise.resolve({ id, closed: false, reason: 'persistent-window' });
    if (entry.closing) return entry.closing;
    if (entry.closeButton) entry.closeButton.disabled = true;
    entry.closing = (async () => {
      const allowed = await entry.beforeClose?.();
      if (allowed === false) return { id, closed: false, cancelled: true };
      if (destroyed || entries.get(id) !== entry) return { id, closed: true };
      remove(entry); emit('close');
      try { await entry.onClose?.(); } catch (error) { report(error); }
      return { id, closed: true };
    })().finally(() => {
      entry.closing = null;
      if (entry.closeButton) entry.closeButton.disabled = false;
    });
    return entry.closing;
  }
  function defaults(minWidth, minHeight) {
    const space = area();
    const fit = value => fitBounds(value, space, { minWidth, minHeight });
    const width = Math.min(620, space.width - 32), height = Math.min(560, space.height - 32);
    if (order.length === 1) {
      const previous = entries.get(order[0]).bounds;
      const x = previous.x + previous.width + 18, remaining = space.x + space.width - x - 16;
      if (remaining >= minWidth) return fit({ x, y: previous.y, width: Math.max(minWidth, Math.min(width, remaining)), height: Math.max(minHeight, height) });
    }
    const offset = (order.length % 7) * 28;
    return fit({ x: space.x + 16 + offset, y: space.y + 16 + offset, width: Math.max(minWidth, width), height: Math.max(minHeight, height) });
  }
  function create(spec = {}) {
    if (destroyed) fail('E_DESKTOP_CLOSED', 'The desktop window manager has been destroyed.');
    if (entries.size >= maxWindows) fail('E_WINDOW_LIMIT', 'Close a window before opening another. This desktop supports ' + maxWindows + ' windows.');
    const id = spec.id ?? 'w-' + crypto.randomUUID();
    if (typeof id !== 'string' || !/^[A-Za-z][A-Za-z0-9_.:-]{0,127}$/.test(id)) fail('E_WINDOW_ARGUMENT', 'Window IDs use a letter followed by up to 127 letters, digits, or . _ : - characters.');
    if (entries.has(id)) fail('E_WINDOW_EXISTS', 'A window already has id ' + id + '.');
    const app = boundedString(spec.app ?? 'document', 'Application name', 128);
    const title = boundedString(spec.title ?? app, 'Window title', 512);
    const minWidth = number(spec.minWidth ?? 320, 'minWidth'), minHeight = number(spec.minHeight ?? 240, 'minHeight');
    if (minWidth < 160 || minHeight < 120 || minWidth > 4096 || minHeight > 4096) fail('E_WINDOW_ARGUMENT', 'Minimum sizes must be 160–4096 wide and 120–4096 high.');
    const mode = spec.mode ?? 'normal';
    if (!MODES.has(mode)) fail('E_WINDOW_ARGUMENT', 'Unknown window mode.');
    if (spec.chrome !== undefined && typeof spec.chrome !== 'boolean') fail('E_WINDOW_ARGUMENT', 'Window chrome must be true or false.');
    const normalBounds = boundsValue(spec.restoreBounds ?? spec.bounds ?? {}, defaults(minWidth, minHeight));
    for (const name of ['beforeClose', 'onClose']) if (spec[name] != null && typeof spec[name] !== 'function') fail('E_WINDOW_ARGUMENT', name + ' must be a function.');
    const content = spec.content;
    if (content?.nodeType !== 1 || content.ownerDocument !== document || content === workspace || content === taskbar || content.contains(workspace) || content.contains(taskbar)) {
      fail('E_WINDOW_CONTENT', 'Window content must be an owned element in this document.');
    }
    if ([...entries.values()].some(entry => entry.element.contains(content) || content.contains(entry.element))) fail('E_WINDOW_CONTENT', 'That content already belongs to an open window.');
    const entry = { id, app, title, minWidth, minHeight, normalBounds, bounds: copy(normalBounds), mode,
      minimized: spec.minimized === true, dirty: false, closable: spec.closable !== false, chrome: spec.chrome !== false,
      beforeClose: spec.beforeClose, onClose: spec.onClose, lastFocus: null, closing: null, controls: [], listeners: new Controller() };
    entry.element = element('section', 'desktop-window');
    entry.element.id = prefix + '-' + id;
    entry.element.dataset.windowId = id;
    entry.element.dataset.app = app;
    entry.element.setAttribute('role', 'region');
    entry.titlebar = element('header', 'wm-titlebar');
    entry.titlebar.tabIndex = 0;
    entry.titlebar.title = 'Drag to move. Double-click to maximize. Arrow keys move; Shift + arrows resize. Home brings the window fully onscreen.';
    const caption = element('div', 'wm-caption');
    const icon = element('span', 'wm-icon', ({ terminal: '›_', tasks: '✓', files: '▤', journal: '≡', system: '◇' })[app] ?? '◇');
    icon.setAttribute('aria-hidden', 'true');
    entry.heading = element('h2', 'wm-title', title);
    entry.heading.id = entry.element.id + '-title';
    entry.element.setAttribute('aria-labelledby', entry.heading.id);
    entry.dirtyMark = element('span', 'wm-dirty', '●');
    entry.dirtyMark.setAttribute('aria-label', 'Unsaved changes');
    caption.append(icon, entry.heading, entry.dirtyMark);
    const controls = element('div', 'wm-controls');
    function control(label, glyph, action, extraClass = '') {
      const button = element('button', 'wm-control ' + extraClass, glyph);
      button.type = 'button'; button.title = label; button.setAttribute('aria-label', label + ' ' + title);
      button.addEventListener('click', safe(action), { signal: entry.listeners.signal });
      entry.controls.push({ button, label });
      controls.append(button); return button;
    }
    control('Snap left', '◧', () => setMode(id, 'left'), 'wm-snap');
    control('Snap right', '◨', () => setMode(id, 'right'), 'wm-snap');
    control('Minimize', '−', () => minimize(id), 'wm-minimize');
    entry.maximizeButton = control('Maximize', '□', () => entry.mode === 'maximized' ? restore(id) : setMode(id, 'maximized'));
    if (entry.closable) entry.closeButton = control('Close', '×', () => close(id), 'wm-close');
    entry.titlebar.append(caption, controls);
    entry.body = element('div', 'wm-body');
    entry.body.append(content);
    entry.resize = element('div', 'wm-resize');
    entry.resize.tabIndex = 0;
    entry.resize.setAttribute('role', 'group');
    entry.revealChrome = element('button', 'wm-reveal-chrome', '⋮');
    entry.revealChrome.type = 'button';
    entry.revealChrome.title = 'Show window controls';
    entry.revealChrome.setAttribute('aria-label', 'Show window controls for ' + title);
    entry.revealChrome.addEventListener('click', safe(() => setChrome(id, true)), { signal: entry.listeners.signal });
    entry.resize.title = 'Drag to resize, or use arrow keys. Home brings the window fully onscreen.';
    const help = element('p', 'wm-sr-only', 'Window title: use arrow keys to move, or Shift with arrow keys to resize. Resize corner: use arrow keys to resize. Home brings the window fully onscreen. A taskbar button also recovers an offscreen window.');
    help.id = entry.element.id + '-help';
    entry.titlebar.setAttribute('aria-describedby', help.id);
    entry.resize.setAttribute('aria-describedby', help.id);
    entry.element.append(entry.titlebar, entry.body, entry.resize, entry.revealChrome, help);
    entry.taskButton = element('button', 'wm-task');
    entry.taskButton.type = 'button';
    entry.taskButton.dataset.windowTarget = id;
    entry.taskButton.setAttribute('aria-controls', entry.element.id);
    const taskIcon = icon.cloneNode(true);
    entry.taskLabel = element('span', 'wm-task-label', title);
    entry.taskButton.append(taskIcon, entry.taskLabel);
    entry.taskButton.addEventListener('click', safe(() => needsRecovery(entry) ? recover(id)
      : entry.minimized || activeId !== id ? raise(entry) : minimize(id)), { signal: entry.listeners.signal });
    entry.taskButton.addEventListener('keydown', safe(event => {
      if (event.key === 'Home' && !event.altKey && !event.ctrlKey && !event.metaKey && !event.isComposing) {
        event.preventDefault(); recover(id);
      }
    }), { signal: entry.listeners.signal });
    entry.element.addEventListener('pointerdown', safe(() => raise(entry, false)), { capture: true, signal: entry.listeners.signal });
    entry.element.addEventListener('focusin', safe(event => {
      if (entry.body.contains(event.target)) entry.lastFocus = event.target;
      const recovered = revealFocusedControl(entry, event.target);
      raise(entry, false, !recovered);
      if (recovered) emit('recover');
    }), { signal: entry.listeners.signal });
    entry.titlebar.addEventListener('pointerdown', safe(event => beginGesture(entry, event, 'move')), { signal: entry.listeners.signal });
    entry.titlebar.addEventListener('dblclick', safe(event => {
      if (event.target.closest('button')) return;
      entry.mode === 'maximized' ? restore(id) : setMode(id, 'maximized');
    }), { signal: entry.listeners.signal });
    entry.titlebar.addEventListener('keydown', safe(event => keyboardGeometry(entry, event)), { signal: entry.listeners.signal });
    entry.resize.addEventListener('pointerdown', safe(event => beginGesture(entry, event, 'resize')), { signal: entry.listeners.signal });
    entry.resize.addEventListener('keydown', safe(event => keyboardGeometry(entry, event, true)), { signal: entry.listeners.signal });
    entry.handle = Object.freeze({
      id, element: entry.element, body: entry.body,
      describe: () => describe(entry),
      setTitle(value) {
        requireOwned(entry); value = boundedString(value, 'Window title', 512);
        if (value !== entry.title) { entry.title = value; paint(entry); emit('title'); }
        return describe(entry);
      },
      setDirty(value) {
        requireOwned(entry);
        if (typeof value !== 'boolean') throw new TypeError('Dirty must be boolean.');
        if (value !== entry.dirty) { entry.dirty = value; paint(entry); emit('dirty'); }
        return describe(entry);
      },
      setBeforeClose(callback) {
        requireOwned(entry);
        if (callback != null && typeof callback !== 'function') throw new TypeError('beforeClose must be a function.');
        entry.beforeClose = callback;
      },
      focus: () => raise(requireOwned(entry)),
      setChrome(value) { requireOwned(entry); return setChrome(id, value); },
      recover() { requireOwned(entry); return recover(id); },
      close() { requireOwned(entry); return close(id); },
      setBounds(value) { requireOwned(entry); return setBounds(id, value); }
    });
    entries.set(id, entry); order.push(id);
    workspace.append(entry.element); taskbar.append(entry.taskButton);
    paint(entry);
    if (!entry.minimized) raise(entry, true, false); else paintOrder();
    emit('create');
    return entry.handle;
  }
  function arrange(layout = 'tile') {
    if (destroyed) fail('E_DESKTOP_CLOSED', 'The desktop window manager has been destroyed.');
    if (!['tile', 'cascade'].includes(layout)) fail('E_WINDOW_ARGUMENT', 'Arrange uses tile or cascade.');
    const visible = order.map(id => entries.get(id)).filter(entry => !entry.minimized);
    if (!visible.length) return { layout, count: 0, windows: [] };
    const space = area(), gap = 10;
    const minWidth = Math.min(space.width, Math.max(...visible.map(entry => entry.minWidth)));
    const minHeight = Math.min(space.height, Math.max(...visible.map(entry => entry.minHeight)));
    const columns = Math.min(visible.length, Math.max(1, Math.floor((space.width + gap) / (minWidth + gap))));
    const rows = Math.ceil(visible.length / columns);
    if (layout === 'tile' && rows * minHeight + (rows - 1) * gap > space.height) {
      fail('E_TILE_SPACE', 'There is not enough room to tile every open window. Minimize some windows or use Cascade.');
    }
    if (gesture) finishGesture(true);
    const offset = Math.min(28 * (visible.length - 1), Math.floor(space.width / 5), Math.floor(space.height / 5));
    const stride = visible.length > 1 ? Math.floor(offset / (visible.length - 1)) : 0;
    visible.forEach((entry, index) => {
      entry.mode = 'normal';
      if (layout === 'tile') {
        const column = index % columns, row = Math.floor(index / columns);
        const width = Math.floor((space.width - (columns - 1) * gap) / columns);
        const height = Math.floor((space.height - (rows - 1) * gap) / rows);
        entry.normalBounds = { x: space.x + column * (width + gap), y: space.y + row * (height + gap), width, height };
      } else entry.normalBounds = fitBounds({ x: space.x + index * stride, y: space.y + index * stride,
        width: Math.min(680, space.width - offset), height: Math.min(560, space.height - offset) }, space, limits(entry));
      paint(entry);
    });
    emit('arrange:' + layout);
    return { layout, count: visible.length, windows: visible.map(describe) };
  }
  function resized() {
    if (destroyed) return;
    if (gesture) finishGesture(true);
    let changed = false;
    for (const entry of entries.values()) {
      const previous = entry.bounds;
      paint(entry);
      if (!same(previous, entry.bounds)) changed = true;
    }
    if (changed) emit('viewport');
  }
  const resizeObserver = platform.ResizeObserver ? new platform.ResizeObserver(safe(resized)) : null;
  if (resizeObserver) resizeObserver.observe(workspace);
  else platform.addEventListener('resize', safe(resized), { signal: lifetime.signal });
  platform.addEventListener('blur', () => finishGesture(true), { signal: lifetime.signal });
  document.addEventListener('keydown', event => {
    if (gesture && event.key === 'Escape') { event.preventDefault(); finishGesture(true); }
  }, { signal: lifetime.signal });

  return Object.freeze({
    create, list,
    get(id) { return entries.get(id)?.handle ?? null; },
    get activeId() { return activeId; },
    focus: id => raise(requireEntry(id)), close, minimize, restore, recover, setBounds, setChrome,
    maximize: id => setMode(id, 'maximized'),
    snap(id, side) { if (!['left', 'right'].includes(side)) fail('E_WINDOW_ARGUMENT', 'Snap uses left or right.'); return setMode(id, side); },
    arrange, refreshLayout: resized,
    destroy() {
      if (destroyed) return;
      finishGesture(true);
      destroyed = true;
      resizeObserver?.disconnect(); lifetime.abort();
      for (const entry of [...entries.values()]) {
        remove(entry);
        safe(() => entry.onClose?.())();
      }
      activeId = null;
      workspace.classList.remove('desktop-window-area', 'wm-moving', 'wm-resizing');
      taskbar.classList.remove('wm-taskbar');
    }
  });
}
