/** A native dialog over the public search service. It never executes search text. */
export function createLauncher({ dialog, search, onActivate, onError = () => {} }) {
  const input = dialog.querySelector('#launcher-input');
  const results = dialog.querySelector('#launcher-results');
  const status = dialog.querySelector('#launcher-status');
  const lifetime = new AbortController();
  let sequence = 0, selected = -1, rows = [], timer, request;
  let opening = false;

  function choose(index) {
    selected = rows.length ? (index + rows.length) % rows.length : -1;
    for (const [position, element] of [...results.children].entries()) {
      element.setAttribute('aria-selected', String(position === selected));
    }
    const active = results.children[selected];
    if (active) {
      input.setAttribute('aria-activedescendant', active.id);
      active.scrollIntoView({ block: 'nearest' });
    } else input.removeAttribute('aria-activedescendant');
  }

  function render(items) {
    rows = items;
    const fragment = document.createDocumentFragment();
    for (const [index, item] of items.entries()) {
      const option = document.createElement('li');
      option.id = 'launcher-result-' + index;
      option.dataset.index = String(index);
      option.setAttribute('role', 'option');
      option.setAttribute('aria-selected', 'false');
      const icon = document.createElement('span');
      icon.className = 'launcher-icon';
      icon.setAttribute('aria-hidden', 'true');
      icon.textContent = ({ application: '◇', command: '›_', file: '·', directory: '▸' })[item.kind] ?? '·';
      const body = document.createElement('span');
      body.className = 'launcher-result-body';
      const title = document.createElement('strong'); title.textContent = item.title;
      const detail = document.createElement('small'); detail.textContent = item.description ?? item.path ?? '';
      const kind = document.createElement('span'); kind.className = 'launcher-kind'; kind.textContent = item.kind;
      body.append(title, detail); option.append(icon, body, kind); fragment.append(option);
    }
    results.replaceChildren(fragment);
    input.setAttribute('aria-expanded', String(items.length > 0));
    choose(0);
  }

  async function refresh() {
    const token = ++sequence;
    request?.abort(); request = new AbortController();
    status.textContent = 'Searching locally…';
    try {
      const found = await search.query(input.value, { limit: 30, signal: request.signal });
      if (token !== sequence || !dialog.open) return;
      render(found);
      status.textContent = found.length ? found.length + ' results · local workspace' : 'No matches. Try a shorter name.';
    } catch (error) {
      if (token !== sequence || request.signal.aborted || !dialog.open) return;
      render([]); status.textContent = error.message ?? 'The local search could not finish.';
    }
  }

  async function activate(index = selected) {
    if (opening || !rows[index]) return;
    const result = rows[index];
    opening = true;
    try { dialog.close(); await onActivate(result); }
    catch (error) { onError(error); }
    finally { opening = false; }
  }

  input.addEventListener('input', () => {
    sequence++; request?.abort(); clearTimeout(timer);
    render([]); status.textContent = 'Searching locally…';
    timer = setTimeout(refresh, 140);
  }, { signal: lifetime.signal });
  input.addEventListener('keydown', event => {
    if (event.isComposing) return;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault(); choose(selected + (event.key === 'ArrowDown' ? 1 : -1));
    } else if (event.key === 'Enter') { event.preventDefault(); void activate(); }
  }, { signal: lifetime.signal });
  results.addEventListener('click', event => {
    const option = event.target.closest('[data-index]');
    if (option && results.contains(option)) void activate(Number(option.dataset.index));
  }, { signal: lifetime.signal });
  dialog.addEventListener('close', () => {
    sequence++; request?.abort(); clearTimeout(timer);
    input.setAttribute('aria-expanded', 'false');
  }, { signal: lifetime.signal });
  const open = (query = '') => {
    if (!dialog.open) dialog.showModal();
    input.value = query; input.focus(); input.select(); void refresh();
  };
  document.addEventListener('keydown', event => {
    if (event.ctrlKey && !event.altKey && !event.metaKey && event.key.toLowerCase() === 'k' && !event.isComposing) {
      event.preventDefault(); open();
    }
  }, { signal: lifetime.signal });
  return Object.freeze({ open, close: () => dialog.close(), destroy() {
    request?.abort(); clearTimeout(timer); lifetime.abort(); if (dialog.open) dialog.close();
  } });
}
