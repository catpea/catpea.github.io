import { system, operands, CommandError } from './common.mjs';
export const name = 'sync';
export const summary = 'Compare and synchronize visible files with an optional Linux folder.';
export const usage = 'sync [status | compare [ROOT] | run [ROOT] | resolve PATH local|remote [ROOT]]';
export async function run(ctx) {
  const [action = 'status', first, second, third] = operands(ctx, 0, 4, usage);
  const sync = system(ctx).sync;
  if (action === 'status' && first === undefined) return ctx.stdout.write(await sync.status());
  if (action === 'compare' && second === undefined) {
    const plan = await sync.compare({ root: first ?? '~', signal: ctx.signal });
    for (const row of plan.rows) await ctx.stdout.write({ kind: 'sync-file', root: plan.root, ...row });
    return ctx.stdout.write({ kind: 'sync-summary', compared: plan.rows.length, skipped: plan.skipped.length, peer: plan.peer });
  }
  const options = { signal: ctx.signal, onProgress: record => ctx.stdout.write({ kind: 'sync-file', ...record }) };
  let result;
  if (action === 'run' && second === undefined) result = await sync.run({ ...options, root: first ?? '~' });
  else if (action === 'resolve' && first && ['local', 'remote'].includes(second)) result = await sync.resolve(first, second, { ...options, root: third ?? '~' });
  else throw new CommandError('E_USAGE', 'Usage: ' + usage);
  await ctx.stdout.write({ kind: 'sync-summary', transferred: result.transferred, unresolved: result.unresolved,
    skipped: result.skipped.length, peer: result.peer });
}
