import { operands, outputRows, system } from './common.mjs';

export const name = 'ls';
export const summary = 'List a directory as structured records.';
export const usage = 'ls [absolute-path]';

export async function run(ctx) {
  const [path = '/home'] = operands(ctx, 0, 1, usage);
  await outputRows(ctx, await system(ctx).vfs.list(path));
}
