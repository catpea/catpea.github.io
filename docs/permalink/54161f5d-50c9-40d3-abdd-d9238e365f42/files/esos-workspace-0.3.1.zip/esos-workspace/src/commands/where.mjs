import { operands, scalar } from './common.mjs';

export const name = 'where';
export const summary = 'Keep records whose field equals a JSON scalar or text.';
export const usage = 'where FIELD VALUE';

export async function run(ctx) {
  const [field, source] = operands(ctx, 2, 2, usage);
  const value = scalar(source);
  for await (const record of ctx.stdin) {
    ctx.signal?.throwIfAborted();
    if (Object.hasOwn(record, field) && record[field] === value) await ctx.stdout.write(record);
  }
}
