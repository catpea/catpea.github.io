export class CommandError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'CommandError';
    this.code = code;
  }
}

export function operands(ctx, min, max, usage) {
  const args = ctx.args ?? [];
  if (!Array.isArray(args) || args.some(value => typeof value !== 'string') ||
      args.length < min || args.length > max) {
    throw new CommandError('E_USAGE', 'Usage: ' + usage);
  }
  ctx.signal?.throwIfAborted();
  return args;
}

export function system(ctx) {
  const os = ctx.os ?? ctx.capabilities?.os;
  if (!os) throw new CommandError('E_CONTEXT', 'The command needs its system context.');
  return os;
}

export async function outputRows(ctx, rows) {
  for await (const row of rows) {
    ctx.signal?.throwIfAborted();
    await ctx.stdout.write(row);
  }
}

export function scalar(source) {
  let value;
  try { value = JSON.parse(source); } catch { value = source; }
  if (value !== null && !['string', 'boolean', 'number'].includes(typeof value)) {
    throw new CommandError('E_USAGE', 'The comparison value must be a JSON scalar or text.');
  }
  if (typeof value === 'number' &&
      (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value)))) {
    throw new CommandError('E_USAGE', 'The comparison number must be finite and exactly representable.');
  }
  return value;
}
