import { operands, system, CommandError } from './common.mjs';
export const name = 'project';
export const summary = 'Create, inspect, run, or publish a portable project document.';
export const usage = 'project new form|cards|workflow PATH [TITLE] | project inspect|run|publish PATH';
export async function run(ctx) {
  const [action, first, second, title] = operands(ctx, 2, 4, usage);
  const os = system(ctx);
  if (action === 'new' && ['form', 'cards', 'workflow'].includes(first) && second) {
    const project = os.projects.create(first);
    if (title !== undefined) project.name = title;
    const path = os.projects.resolvePath(second);
    let parent = '';
    for (const part of path.split('/').filter(Boolean).slice(0,-1)) { parent += '/' + part; await os.vfs.mkdir(parent); }
    const saved = await os.projects.save(path, project, { expectedRevision: 0, operationId: crypto.randomUUID() });
    return ctx.stdout.write({ kind: 'project-created', path: saved.path, revision: saved.revision, project: project.id });
  }
  if (second !== undefined || !['inspect', 'run', 'publish'].includes(action)) throw new CommandError('E_USAGE', 'Usage: ' + usage);
  const loaded = await os.projects.load(first);
  if (action === 'inspect') return ctx.stdout.write({ kind: 'project', path: loaded.path, revision: loaded.revision,
    id: loaded.project.id, name: loaded.project.name, type: loaded.project.kind, requires: loaded.project.requires });
  if (action === 'run') return ctx.stdout.write(await os.views.open('project', { path: loaded.path, newWindow: true }));
  return ctx.stdout.write(await os.software.publish({ project: loaded.project, sourcePath: loaded.path }));
}
