import { operands, system } from './common.mjs';

export const name = 'system';
export const summary = 'Inspect the running local system.';
export const usage = 'system';

export async function run(ctx) {
  operands(ctx, 0, 0, usage);
  await ctx.stdout.write(await system(ctx).system.status());
}
