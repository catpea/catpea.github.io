import { CommandError, operands } from './common.mjs';

export const name = 'select';
export const summary = 'Keep selected fields from every input record.';
export const usage = 'select FIELD [FIELD...]';

export async function run(ctx) {
  const fields = operands(ctx, 1, 128, usage);
  if (fields.some(field => !field) || new Set(fields).size !== fields.length) {
    throw new CommandError('E_USAGE', 'Select distinct, nonempty field names.');
  }
  for await (const record of ctx.stdin) {
    ctx.signal?.throwIfAborted();
    const selected = Object.create(null);
    for (const field of fields) {
      if (Object.hasOwn(record, field)) selected[field] = record[field];
    }
    await ctx.stdout.write(selected);
  }
}
