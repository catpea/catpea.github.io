import { CommandError, operands, system } from './common.mjs';

export const name = 'open';
export const summary = 'Open or focus an application, a new window, or a local text file.';
export const usage = 'open APPLICATION [--new] [PATH] | open PATH';

export async function run(ctx) {
  const [name, ...args] = operands(ctx, 1, 3, usage);
  const os = system(ctx);
  const options = {};
  for (const value of args) {
    if (value === '--new' && !options.newWindow) options.newWindow = true;
    else if (options.path === undefined && value !== '--new') options.path = value;
    else throw new CommandError('E_USAGE', 'Usage: ' + usage);
  }
  const view = (name.startsWith('/') || name.startsWith('~/') || name.startsWith('./') || /\.(json|txt|md|xml)$/i.test(name)) && !options.path
    ? await os.views.openDocument(name, options)
    : await os.views.open(name, options);
  await ctx.stdout.write({ kind: 'view-opened', application: name, ...(view ?? {}) });
}
