import { CommandError, operands, system } from './common.mjs';

export const name = 'write';
export const summary = 'Save text, or text records from STDIN, into a file.';
export const usage = 'write absolute-path [text]';
const encoder = new TextEncoder();
const MAX_BYTES = 1024 * 1024;

export async function run(ctx) {
  const [path, ...words] = operands(ctx, 1, 128, usage);
  let text;
  if (words.length) {
    text = words.join(' ');
  } else {
    const pieces = [];
    let bytes = 0;
    for await (const record of ctx.stdin) {
      ctx.signal?.throwIfAborted();
      if (typeof record.text !== 'string') {
        throw new CommandError('E_INPUT_SCHEMA', 'write expects records with a text string.');
      }
      bytes += encoder.encode(record.text).byteLength;
      if (bytes > MAX_BYTES) throw new CommandError('E_FILE_TOO_LARGE', 'The file exceeds the 1 MiB text limit.');
      if (record.text) pieces.push(record.text);
    }
    text = pieces.join('');
  }
  if (encoder.encode(text).byteLength > MAX_BYTES) {
    throw new CommandError('E_FILE_TOO_LARGE', 'The file exceeds the 1 MiB text limit.');
  }
  ctx.signal?.throwIfAborted();
  const saved = await system(ctx).vfs.write(path, text, { operationId: crypto.randomUUID() });
  const { text: omittedText, ...metadata } = saved;
  await ctx.stdout.write({ ...metadata, kind: saved.path?.startsWith('/dev/') ? 'device-written' : 'file-saved' });
}
