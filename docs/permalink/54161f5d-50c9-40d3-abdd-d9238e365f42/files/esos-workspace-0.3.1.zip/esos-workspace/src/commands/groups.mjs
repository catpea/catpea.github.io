import { operands, outputRows, system } from './common.mjs';

export const name = 'groups';
export const summary = 'Inspect the coherent package groups.';
export const usage = 'groups';

export async function run(ctx) {
  operands(ctx, 0, 0, usage);
  await outputRows(ctx, await system(ctx).system.groups());
}
