import { CommandError, operands, outputRows, system } from './common.mjs';

export const name = 'windows';
export const summary = 'List, focus, recover, arrange, or close desktop windows.';
export const usage = 'windows [list | focus|minimize|restore|recover|maximize|close ID | snap ID left|right | chrome ID on|off | tile | cascade]';

export async function run(ctx) {
  const [action = 'list', target, side] = operands(ctx, 0, 3, usage);
  const desktop = system(ctx).desktop;
  if (action === 'list' && target === undefined) return outputRows(ctx, await desktop.list());
  if (['tile', 'cascade'].includes(action) && target === undefined) {
    await desktop.arrange(action);
    await ctx.stdout.write({ kind: 'windows-arranged', arrangement: action, windows: await desktop.list() });
    return;
  }
  if (!['focus', 'minimize', 'restore', 'recover', 'maximize', 'close', 'snap', 'chrome'].includes(action) || !target ||
      (action === 'snap' ? !['left', 'right'].includes(side) : action === 'chrome' ? !['on', 'off'].includes(side) : side !== undefined)) {
    throw new CommandError('E_USAGE', 'Usage: ' + usage);
  }
  const rows = await desktop.list();
  const exact = rows.find(window => window.id === target);
  const matches = exact ? [exact] : rows.filter(window => window.id.startsWith(target));
  if (matches.length !== 1) {
    throw new CommandError('E_WINDOW', matches.length
      ? 'That window ID prefix is ambiguous. Use windows list.'
      : 'No open window matches that ID. Use windows list.');
  }
  ctx.signal?.throwIfAborted();
  const window = matches[0].id;
  if (action === 'snap') await desktop.snap(window, side);
  else if (action === 'chrome') await desktop.chrome(window, side === 'on');
  else await desktop[action](window);
  const state = (await desktop.list()).find(item => item.id === window) ?? null;
  await ctx.stdout.write({ kind: 'window-action', action, window, ...(action === 'snap' ? { side } : {}),
    ...(action === 'chrome' ? { chrome: side === 'on' } : {}),
    ...(action === 'close' ? { closed: state === null } : {}), state });
}
