import { operands, system } from './common.mjs';

export const name = 'rm';
export const summary = 'Remove a file or an empty directory.';
export const usage = 'rm absolute-path';

export async function run(ctx) {
  const [path] = operands(ctx, 1, 1, usage);
  await ctx.stdout.write(await system(ctx).vfs.remove(path));
}
