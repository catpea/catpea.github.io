import { operands, system } from './common.mjs';

export const name = 'cat';
export const summary = 'Read a UTF-8 file as ordered text records.';
export const usage = 'cat absolute-path';
const MAX_CHUNK_UNITS = 16 * 1024;

export async function run(ctx) {
  const [path] = operands(ctx, 1, 1, usage);
  const file = await system(ctx).vfs.read(path);
  let start = 0;
  let part = 0;
  do {
    ctx.signal?.throwIfAborted();
    let end = Math.min(start + MAX_CHUNK_UNITS, file.text.length);
    if (end < file.text.length) {
      const before = file.text.charCodeAt(end - 1);
      const after = file.text.charCodeAt(end);
      if (before >= 0xd800 && before <= 0xdbff && after >= 0xdc00 && after <= 0xdfff) end--;
    }
    await ctx.stdout.write({
      path: file.path,
      revision: file.revision,
      text: file.text.slice(start, end),
      part,
      final: end === file.text.length,
    });
    start = end;
    part++;
  } while (start < file.text.length);
}
