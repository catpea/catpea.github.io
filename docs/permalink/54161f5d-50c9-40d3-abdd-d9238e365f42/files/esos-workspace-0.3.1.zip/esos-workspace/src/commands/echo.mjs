import { operands, outputRows } from './common.mjs';
import { decodeNdjson } from '../protocol/ndjson.mjs';

export const name = 'echo';
export const summary = 'Emit one JSON object or a text record.';
export const usage = 'echo [text | quoted-JSON-object]';

export async function run(ctx) {
  const args = operands(ctx, 0, 128, usage);
  if (!args.length) {
    await outputRows(ctx, ctx.stdin);
    return;
  }
  const text = args.join(' ');
  let record;
  try {
    const parsed = JSON.parse(text);
    if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) record = parsed;
  } catch {}
  if (record) {
    // Apply the same duplicate-key, number, Unicode, and depth policy as a pipe.
    const bytes = new TextEncoder().encode(text + '\n');
    for await (const value of decodeNdjson([bytes])) await ctx.stdout.write(value);
  } else {
    await ctx.stdout.write({ text });
  }
}
