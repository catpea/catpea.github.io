import * as help from './help.mjs';
import * as echo from './echo.mjs';
import * as ls from './ls.mjs';
import * as cat from './cat.mjs';
import * as write from './write.mjs';
import * as mkdir from './mkdir.mjs';
import * as rm from './rm.mjs';
import * as mv from './mv.mjs';
import * as tasks from './tasks.mjs';
import * as events from './events.mjs';
import * as open from './open.mjs';
import * as system from './system.mjs';
import * as groups from './groups.mjs';
import * as exportCommand from './export.mjs';
import * as select from './select.mjs';
import * as where from './where.mjs';
import * as windows from './windows.mjs';
import * as find from './find.mjs';
import * as clipboard from './clipboard.mjs';
import * as software from './software.mjs';
import * as project from './project.mjs';
import * as sync from './sync.mjs';

/**
 * Commands are separate, ordinary ESM modules. The catalog binds only the
 * caller's facade, leaving the existing strict NDJSON runtime unchanged.
 */
export function createCommands(os) {
  const registry = new Map();
  for (const command of [
    help, echo, ls, cat, write, mkdir, rm, mv, tasks, events, open,
    system, groups, exportCommand, select, where, windows, find, clipboard, software, project, sync,
  ]) {
    registry.set(command.name, Object.freeze({
      name: command.name,
      summary: command.summary,
      usage: command.usage,
      run: ctx => command.run({ ...ctx, os, registry }),
    }));
  }
  return registry;
}
