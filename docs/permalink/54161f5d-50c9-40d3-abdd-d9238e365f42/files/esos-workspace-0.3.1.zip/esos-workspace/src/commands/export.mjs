import { operands, system } from './common.mjs';

export const name = 'export';
export const summary = 'Download a standalone workspace export.';
export const usage = 'export';

export async function run(ctx) {
  operands(ctx, 0, 0, usage);
  const receipt = await system(ctx).system.export();
  await ctx.stdout.write({ kind: 'workspace-export', ...(receipt ?? {}) });
}
