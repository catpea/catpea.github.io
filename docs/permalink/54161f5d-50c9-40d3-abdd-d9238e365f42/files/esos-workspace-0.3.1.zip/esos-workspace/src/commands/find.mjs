import { operands, outputRows, system } from './common.mjs';

export const name = 'find';
export const summary = 'Find local files and directories by a literal name or path fragment.';
export const usage = 'find query';

export async function run(ctx) {
  const words = operands(ctx, 1, 127, usage);
  const results = await system(ctx).search.query(words.join(' '), {
    limit: 100, kinds: ['file', 'directory'], signal: ctx.signal
  });
  await outputRows(ctx, results);
}
