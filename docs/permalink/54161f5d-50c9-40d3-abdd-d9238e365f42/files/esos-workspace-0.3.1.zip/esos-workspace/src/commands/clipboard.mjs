import { CommandError, operands, system } from './common.mjs';

export const name = 'clipboard';
export const summary = 'Copy text, read an explicit clipboard source, or inspect clipboard status.';
export const usage = 'clipboard [status | copy [--workspace] [text] | read [--workspace]]';
const encoder = new TextEncoder();
const MAX_BYTES = 1024 * 1024;

export async function run(ctx) {
  const [action = 'status', ...args] = operands(ctx, 0, 127, usage);
  const clipboard = system(ctx).clipboard;
  if (action === 'status' && !args.length) {
    await ctx.stdout.write({ kind: 'clipboard-status', ...clipboard.status() });
    return;
  }
  if (action === 'read' && (!args.length || (args.length === 1 && args[0] === '--workspace'))) {
    const result = await clipboard.readText({ source: args.length ? 'workspace' : 'system' });
    const text = result.text;
    let offset = 0, part = 0;
    do {
      ctx.signal?.throwIfAborted();
      let end = Math.min(offset + 16384, text.length);
      if (end < text.length && /[\uD800-\uDBFF]/.test(text[end - 1])) end--;
      await ctx.stdout.write({ text: text.slice(offset, end), source: result.source, part, final: end === text.length });
      offset = end; part++;
    } while (offset < text.length);
    return;
  }
  if (action !== 'copy') throw new CommandError('E_USAGE', 'Usage: ' + usage);
  const workspace = args[0] === '--workspace';
  const words = workspace ? args.slice(1) : args;
  let text;
  if (words.length) text = words.join(' ');
  else {
    const pieces = [];
    let bytes = 0;
    for await (const record of ctx.stdin) {
      ctx.signal?.throwIfAborted();
      if (typeof record.text !== 'string') throw new CommandError('E_INPUT_SCHEMA', 'clipboard copy expects text records.');
      bytes += encoder.encode(record.text).byteLength;
      if (bytes > MAX_BYTES) throw new CommandError('E_CLIPBOARD_LIMIT', 'The text clipboard is limited to 1 MiB.');
      pieces.push(record.text);
    }
    text = pieces.join('');
  }
  if (encoder.encode(text).byteLength > MAX_BYTES) throw new CommandError('E_CLIPBOARD_LIMIT', 'The text clipboard is limited to 1 MiB.');
  ctx.signal?.throwIfAborted();
  await ctx.stdout.write({ kind: 'clipboard-copied', ...await clipboard.writeText(text, { source: workspace ? 'workspace' : 'auto' }) });
}
