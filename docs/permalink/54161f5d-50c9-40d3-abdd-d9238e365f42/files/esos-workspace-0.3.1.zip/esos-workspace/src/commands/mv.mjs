import { operands, system } from './common.mjs';

export const name = 'mv';
export const summary = 'Rename a file or directory within the local volume.';
export const usage = 'mv source-path destination-path';

export async function run(ctx) {
  const [from, to] = operands(ctx, 2, 2, usage);
  await ctx.stdout.write(await system(ctx).vfs.rename(from, to));
}
