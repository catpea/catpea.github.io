import { CommandError, operands, outputRows, system } from './common.mjs';

export const name = 'tasks';
export const summary = 'List, add, complete, remove, or undo tasks.';
export const usage = 'tasks [list | add TITLE | toggle ID | remove ID | undo | clear-completed]';

export async function run(ctx) {
  const [action = 'list', ...args] = operands(ctx, 0, 128, usage);
  const tasks = system(ctx).tasks;
  if (action === 'list') {
    if (args.length) throw new CommandError('E_USAGE', 'Usage: tasks list');
    const { state } = await tasks.read();
    await outputRows(ctx, state.items.map(item => ({ kind: 'task', ...item })));
    return;
  }
  let input;
  if (action === 'add' && args.length) input = { title: args.join(' ') };
  else if ((action === 'toggle' || action === 'remove') && args.length === 1) input = { id: args[0] };
  else if ((action === 'undo' || action === 'clear-completed') && args.length === 0) input = {};
  else throw new CommandError('E_USAGE', 'Usage: ' + usage);
  const result = await tasks.dispatch(action, input);
  await ctx.stdout.write({
    kind: 'tasks-changed',
    action,
    revision: result.revision,
    operationId: result.operationId,
    total: result.state.items.length,
    remaining: result.state.items.filter(item => !item.done).length,
    events: result.events,
  });
}
