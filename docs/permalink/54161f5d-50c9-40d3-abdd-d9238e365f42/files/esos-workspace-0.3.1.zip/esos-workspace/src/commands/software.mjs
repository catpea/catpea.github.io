import { CommandError, operands, system, outputRows } from './common.mjs';

export const name = 'software';
export const summary = 'Install optional software and publish, import, or export portable programs.';
export const usage = 'software [list [--installed] | inspect|plan|install|enable|disable|remove|repair PACKAGE | publish PROJECT_PATH | import [BUNDLE_PATH] | export PACKAGE [NEW_PATH]]';

export async function run(ctx) {
  const [action = 'list', ...args] = operands(ctx, 0, 3, usage);
  const os = system(ctx), software = os.software;
  if (!software) throw new CommandError('E_CONTEXT', 'The Software service is unavailable.');
  if (action === 'list' && (!args.length || (args.length === 1 && args[0] === '--installed'))) {
    await outputRows(ctx, (args.length ? software.installed() : software.list()).map(item => ({ kind: 'software-package', ...item })));
    return;
  }
  if (['inspect', 'plan', 'install', 'enable', 'disable', 'remove', 'uninstall', 'repair'].includes(action) && args.length === 1) {
    const value = await software[action](args[0]);
    await ctx.stdout.write({ kind: 'software-' + action, ...value });
    return;
  }
  if (action === 'publish' && args.length === 1) {
    const source = await os.projects.load(args[0]);
    ctx.signal?.throwIfAborted();
    await ctx.stdout.write({ kind: 'software-published', ...await software.publish({ project: source.project, sourcePath: source.path }) });
    return;
  }
  if (action === 'import' && args.length <= 1) {
    let bundle;
    if (args.length) {
      const file = await os.vfs.read(args[0]);
      try { bundle = JSON.parse(file.text); }
      catch { throw new CommandError('E_BUNDLE_FORMAT', 'The bundle file must contain one JSON object.'); }
    } else {
      let count = 0;
      for await (const record of ctx.stdin) {
        ctx.signal?.throwIfAborted();
        if (++count > 1) throw new CommandError('E_BUNDLE_FORMAT', 'Import accepts exactly one portable bundle record.');
        bundle = record;
      }
      if (!count) throw new CommandError('E_BUNDLE_FORMAT', 'Supply a bundle path or one portable bundle record on STDIN.');
    }
    ctx.signal?.throwIfAborted();
    await ctx.stdout.write({ kind: 'software-imported', ...await software.importBundle(bundle) });
    return;
  }
  if (action === 'export' && args.length >= 1 && args.length <= 2) {
    const bundle = await software.exportBundle(args[0]);
    ctx.signal?.throwIfAborted();
    if (args.length === 1) await ctx.stdout.write(bundle);
    else {
      const saved = await os.vfs.write(args[1], JSON.stringify(bundle) + '\n', { expectedRevision: 0 });
      const { text: omitted, ...metadata } = saved;
      await ctx.stdout.write({ kind: 'software-bundle-saved', ...metadata });
    }
    return;
  }
  throw new CommandError('E_USAGE', 'Usage: ' + usage);
}
