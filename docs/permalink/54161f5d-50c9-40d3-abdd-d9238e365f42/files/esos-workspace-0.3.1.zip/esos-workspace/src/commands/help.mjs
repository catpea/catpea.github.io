import { CommandError, operands } from './common.mjs';

export const name = 'help';
export const summary = 'List commands or show one command’s usage.';
export const usage = 'help [command]';

export async function run(ctx) {
  const [target] = operands(ctx, 0, 1, usage);
  const registry = ctx.registry;
  if (!registry) throw new CommandError('E_CONTEXT', 'The command catalog is unavailable.');
  if (target) {
    const command = registry.get(target);
    if (!command) throw new CommandError('E_COMMAND_NOT_FOUND', 'Unknown command: ' + target);
    await ctx.stdout.write({ name: command.name, summary: command.summary, usage: command.usage });
    return;
  }
  for (const command of registry.values()) {
    await ctx.stdout.write({ name: command.name, summary: command.summary, usage: command.usage });
  }
}
