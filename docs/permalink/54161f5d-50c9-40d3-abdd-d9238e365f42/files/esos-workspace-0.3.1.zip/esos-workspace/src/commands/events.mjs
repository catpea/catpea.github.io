import { CommandError, operands, outputRows, system } from './common.mjs';

export const name = 'events';
export const summary = 'Read committed events in sequence order.';
export const usage = 'events [tasks | all] [after-sequence]';

export async function run(ctx) {
  const [app = 'tasks', afterText = '0'] = operands(ctx, 0, 2, usage);
  if (app !== 'tasks' && app !== 'all') throw new CommandError('E_USAGE', 'Usage: ' + usage);
  const after = Number(afterText);
  if (!/^\d+$/.test(afterText) || !Number.isSafeInteger(after)) {
    throw new CommandError('E_USAGE', 'The sequence must be a nonnegative safe integer.');
  }
  const os = system(ctx);
  const rows = app === 'tasks'
    ? await os.tasks.history({ after, limit: 100 })
    : await os.journal({ after, limit: 100 });
  await outputRows(ctx, rows);
}
