import { operands, system } from './common.mjs';

export const name = 'mkdir';
export const summary = 'Create one directory; an existing directory is unchanged.';
export const usage = 'mkdir absolute-path';

export async function run(ctx) {
  const [path] = operands(ctx, 1, 1, usage);
  await ctx.stdout.write(await system(ctx).vfs.mkdir(path));
}
