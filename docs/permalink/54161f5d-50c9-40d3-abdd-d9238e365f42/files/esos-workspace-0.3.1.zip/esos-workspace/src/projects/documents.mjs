import * as model from './model.mjs';
import { resolvePath } from '../ui/apps/common.mjs';
import { createProjectDraft } from './draft.mjs';

const home = os => '/home/' + os.profile.username;
export function projectPath(os, path) {
  const resolved = resolvePath(path, home(os), os.profile.username);
  if (!resolved.startsWith(home(os) + '/') || resolved.startsWith(home(os) + '/.local/')) {
    throw new model.ProjectError('E_PROJECT_PATH', 'Save projects in an ordinary folder within your home directory.');
  }
  return resolved;
}
export async function loadProject(os, path, { kind } = {}) {
  const file = await os.vfs.read(projectPath(os, path));
  if (file.managedBy || file.virtual) throw new model.ProjectError('E_PROJECT_PATH', 'Application state and devices are not editable project documents.');
  return { project: model.parseProject(file.text, kind), path: file.path, revision: file.revision };
}
export async function saveProject(os, path, value, { expectedRevision = 0, operationId = crypto.randomUUID() } = {}) {
  const project = model.validateProject(value);
  const target = projectPath(os, path), parent = target.slice(0, target.lastIndexOf('/'));
  let directory = home(os);
  for (const segment of parent.slice(directory.length).split('/').filter(Boolean)) {
    directory += '/' + segment;
    await os.vfs.mkdir(directory);
  }
  const result = await os.vfs.write(target, model.serializeProject(project), { expectedRevision, operationId });
  return { project, path: result.path, revision: result.revision };
}
export function createProjectDocuments(os) {
  return Object.freeze({
    format: model.PROJECT_FORMAT, version: 1, limits: model.PROJECT_LIMITS, components: model.COMPONENTS,
    create: model.newProject, validate: model.validateProject, parse: model.parseProject, serialize: model.serializeProject,
    newId: model.newId, newNode: model.newNode, roots: model.roots, walkNodes: model.walkNodes,
    findNode: model.findNode, replaceNode: model.replaceNode, splitNode: model.splitNode,
    resolvePath: path => projectPath(os, path),
    load: (path, options) => loadProject(os, path, options),
    save: (path, project, options) => saveProject(os, path, project, options),
    createDraft: options => createProjectDraft(os, options)
  });
}

