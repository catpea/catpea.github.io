// Connect portable project data to installed runtimes without importing editors.
export function createProjectAdapter(os) {
  const validate = value => os.projects.validate(value);
  function preparePublish(value) {
    const project = validate(value);
    const providers = new Map((os.software?.commands() ?? []).map(command => [command.name, command]));
    const installedCommands = new Set((os.commands?.list() ?? []).map(command => command.name));
    for (const { node } of os.projects.walkNodes(project)) {
      if (node.action?.kind !== 'command') continue;
      if (!installedCommands.has(node.action.command)) throw new Error('Install the command before publishing this project: ' + node.action.command);
      const command = providers.get(node.action.command);
      if (command) {
        const existing = project.requires.find(item => item.id === command.packageId);
        if (existing && existing.version !== command.version) throw new Error('The project requires a different version of ' + command.packageId + '.');
        if (!existing) project.requires.push({ id: command.packageId, version: command.version });
      }
    }
    project.requires.sort((a, b) => a.id.localeCompare(b.id));
    return validate(project);
  }
  function requirements(value) { return validate(value).requires; }
  async function build(value, context, options = {}) {
    const project = validate(value), releases = [];
    try {
      for (const dependency of project.requires) {
        const installed = os.software.inspect(dependency.id);
        if (installed.installedVersion !== dependency.version) {
          throw new Error('Install ' + dependency.id + '@' + dependency.version + ' from Software before running this project.');
        }
        releases.push(os.software.acquire(dependency.id, { kind: 'window', title: project.name }));
      }
      const namespace = await os.software.loadModule(project.kind === 'workflow' ? 'runtime.workflows' : 'runtime.forms');
      const builder = project.kind === 'workflow' ? namespace.buildWorkflowProgram : namespace.buildProject;
      if (typeof builder !== 'function') throw new Error('The installed project runtime has no program entry.');
      const app = await builder(context, { ...options, project });
      app.cleanup.push(...releases); return app;
    } catch (error) { for (const release of releases) release(); throw error; }
  }
  return Object.freeze({ validate, requirements, preparePublish, build });
}
