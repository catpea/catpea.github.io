// Versioned data documents. This module neither renders nor evaluates project code.
export const PROJECT_FORMAT = 'esos.project';
export const PROJECT_VERSION = 1;
export const PROJECT_LIMITS = Object.freeze({ bytes: 512 * 1024, nodes: 256, cards: 32, depth: 12, fields: 32 });
export const COMPONENTS = Object.freeze([
  { type: 'section', label: 'Region', category: 'Layout', container: true },
  { type: 'heading', label: 'Heading', category: 'Content' },
  { type: 'text', label: 'Text', category: 'Content' },
  { type: 'field', label: 'Field', category: 'Input' },
  { type: 'textarea', label: 'Long text', category: 'Input' },
  { type: 'button', label: 'Button', category: 'Action' },
  { type: 'image', label: 'Picture', category: 'Content' },
  { type: 'output', label: 'Command result', category: 'Content' }
].map(Object.freeze));

export class ProjectError extends Error {
  constructor(code, message) { super(message); this.name = 'ProjectError'; this.code = code; }
}
const fail = message => { throw new ProjectError('E_PROJECT', message); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const ID = /^[A-Za-z][A-Za-z0-9_-]{0,63}$/;
export const newId = (prefix = 'node') => prefix + '-' + crypto.randomUUID();
function string(value, label, maximum = 4096, fallback) {
  if (value === undefined && fallback !== undefined) return fallback;
  if (typeof value !== 'string' || value.length > maximum || /\u0000/.test(value) || !value.isWellFormed()) fail(label + ' must be well-formed text of at most ' + maximum + ' characters.');
  return value;
}
function id(value, label = 'ID') {
  if (typeof value !== 'string' || !ID.test(value)) fail(label + ' must begin with a letter and use at most 64 letters, digits, underscores, or hyphens.');
  return value;
}
function only(value, allowed, label) {
  if (!object(value)) fail(label + ' must be an object.');
  for (const key of Object.keys(value)) if (!allowed.includes(key)) fail(label + ': unsupported property ' + key + '.');
}
function json(value, depth = 0) {
  if (depth > 12) fail('Project data is nested too deeply.');
  if (value === null || typeof value === 'boolean') return value;
  if (typeof value === 'string') return string(value, 'Data', 65536);
  if (typeof value === 'number' && Number.isFinite(value) && (!Number.isInteger(value) || Number.isSafeInteger(value))) return value;
  if (Array.isArray(value) && value.length <= 256) return value.map(item => json(item, depth + 1));
  if (object(value) && Object.keys(value).length <= 128) {
    const result = {};
    for (const [key, child] of Object.entries(value)) {
      if (['__proto__', 'prototype', 'constructor'].includes(key)) fail('Reserved data key.');
      string(key, 'Data key', 96);
      result[key] = json(child, depth + 1);
    }
    return result;
  }
  fail('Projects contain bounded JSON data only.');
}

export function validateAction(value) {
  if (value === undefined || value === null) return null;
  if (!object(value)) fail('An action must be an object.');
  if (value.kind === 'command') {
    only(value, ['kind', 'command', 'args', 'input', 'output'], 'Command action');
    if (typeof value.command !== 'string' || !/^[A-Za-z][A-Za-z0-9_.:-]{0,95}$/.test(value.command)) fail('Choose a valid command name.');
    if (!Array.isArray(value.args) || value.args.length > 32) fail('Command arguments must be an array with at most 32 text values.');
    const result = { kind: 'command', command: value.command, args: value.args.map(arg => string(arg, 'Argument', 4096)) };
    if (JSON.stringify(result.args).length > 16384) fail('An argument definition must fit within 16,384 characters.');
    if (value.input !== undefined) {
      if (!Array.isArray(value.input) || value.input.length > 64 || value.input.some(item => !object(item))) fail('Action input must be at most 64 JSON object records.');
      result.input = json(value.input);
      if (JSON.stringify(result.input).length > 16384) fail('Literal action input must fit within 16,384 characters. Use a command to read larger data.');
    }
    if (value.output) result.output = id(value.output, 'Output component');
    return result;
  }
  if (value.kind === 'navigate') {
    only(value, ['kind', 'card'], 'Navigation action');
    return { kind: 'navigate', card: ['next', 'previous', 'first', 'last'].includes(value.card) ? value.card : id(value.card, 'Card') };
  }
  if (value.kind === 'message') {
    only(value, ['kind', 'text', 'output'], 'Message action');
    return { kind: 'message', text: string(value.text, 'Message', 16384), ...(value.output ? { output: id(value.output) } : {}) };
  }
  if (value.kind === 'set-field') {
    only(value, ['kind', 'field', 'value'], 'Field action');
    return { kind: 'set-field', field: id(value.field, 'Field'), value: string(value.value, 'Field value', 16384) };
  }
  fail('This release supports command, navigation, message, and set-field actions.');
}

export function roots(project) {
  return project.kind === 'form' ? [project.form.root]
    : project.kind === 'cards' ? [project.stack.background, ...project.stack.cards.map(card => card.root)] : [];
}
export function walkNodes(project) {
  const result = [];
  function visit(node, parent = null, depth = 0) {
    result.push({ node, parent, depth });
    for (const child of node.children ?? []) visit(child, node, depth + 1);
  }
  for (const root of roots(project)) visit(root);
  return result;
}
export const findNode = (project, nodeId) => walkNodes(project).find(item => item.node.id === nodeId)?.node ?? null;

/** Validate every known field and return a clean, independently owned snapshot. */
export function validateProject(value, expectedKind) {
  only(value, ['format', 'version', 'id', 'name', 'description', 'kind', 'requires', 'presentation', 'form', 'stack', 'workflow'], 'Project');
  if (value.format !== PROJECT_FORMAT || value.version !== PROJECT_VERSION) fail('Unsupported project format or version. This release opens esos.project version 1.');
  if (!['form', 'cards', 'workflow'].includes(value.kind) || (expectedKind && value.kind !== expectedKind)) fail('This editor opens ' + (expectedKind ?? 'form, cards, or workflow') + ' projects.');
  const project = { format: PROJECT_FORMAT, version: 1, id: id(value.id, 'Project ID'), kind: value.kind,
    name: string(value.name, 'Project name', 100), description: string(value.description, 'Description', 600, ''), requires: [] };
  if (!/^[a-z][a-z0-9_-]{0,63}$/.test(project.id)) fail('Project IDs use lowercase letters, digits, underscores, or hyphens and begin with a letter.');
  if (!project.name.trim()) fail('Give the project a name.');
  only(value.presentation ?? {}, ['chrome', 'maximized'], 'Presentation');
  const presentation = value.presentation ?? {};
  if (['chrome', 'maximized'].some(key => presentation[key] !== undefined && typeof presentation[key] !== 'boolean')) fail('Window presentation settings must be true or false.');
  project.presentation = { chrome: presentation.chrome ?? true, maximized: presentation.maximized ?? true };
  if (value.requires !== undefined && (!Array.isArray(value.requires) || value.requires.length > 16)) fail('A project may declare at most 16 runtime requirements.');
  for (const requirement of value.requires ?? []) {
    only(requirement, ['id', 'version'], 'Requirement');
    if (typeof requirement.id !== 'string' || !/^[a-z][a-z0-9.-]{0,95}$/.test(requirement.id) ||
        typeof requirement.version !== 'string' || !/^\d+\.\d+\.\d+(?:-[A-Za-z0-9.-]+)?(?:\+[A-Za-z0-9.-]+)?$/.test(requirement.version)) fail('A requirement needs a package ID and exact version.');
    if (project.requires.some(item => item.id === requirement.id)) fail('Runtime requirements must be unique.');
    project.requires.push({ id: requirement.id, version: requirement.version });
  }
  const required = project.kind === 'workflow' ? ['runtime.workflows'] : project.kind === 'cards' ? ['runtime.forms', 'runtime.cards'] : ['runtime.forms'];
  for (const name of required) {
    const declared = project.requires.find(item => item.id === name);
    if (declared && declared.version !== '1.0.0') fail('This document requires an unsupported runtime version.');
    if (!declared) project.requires.push({ id: name, version: '1.0.0' });
  }
  const seen = new Set();
  let count = 0;
  const actions = [];
  function node(value, depth = 0) {
    if (++count > PROJECT_LIMITS.nodes || depth > PROJECT_LIMITS.depth) fail('A project supports at most 256 components and 12 nested levels.');
    only(value, ['id', 'type', 'text', 'label', 'value', 'placeholder', 'required', 'inputType', 'tone', 'direction', 'ratio', 'collapse', 'children', 'action', 'src', 'alt', 'fit'], 'Component');
    const result = { id: id(value.id, 'Component ID'), type: value.type };
    if (seen.has(result.id)) fail('Component IDs must be unique throughout the project.');
    seen.add(result.id);
    if (!['section', 'split', 'heading', 'text', 'field', 'textarea', 'button', 'output', 'image'].includes(value.type)) fail('Unknown component type: ' + String(value.type));
    const allowed = ['id', 'type'];
    if (['section', 'split'].includes(value.type)) {
      allowed.push('children', 'label');
      result.label = string(value.label, 'Region label', 120, value.type === 'split' ? 'Split' : 'Region');
      if (!Array.isArray(value.children) || value.children.length > 64) fail('A region contains at most 64 children.');
      result.children = value.children.map(child => node(child, depth + 1));
      if (value.type === 'split') {
        allowed.push('direction', 'ratio', 'collapse');
        if (!['horizontal', 'vertical'].includes(value.direction) || result.children.length !== 2) fail('A split has a horizontal or vertical direction and exactly two regions.');
        result.direction = value.direction;
        result.ratio = value.ratio ?? 'equal';
        if (!['equal', 'wide-first', 'wide-second'].includes(result.ratio)) fail('Unsupported split ratio.');
        result.collapse = value.collapse ?? 650;
        if (![420, 650, 900, 'never'].includes(result.collapse)) fail('Choose a split collapse width of 420, 650, 900, or never.');
      }
    } else if (['field', 'textarea'].includes(value.type)) {
      allowed.push('label', 'value', 'placeholder', 'required', 'inputType');
      result.label = string(value.label, 'Field label', 240, 'Field');
      result.value = string(value.value, 'Initial field value', 16384, '');
      result.placeholder = string(value.placeholder, 'Placeholder', 240, '');
      if (value.required !== undefined && typeof value.required !== 'boolean') fail('Required must be true or false.');
      result.required = value.required ?? false;
      result.inputType = value.inputType ?? 'text';
      if (!['text', 'email', 'number', 'date', 'url', 'search'].includes(result.inputType)) fail('Unsupported field input type.');
    } else if (value.type === 'image') {
      allowed.push('src', 'alt', 'fit');
      result.src = string(value.src, 'Picture', 350000, '');
      if (result.src && !/^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(result.src)) fail('Pictures must be embedded PNG, JPEG, GIF, or WebP images.');
      result.alt = string(value.alt, 'Picture description', 500, 'Picture');
      result.fit = value.fit ?? 'contain';
      if (!['contain', 'cover'].includes(result.fit)) fail('Picture fit must be contain or cover.');
    } else {
      allowed.push('text');
      result.text = string(value.text, 'Component text', value.type === 'text' ? 16384 : 1000, '');
      if (value.type === 'button') {
        allowed.push('tone', 'action');
        result.tone = value.tone ?? 'primary';
        if (!['primary', 'secondary', 'success'].includes(result.tone)) fail('Unsupported button tone.');
        result.action = validateAction(value.action);
        if (result.action) actions.push(result.action);
      }
    }
    for (const key of Object.keys(value)) if (!allowed.includes(key)) fail(value.type + ' does not support the property ' + key + '.');
    return result;
  }
  if (project.kind === 'form') {
    if (value.stack !== undefined || value.workflow !== undefined) fail('A form project contains only its form document.');
    only(value.form, ['root'], 'Form');
    project.form = { root: node(value.form.root) };
  } else if (project.kind === 'cards') {
    if (value.form !== undefined || value.workflow !== undefined) fail('A Cards project contains only its stack document.');
    only(value.stack, ['background', 'cards', 'startCard'], 'Stack');
    if (!Array.isArray(value.stack.cards) || !value.stack.cards.length || value.stack.cards.length > PROJECT_LIMITS.cards) fail('A stack contains 1–32 cards.');
    const ids = new Set();
    project.stack = { background: node(value.stack.background), cards: value.stack.cards.map(card => {
      only(card, ['id', 'name', 'root'], 'Card');
      const cardId = id(card.id, 'Card ID');
      if (ids.has(cardId)) fail('Card IDs must be unique.');
      ids.add(cardId);
      return { id: cardId, name: string(card.name, 'Card name', 120), root: node(card.root) };
    }), startCard: id(value.stack.startCard, 'Starting card') };
    if (!ids.has(project.stack.startCard)) fail('The starting card must belong to the stack.');
    for (const action of actions) if (action.kind === 'navigate' && !['next', 'previous', 'first', 'last'].includes(action.card) && !ids.has(action.card)) fail('A navigation action points to a missing card.');
  } else {
    if (value.form !== undefined || value.stack !== undefined) fail('A workflow project contains only its workflow document.');
    only(value.workflow, ['version', 'actions'], 'Workflow');
    if ((value.workflow.version ?? 1) !== 1 || !Array.isArray(value.workflow.actions) || value.workflow.actions.length > 64) fail('A workflow contains at most 64 actions.');
    const ids = new Set();
    project.workflow = { version: 1, actions: value.workflow.actions.map(action => {
      only(action, ['id', 'action', 'parameters'], 'Workflow action');
      const actionId = id(action.id, 'Action ID');
      if (ids.has(actionId)) fail('Workflow action IDs must be unique.');
      ids.add(actionId);
      if (!object(action.parameters ?? {})) fail('Action parameters must be an object.');
      return { id: actionId, action: string(action.action, 'Action type', 96), parameters: json(action.parameters ?? {}) };
    }) };
  }
  const all = walkNodes(project).map(item => item.node), byId = new Map(all.map(item => [item.id, item]));
  for (const action of actions) {
    if (action.kind === 'navigate' && project.kind !== 'cards') fail('Navigation belongs to a Cards stack.');
    if (action.output && byId.get(action.output)?.type !== 'output') fail('An action output must name a Command result component.');
    if (action.kind === 'set-field' && !['field', 'textarea'].includes(byId.get(action.field)?.type)) fail('A set-field action must name a field.');
    const values = action.kind === 'command' ? action.args : [action.text ?? action.value ?? ''];
    for (const value of values) for (const match of value.matchAll(/\{\{([A-Za-z][A-Za-z0-9_-]{0,63})\}\}/g)) {
      if (!['field', 'textarea'].includes(byId.get(match[1])?.type)) fail('The binding {{' + match[1] + '}} points to a missing field.');
    }
  }
  const fieldCount = root => { let count = 0; function visit(n) { if (['field', 'textarea'].includes(n.type)) count++; for (const child of n.children ?? []) visit(child); } visit(root); return count; };
  if (project.kind === 'form' && fieldCount(project.form.root) > PROJECT_LIMITS.fields) fail('A form supports at most 32 fields.');
  if (project.kind === 'cards' && project.stack.cards.some(card => fieldCount(project.stack.background) + fieldCount(card.root) > PROJECT_LIMITS.fields)) fail('A card and its background support at most 32 fields together.');
  if (new TextEncoder().encode(JSON.stringify(project, null, 2) + '\n').byteLength > PROJECT_LIMITS.bytes) fail('A project document must fit within 512 KiB.');
  return project;
}

export function parseProject(text, kind) {
  if (typeof text !== 'string' || new TextEncoder().encode(text).byteLength > PROJECT_LIMITS.bytes) fail('A project document must fit within 512 KiB.');
  let value;
  try { value = JSON.parse(text); } catch { fail('The project is not valid JSON.'); }
  return validateProject(value, kind);
}
export const serializeProject = project => JSON.stringify(validateProject(project), null, 2) + '\n';
export function newNode(type) {
  const node = { id: newId(type), type };
  if (type === 'section') return { ...node, label: 'Region', children: [] };
  if (type === 'field' || type === 'textarea') return { ...node, label: type === 'field' ? 'Field' : 'Notes', value: '', placeholder: '', required: false, inputType: 'text' };
  if (type === 'button') return { ...node, text: 'Continue', tone: 'primary', action: { kind: 'message', text: 'Hello from your application.' } };
  if (type === 'image') return { ...node, src: '', alt: 'Picture', fit: 'contain' };
  if (type === 'heading') return { ...node, text: 'A new section' };
  if (type === 'text') return { ...node, text: 'Write something useful here.' };
  if (type === 'output') return { ...node, text: 'Results appear here.' };
  fail('Choose a component from the palette.');
}
export function newProject(kind = 'form') {
  const project = { format: PROJECT_FORMAT, version: 1, id: newId('project'), kind,
    name: kind === 'cards' ? 'My first stack' : kind === 'workflow' ? 'My workflow' : 'Quick task', description: '', requires: [] };
  if (kind === 'form') {
    const field = { ...newNode('field'), label: 'What needs doing?', placeholder: 'A small useful task', required: true };
    const output = newNode('output');
    project.form = { root: { ...newNode('section'), label: 'Main form', children: [
      { ...newNode('heading'), text: 'One thing at a time.' },
      { ...newNode('text'), text: 'Add a task to the shared Tasks application. This form uses the ordinary tasks command.' }, field,
      { ...newNode('button'), text: 'Add task', action: { kind: 'command', command: 'tasks', args: ['add', '{{' + field.id + '}}'], output: output.id } }, output
    ] } };
  } else if (kind === 'cards') {
    const card1 = newId('card'), card2 = newId('card');
    project.stack = { background: { ...newNode('section'), label: 'Shared background', children: [
      { ...newNode('text'), text: 'My first stack · made with Cards' }
    ] }, startCard: card1, cards: [
      { id: card1, name: 'Welcome', root: { ...newNode('section'), label: 'Welcome card', children: [
        { ...newNode('heading'), text: 'Welcome to your stack.' },
        { ...newNode('text'), text: 'Cards are pages you can connect. Edit a field or button, then Run to try your stack.' },
        { ...newNode('button'), text: 'Turn the card', action: { kind: 'navigate', card: card2 } }
      ] } },
      { id: card2, name: 'Notes', root: { ...newNode('section'), label: 'Notes card', children: [
        { ...newNode('heading'), text: 'A place for your thoughts.' }, newNode('textarea'),
        { ...newNode('button'), text: 'Back to welcome', tone: 'secondary', action: { kind: 'navigate', card: card1 } }
      ] } }
    ] };
  } else if (kind === 'workflow') project.workflow = { version: 1, actions: [] };
  return validateProject(project);
}

/** Replace a node while preserving all unrelated stable component identities. */
export function replaceNode(project, nodeId, replacement) {
  const next = structuredClone(project);
  const item = walkNodes(next).find(item => item.node.id === nodeId);
  if (!item) fail('That component is no longer in the project.');
  if (item.parent) item.parent.children[item.parent.children.findIndex(node => node.id === nodeId)] = replacement;
  else if (next.kind === 'form') next.form.root = replacement;
  else if (next.stack.background.id === nodeId) next.stack.background = replacement;
  else next.stack.cards.find(card => card.root.id === nodeId).root = replacement;
  return validateProject(next);
}
export function splitNode(project, nodeId, side) {
  if (!['left', 'right', 'up', 'down'].includes(side)) fail('Choose left, right, up, or down.');
  const original = findNode(project, nodeId);
  if (!original) fail('Select a region or component to split.');
  const region = newNode('section');
  const split = { id: newId('split'), type: 'split', label: 'Split region',
    direction: ['left', 'right'].includes(side) ? 'horizontal' : 'vertical', ratio: 'equal', collapse: 650,
    children: ['left', 'up'].includes(side) ? [region, structuredClone(original)] : [structuredClone(original), region] };
  return { project: replaceNode(project, nodeId, split), selected: region.id };
}

