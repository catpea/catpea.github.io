import { newProject, validateProject, serializeProject, ProjectError } from './model.mjs';
import { loadProject, saveProject, projectPath } from './documents.mjs';

/** One document per editor window; changing a draft never writes storage. */
export async function createProjectDraft(os, { kind, path, project } = {}) {
  const initial = path ? await loadProject(os, path, { kind })
    : { project: project ? validateProject(project, kind) : newProject(kind), path: null, revision: 0 };
  let current = initial.project, saved = initial.path ? serializeProject(initial.project) : null;
  let savedPath = initial.path, revision = initial.revision;
  let displayPath = initial.path ?? '/home/' + os.profile.username + '/' + (kind === 'cards' ? 'my-stack' : kind === 'workflow' ? 'my-workflow' : 'my-form') + '.esos.json';
  let generation = crypto.randomUUID(), version = 0, saving = false;
  let undo = [], redo = [];
  function remember(value) {
    undo.push(value);
    while (undo.length > 30 || (undo.length > 1 && undo.reduce((sum, item) => sum + item.length, 0) > 1024 * 1024)) undo.shift();
    redo = [];
  }
  function assign(value, rememberOld = true) {
    const next = validateProject(value, kind);
    const old = serializeProject(current);
    if (serializeProject(next) === old) return false;
    if (rememberOld) remember(old);
    current = next; version++; return true;
  }
  return Object.freeze({
    get project() { return structuredClone(current); },
    get path() { return savedPath; },
    get displayPath() { return displayPath; },
    get revision() { return revision; },
    get generation() { return generation; },
    get version() { return version; },
    get saving() { return saving; },
    get dirty() { return saved === null || serializeProject(current) !== saved || displayPath !== savedPath; },
    get canUndo() { return undo.length > 0; },
    get canRedo() { return redo.length > 0; },
    setPath(value) { if (typeof value !== 'string' || value.length > 1024) throw new ProjectError('E_PROJECT_PATH', 'Enter a short project path.'); if (displayPath !== value) { displayPath = value; version++; } },
    change(mutator) { const next = structuredClone(current); const result = mutator(next); return assign(result ?? next); },
    replace(value) { return assign(value); },
    undo() { if (!undo.length) return false; redo.push(serializeProject(current)); current = JSON.parse(undo.pop()); version++; return true; },
    redo() { if (!redo.length) return false; undo.push(serializeProject(current)); current = JSON.parse(redo.pop()); version++; return true; },
    async load(path, { expectedGeneration = generation, expectedVersion = version } = {}) {
      if (saving) throw new ProjectError('E_PROJECT_BUSY', 'Wait for the current save to finish.');
      const loaded = await loadProject(os, path, { kind });
      if (generation !== expectedGeneration || version !== expectedVersion) throw new ProjectError('E_PROJECT_CHANGED', 'The draft changed while opening the project. Your draft was kept.');
      current = loaded.project; savedPath = displayPath = loaded.path; revision = loaded.revision;
      saved = serializeProject(current); generation = crypto.randomUUID(); version++; undo = []; redo = [];
      return loaded;
    },
    reset() {
      if (saving) throw new ProjectError('E_PROJECT_BUSY', 'Wait for the current save to finish.');
      current = newProject(kind); saved = null; savedPath = null; revision = 0;
      displayPath = '/home/' + os.profile.username + '/' + (kind === 'cards' ? 'my-stack' : kind === 'workflow' ? 'my-workflow' : 'my-form') + '.esos.json';
      generation = crypto.randomUUID(); version++; undo = []; redo = [];
    },
    async save({ operationId = crypto.randomUUID(), expectedGeneration = generation, path = displayPath } = {}) {
      if (saving) throw new ProjectError('E_PROJECT_BUSY', 'This project is already saving.');
      if (generation !== expectedGeneration) throw new ProjectError('E_PROJECT_CHANGED', 'That save belonged to a previous document.');
      const snapshot = structuredClone(current), target = projectPath(os, path), capturedGeneration = generation;
      const expectedRevision = target === savedPath ? revision : 0;
      saving = true;
      try {
        const result = await saveProject(os, target, snapshot, { expectedRevision, operationId });
        if (capturedGeneration !== generation) throw new ProjectError('E_PROJECT_CHANGED', 'A different document is now open. The completed save did not replace it.');
        saved = serializeProject(snapshot); savedPath = result.path; revision = result.revision;
        // A typed replacement path remains an unsaved change.
        if (displayPath === path) displayPath = result.path;
        return result;
      } finally { saving = false; }
    }
  });
}
