// The local volume contract. This module receives a private SQLite OO1 connection.
// It exposes named operations, never SQL, to the worker's clients.
const encoder = new TextEncoder();
const FILE_LIMIT = 1024 * 1024;
const JSON_LIMIT = 1024 * 1024;
const EXPORT_LIMIT = 64 * 1024 * 1024;
const ROOT_ID = 'root';
const MUTATIONS = new Set(['mkdir', 'write', 'remove', 'rename', 'commit']);

export class StorageError extends Error {
  constructor(code, message, details) {
    super(message);
    this.name = 'StorageError';
    this.code = code;
    if (details !== undefined) this.details = details;
  }
}

const fail = (code, message, details) => { throw new StorageError(code, message, details); };
const now = () => new Date().toISOString();
const bytes = value => encoder.encode(value).byteLength;

function textValue(value, label, limit = FILE_LIMIT) {
  if (typeof value !== 'string') fail('E_ARGUMENT', label + ' must be a string.');
  if (typeof value.isWellFormed === 'function' && !value.isWellFormed()) {
    fail('E_ARGUMENT', label + ' must contain well-formed Unicode.');
  }
  if (bytes(value) > limit) fail('E_LIMIT', label + ' exceeds its byte limit.');
  return value;
}

function identifier(value, label = 'Identifier') {
  textValue(value, label, 160);
  if (!/^[a-zA-Z0-9][a-zA-Z0-9_.:/-]*$/.test(value)) {
    fail('E_ARGUMENT', label + ' contains unsupported characters.');
  }
  return value;
}

function integer(value, label, minimum = 0) {
  if (!Number.isSafeInteger(value) || value < minimum) {
    fail('E_ARGUMENT', label + ' must be a safe integer of at least ' + minimum + '.');
  }
  return value;
}

// A deterministic JSON representation makes operation-ID reuse checkable.
function canonical(value, depth = 0, seen = new Set()) {
  if (depth > 48) fail('E_LIMIT', 'JSON nesting exceeds 48 levels.');
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return JSON.stringify(textValue(value, 'JSON string'));
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) {
      fail('E_ARGUMENT', 'JSON numbers must be finite and integer values must be exact.');
    }
    return JSON.stringify(value);
  }
  if (!value || typeof value !== 'object' ||
      (!Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype &&
       Object.getPrototypeOf(value) !== null)) {
    fail('E_ARGUMENT', 'Only plain JSON data is accepted.');
  }
  if (seen.has(value)) fail('E_ARGUMENT', 'Cyclic JSON data is not accepted.');
  seen.add(value);
  let output;
  if (Array.isArray(value)) {
    if (value.length > 16384) fail('E_LIMIT', 'JSON array is too large.');
    output = '[' + value.map(item => canonical(item, depth + 1, seen)).join(',') + ']';
  } else {
    const keys = Object.keys(value).sort();
    if (keys.length > 4096) fail('E_LIMIT', 'JSON object has too many properties.');
    output = '{' + keys.map(key => JSON.stringify(textValue(key, 'JSON key', 1024)) +
      ':' + canonical(value[key], depth + 1, seen)).join(',') + '}';
  }
  seen.delete(value);
  return output;
}

function json(value, label = 'JSON data', limit = JSON_LIMIT) {
  const result = canonical(value);
  if (bytes(result) > limit) fail('E_LIMIT', label + ' exceeds its byte limit.');
  return result;
}

function pathValue(value = '/') {
  textValue(value, 'Path', 4096);
  if (!value.startsWith('/')) fail('E_PATH', 'A filesystem path must be absolute.');
  if (/[\u0000-\u001f\u007f]/.test(value)) fail('E_PATH', 'A path cannot contain control characters.');
  const normalized = value.length > 1 && value.endsWith('/') ? value.slice(0, -1) : value;
  if (normalized === '/') return '/';
  const parts = normalized.slice(1).split('/');
  if (parts.length > 64) fail('E_LIMIT', 'Path nesting exceeds 64 levels.');
  if (parts.some(part => !part || part === '.' || part === '..' || bytes(part) > 255)) {
    fail('E_PATH', 'Path segments must be nonempty names of at most 255 UTF-8 bytes; dot segments are not accepted.');
  }
  return normalized;
}

function expectedRevision(value) {
  return value === undefined ? undefined : integer(value, 'Expected revision');
}

function revisionAfter(value) {
  if (!Number.isSafeInteger(value) || value >= Number.MAX_SAFE_INTEGER) {
    fail('E_LIMIT', 'Revision counter is exhausted.');
  }
  return value + 1;
}

export class Volume {
  constructor(db) {
    this.db = db;
    db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA temp_store=MEMORY; PRAGMA trusted_schema=OFF;');
    const version = Number(db.selectValue('PRAGMA user_version'));
    if (version === 0) {
      const existing = Number(db.selectValue("SELECT count(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"));
      if (existing) fail('E_FORMAT', 'This database is not an empty eSOS volume; it was preserved.');
      this.transaction(() => {
        db.exec(`
          CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
          CREATE TABLE nodes(
            id TEXT PRIMARY KEY,
            parent_id TEXT REFERENCES nodes(id),
            name TEXT NOT NULL,
            kind TEXT NOT NULL CHECK(kind IN ('file','directory')),
            content TEXT,
            revision INTEGER NOT NULL CHECK(revision >= 1),
            updated_at TEXT NOT NULL,
            owner_app TEXT,
            UNIQUE(parent_id,name),
            CHECK((kind='directory' AND content IS NULL) OR (kind='file' AND content IS NOT NULL))
          );
          CREATE INDEX nodes_parent ON nodes(parent_id);
          CREATE TABLE states(
            app TEXT PRIMARY KEY,
            state_json TEXT NOT NULL,
            revision INTEGER NOT NULL CHECK(revision >= 1),
            updated_at TEXT NOT NULL
          );
          CREATE TABLE events(
            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
            id TEXT UNIQUE NOT NULL,
            app TEXT NOT NULL,
            revision INTEGER NOT NULL,
            type TEXT NOT NULL,
            data_json TEXT NOT NULL,
            accepted_at TEXT NOT NULL,
            operation_id TEXT NOT NULL
          );
          CREATE INDEX events_app_sequence ON events(app,sequence);
          CREATE TABLE operations(
            id TEXT PRIMARY KEY,
            method TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            result_json TEXT NOT NULL,
            committed_at TEXT NOT NULL
          );
          PRAGMA user_version=1;
        `);
        this.execute('INSERT INTO metadata(key,value) VALUES(?,?)', ['format', 'esos-workspace/1']);
        this.execute('INSERT INTO metadata(key,value) VALUES(?,?)', ['volume-id', crypto.randomUUID()]);
        this.execute('INSERT INTO nodes(id,parent_id,name,kind,content,revision,updated_at) VALUES(?,NULL,?,?,NULL,1,?)',
          [ROOT_ID, '', 'directory', now()]);
        for (const path of ['/home', '/etc', '/var', '/var/log']) this.createDirectory(path);
      });
    } else if (version !== 1) {
      fail('E_FORMAT', 'Unsupported volume format ' + version + '; existing data was preserved.');
    }
    if (db.selectValue('SELECT value FROM metadata WHERE key=?', ['format']) !== 'esos-workspace/1') {
      fail('E_FORMAT', 'The volume format marker is invalid; existing data was preserved.');
    }
    this.volumeId = db.selectValue('SELECT value FROM metadata WHERE key=?', ['volume-id']);
    if (typeof this.volumeId !== 'string') fail('E_FORMAT', 'The volume identity is missing.');
  }

  execute(sql, bind = []) { this.db.exec({ sql, bind }); }
  one(sql, bind = []) { return this.db.selectObject(sql, bind); }
  all(sql, bind = []) { return this.db.selectObjects(sql, bind); }

  transaction(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn();
      this.db.exec('COMMIT');
      return result;
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch { /* Keep the primary failure. */ }
      throw error;
    }
  }

  resolve(path) {
    path = pathValue(path);
    let node = this.one('SELECT * FROM nodes WHERE id=?', [ROOT_ID]);
    if (path === '/') return node;
    for (const part of path.slice(1).split('/')) {
      if (node.kind !== 'directory') fail('E_NOT_DIRECTORY', 'A path component is not a directory.');
      node = this.one('SELECT * FROM nodes WHERE parent_id=? AND name=?', [node.id, part]);
      if (!node) fail('E_NOT_FOUND', 'Path does not exist: ' + path);
    }
    return node;
  }

  parent(path) {
    path = pathValue(path);
    if (path === '/') fail('E_ROOT', 'The volume root cannot be replaced.');
    const split = path.lastIndexOf('/');
    const parent = this.resolve(split === 0 ? '/' : path.slice(0, split));
    if (parent.kind !== 'directory') fail('E_NOT_DIRECTORY', 'The parent is not a directory.');
    return { parent, name: path.slice(split + 1), path };
  }

  metadata(node, path) {
    return {
      id: node.id, path, name: node.name || '/', kind: node.kind,
      revision: Number(node.revision), updatedAt: node.updated_at,
      bytes: node.kind === 'file' ? bytes(node.content) : 0,
      managedBy: node.owner_app || null
    };
  }

  createDirectory(path) {
    const { parent, name, path: canonicalPath } = this.parent(path);
    const existing = this.one('SELECT * FROM nodes WHERE parent_id=? AND name=?', [parent.id, name]);
    if (existing) {
      if (existing.kind !== 'directory') fail('E_EXISTS', 'A file already occupies this path.');
      return { ...this.metadata(existing, canonicalPath), existed: true };
    }
    const node = { id: crypto.randomUUID(), parent_id: parent.id, name, kind: 'directory',
      content: null, revision: 1, updated_at: now(), owner_app: null };
    this.execute('INSERT INTO nodes(id,parent_id,name,kind,content,revision,updated_at) VALUES(?,?,?,?,NULL,1,?)',
      [node.id, parent.id, name, 'directory', node.updated_at]);
    return { ...this.metadata(node, canonicalPath), existed: false };
  }

  writeFile({ path, text, expectedRevision: expected }, ownerApp = null) {
    textValue(text, 'File content');
    expectedRevision(expected);
    const location = this.parent(path);
    const old = this.one('SELECT * FROM nodes WHERE parent_id=? AND name=?', [location.parent.id, location.name]);
    if (old && old.kind !== 'file') fail('E_IS_DIRECTORY', 'Cannot write text over a directory.');
    if (old?.owner_app && old.owner_app !== ownerApp) {
      fail('E_MANAGED_FILE', 'This file is a managed application projection. Use its application commands.');
    }
    if (ownerApp && old && !old.owner_app) {
      fail('E_PROJECTION_EXISTS', 'An ordinary file already occupies this application projection path.');
    }
    const prior = old ? Number(old.revision) : 0;
    if (expected !== undefined && expected !== prior) {
      fail('E_CONFLICT', 'The file changed before this write could be committed.',
        { expectedRevision: expected, actualRevision: prior });
    }
    const node = { id: old?.id || crypto.randomUUID(), parent_id: location.parent.id,
      name: location.name, kind: 'file', content: text, revision: revisionAfter(prior),
      updated_at: now(), owner_app: ownerApp };
    if (old) {
      this.execute('UPDATE nodes SET content=?,revision=?,updated_at=?,owner_app=? WHERE id=?',
        [text, node.revision, node.updated_at, ownerApp, node.id]);
    } else {
      this.execute('INSERT INTO nodes(id,parent_id,name,kind,content,revision,updated_at,owner_app) VALUES(?,?,?,?,?,?,?,?)',
        [node.id, node.parent_id, node.name, node.kind, text, node.revision, node.updated_at, ownerApp]);
    }
    return this.metadata(node, location.path);
  }

  appendEvent(app, revision, event, operationId, acceptedAt) {
    if (!event || typeof event !== 'object' || Array.isArray(event)) {
      fail('E_ARGUMENT', 'A domain event must be an object.');
    }
    identifier(event.type, 'Event type');
    const dataJson = json(event.data ?? null, 'Event payload', 64 * 1024);
    const id = crypto.randomUUID();
    this.execute('INSERT INTO events(id,app,revision,type,data_json,accepted_at,operation_id) VALUES(?,?,?,?,?,?,?)',
      [id, app, revision, event.type, dataJson, acceptedAt, operationId]);
    return this.eventRecord(this.one('SELECT * FROM events WHERE id=?', [id]));
  }

  eventRecord(row) {
    return { sequence: Number(row.sequence), id: row.id, app: row.app,
      revision: Number(row.revision), type: row.type, data: JSON.parse(row.data_json),
      acceptedAt: row.accepted_at, operationId: row.operation_id };
  }

  currentState(app) {
    identifier(app, 'Application id');
    const row = this.one('SELECT * FROM states WHERE app=?', [app]);
    return row ? { app, state: JSON.parse(row.state_json), revision: Number(row.revision),
      updatedAt: row.updated_at } : { app, state: null, revision: 0, updatedAt: null };
  }

  operation(operationId) {
    identifier(operationId, 'Operation id');
    const row = this.one('SELECT * FROM operations WHERE id=?', [operationId]);
    return row ? { operationId, status: 'committed', method: row.method,
      result: JSON.parse(row.result_json), committedAt: row.committed_at } :
      { operationId, status: 'unknown' };
  }

  async call(method, args = {}) {
    if (!args || typeof args !== 'object' || Array.isArray(args)) {
      fail('E_ARGUMENT', 'Operation arguments must be an object.');
    }
    if (MUTATIONS.has(method)) {
      const operationId = identifier(args.operationId, 'Operation id');
      const request = Object.fromEntries(Object.entries(args)
        .filter(([key, value]) => key !== 'operationId' && value !== undefined));
      const requestJson = json({ method, args: request }, 'Mutation request', 20 * FILE_LIMIT);
      const digest = await crypto.subtle.digest('SHA-256', encoder.encode(requestJson));
      const fingerprint = Array.from(new Uint8Array(digest), value => value.toString(16).padStart(2, '0')).join('');
      return this.transaction(() => {
        const prior = this.one('SELECT * FROM operations WHERE id=?', [operationId]);
        if (prior) {
          if (prior.method !== method || prior.fingerprint !== fingerprint) {
            fail('E_OPERATION_REUSED', 'This operation id already belongs to a different mutation.');
          }
          return { ...JSON.parse(prior.result_json), replayed: true };
        }
        const result = { ...this.mutate(method, args), operationId, replayed: false };
        this.execute('INSERT INTO operations(id,method,fingerprint,result_json,committed_at) VALUES(?,?,?,?,?)',
          [operationId, method, fingerprint, json(result, 'Operation result', 4 * FILE_LIMIT), now()]);
        return result;
      });
    }
    switch (method) {
      case 'status':
        return {
          format: 'esos-workspace/1', volumeId: this.volumeId, engine: 'sqlite-wasm/opfs-sahpool',
          sqliteVersion: this.db.selectValue('SELECT sqlite_version()'),
          files: Number(this.db.selectValue("SELECT count(*) FROM nodes WHERE kind='file'")),
          events: Number(this.db.selectValue('SELECT count(*) FROM events')),
          lastSequence: Number(this.db.selectValue('SELECT coalesce(max(sequence),0) FROM events')),
          fileByteLimit: FILE_LIMIT, mode: 'single-tab'
        };
      case 'list': {
        const path = pathValue(args.path);
        const directory = this.resolve(path);
        if (directory.kind !== 'directory') fail('E_NOT_DIRECTORY', 'The requested path is not a directory.');
        return this.all('SELECT * FROM nodes WHERE parent_id=? ORDER BY kind,name COLLATE BINARY', [directory.id])
          .map(row => this.metadata(row, path === '/' ? '/' + row.name : path + '/' + row.name));
      }
      case 'read': {
        const path = pathValue(args.path);
        const node = this.resolve(path);
        if (node.kind !== 'file') fail('E_IS_DIRECTORY', 'The requested path is a directory.');
        return { ...this.metadata(node, path), text: node.content };
      }
      case 'find': {
        const query = textValue(args.query, 'Search query', 512).trim();
        if (!query || query.length > 128 || /[\u0000-\u001f\u007f]/.test(query)) {
          fail('E_ARGUMENT', 'A search query contains 1–128 characters without control characters.');
        }
        const limit = integer(args.limit ?? 30, 'Search limit', 1);
        if (limit > 100) fail('E_LIMIT', 'At most 100 filesystem search results may be returned.');
        // Search metadata only. Bound parameters keep %, _, quotes, and SQL text literal.
        // SQLite lower() folds ASCII; names remain byte-for-byte unchanged.
        const rows = this.all(`
          WITH RECURSIVE paths(id,path,depth) AS (
            SELECT id,'/',0 FROM nodes WHERE id=?
            UNION ALL
            SELECT n.id,CASE WHEN p.path='/' THEN '/'||n.name ELSE p.path||'/'||n.name END,p.depth+1
              FROM nodes n JOIN paths p ON n.parent_id=p.id WHERE p.depth<64
          )
          SELECT n.id,n.name,n.kind,n.revision,n.updated_at,n.owner_app,p.path,
                 CASE WHEN n.kind='file' THEN length(CAST(n.content AS BLOB)) ELSE 0 END AS bytes
            FROM paths p JOIN nodes n ON n.id=p.id
           WHERE n.id<>? AND instr(lower(p.path),lower(?))>0
           ORDER BY CASE WHEN lower(n.name)=lower(?) THEN 0
                         WHEN instr(lower(n.name),lower(?))=1 THEN 1 ELSE 2 END,
                    p.path COLLATE NOCASE,p.path
           LIMIT ?
        `, [ROOT_ID, ROOT_ID, query, query, query, limit + 1]);
        return { query, truncated: rows.length > limit, entries: rows.slice(0, limit).map(row => ({
          id: row.id, path: row.path, name: row.name, kind: row.kind,
          revision: Number(row.revision), updatedAt: row.updated_at,
          bytes: Number(row.bytes), managedBy: row.owner_app || null
        })) };
      }
      case 'getState': return this.currentState(args.app);
      case 'events': {
        const after = integer(args.after ?? 0, 'After sequence');
        const limit = integer(args.limit ?? 100, 'Event limit', 1);
        if (limit > 1000) fail('E_LIMIT', 'At most 1000 events may be read at a time.');
        const rows = args.app === undefined
          ? this.all('SELECT * FROM events WHERE sequence>? ORDER BY sequence LIMIT ?', [after, limit])
          : this.all('SELECT * FROM events WHERE app=? AND sequence>? ORDER BY sequence LIMIT ?',
            [identifier(args.app, 'Application id'), after, limit]);
        return rows.map(row => this.eventRecord(row));
      }
      case 'operation': return this.operation(args.operationId);
      case 'export': return this.exportVolume();
      default: fail('E_METHOD', 'Unknown storage operation: ' + String(method));
    }
  }

  mutate(method, args) {
    const operationId = args.operationId;
    switch (method) {
      case 'mkdir': {
        const result = this.createDirectory(pathValue(args.path));
        if (!result.existed) this.appendEvent('vfs', result.revision,
          { type: 'directory.created', data: { path: result.path, objectId: result.id } }, operationId, now());
        return result;
      }
      case 'write': {
        const result = this.writeFile(args);
        this.appendEvent('vfs', result.revision, { type: 'file.written',
          data: { path: result.path, objectId: result.id, bytes: result.bytes } }, operationId, now());
        return result;
      }
      case 'remove': {
        const path = pathValue(args.path);
        if (path === '/') fail('E_ROOT', 'The volume root cannot be removed.');
        const node = this.resolve(path);
        if (node.owner_app) fail('E_MANAGED_FILE', 'Use the owning application to change this projection.');
        if (node.kind === 'directory' &&
            Number(this.db.selectValue('SELECT count(*) FROM nodes WHERE parent_id=?', [node.id]))) {
          fail('E_NOT_EMPTY', 'Only empty directories can be removed.');
        }
        expectedRevision(args.expectedRevision);
        if (args.expectedRevision !== undefined && args.expectedRevision !== Number(node.revision)) {
          fail('E_CONFLICT', 'The object changed before removal.');
        }
        this.execute('DELETE FROM nodes WHERE id=?', [node.id]);
        this.appendEvent('vfs', Number(node.revision), { type: 'object.removed',
          data: { path, objectId: node.id, kind: node.kind } }, operationId, now());
        return { path, id: node.id, removed: true };
      }
      case 'rename': {
        const from = pathValue(args.from), to = pathValue(args.to);
        if (from === '/') fail('E_ROOT', 'The volume root cannot be renamed.');
        const node = this.resolve(from);
        const destination = this.parent(to);
        if (node.owner_app) fail('E_MANAGED_FILE', 'Use the owning application to change this projection.');
        if (node.kind === 'directory') {
          const managedDescendant = this.db.selectValue(`
            WITH RECURSIVE descendants(id,owner_app) AS (
              SELECT id,owner_app FROM nodes WHERE id=?
              UNION ALL SELECT n.id,n.owner_app FROM nodes n JOIN descendants d ON n.parent_id=d.id
            ) SELECT count(*) FROM descendants WHERE owner_app IS NOT NULL
          `, [node.id]);
          if (Number(managedDescendant)) fail('E_MANAGED_FILE', 'This directory contains a managed application projection.');
          const descendants = this.all(`
            WITH RECURSIVE subtree(id,suffix) AS (
              SELECT id,'' FROM nodes WHERE id=?
              UNION ALL SELECT n.id,s.suffix||'/'||n.name FROM nodes n JOIN subtree s ON n.parent_id=s.id
            ) SELECT suffix FROM subtree
          `, [node.id]);
          for (const child of descendants) pathValue(to + child.suffix);
        }
        if (from === to) return { ...this.metadata(node, from), from, renamed: false };
        if (this.one('SELECT id FROM nodes WHERE parent_id=? AND name=?', [destination.parent.id, destination.name])) {
          fail('E_EXISTS', 'The destination already exists. Move or remove it explicitly first.');
        }
        let ancestor = destination.parent;
        while (ancestor) {
          if (ancestor.id === node.id) fail('E_PATH', 'A directory cannot be moved into itself.');
          ancestor = ancestor.parent_id ? this.one('SELECT * FROM nodes WHERE id=?', [ancestor.parent_id]) : null;
        }
        expectedRevision(args.expectedRevision);
        if (args.expectedRevision !== undefined && args.expectedRevision !== Number(node.revision)) {
          fail('E_CONFLICT', 'The object changed before rename.');
        }
        node.parent_id = destination.parent.id; node.name = destination.name;
        node.revision = revisionAfter(Number(node.revision)); node.updated_at = now();
        this.execute('UPDATE nodes SET parent_id=?,name=?,revision=?,updated_at=? WHERE id=?',
          [node.parent_id, node.name, node.revision, node.updated_at, node.id]);
        this.appendEvent('vfs', node.revision,
          { type: 'object.renamed', data: { from, to, objectId: node.id } }, operationId, node.updated_at);
        return { ...this.metadata(node, to), from, renamed: true };
      }
      case 'commit': {
        const app = identifier(args.app, 'Application id');
        const stateJson = json(args.state, 'Application state');
        const expected = integer(args.expectedRevision, 'Expected state revision');
        const current = this.currentState(app);
        if (current.revision !== expected) {
          fail('E_CONFLICT', 'Application state changed before this intent could be committed.',
            { expectedRevision: expected, actualRevision: current.revision });
        }
        if (!Array.isArray(args.events) || args.events.length < 1 || args.events.length > 32) {
          fail('E_ARGUMENT', 'An application commit requires between 1 and 32 domain events.');
        }
        const writes = args.writes ?? [];
        if (!Array.isArray(writes) || writes.length > 16) fail('E_LIMIT', 'At most 16 file projections may be committed together.');
        const paths = writes.map(write => pathValue(write.path));
        if (new Set(paths).size !== paths.length) fail('E_ARGUMENT', 'A commit cannot write the same path twice.');
        const revision = revisionAfter(current.revision), acceptedAt = now();
        const fileResults = writes.map(write => this.writeFile(write, app));
        this.execute(`
          INSERT INTO states(app,state_json,revision,updated_at) VALUES(?,?,?,?)
          ON CONFLICT(app) DO UPDATE SET state_json=excluded.state_json,revision=excluded.revision,updated_at=excluded.updated_at
        `, [app, stateJson, revision, acceptedAt]);
        const events = args.events.map(event => this.appendEvent(app, revision, event, operationId, acceptedAt));
        return { app, revision, events, writes: fileResults, acceptedAt };
      }
      default: fail('E_METHOD', 'Unsupported mutation.');
    }
  }

  exportVolume() {
    const size = Number(this.db.selectValue(`
      SELECT coalesce((SELECT sum(length(CAST(json_quote(content) AS BLOB))+9000) FROM nodes),0)
           + coalesce((SELECT sum(length(CAST(state_json AS BLOB))+512) FROM states),0)
           + coalesce((SELECT sum(length(CAST(data_json AS BLOB))+768) FROM events),0)
    `));
    if (size > EXPORT_LIMIT) fail('E_LIMIT', 'The simple workspace export is limited to 64 MiB. Existing data was preserved.');
    const nodes = this.all('SELECT * FROM nodes'), byId = new Map(nodes.map(node => [node.id, node]));
    const pathCache = new Map([[ROOT_ID, '/']]);
    const pathOf = (node, depth = 0) => {
      if (pathCache.has(node.id)) return pathCache.get(node.id);
      if (depth > 64 || !byId.has(node.parent_id)) fail('E_CORRUPT', 'The directory graph cannot be exported.');
      const parent = pathOf(byId.get(node.parent_id), depth + 1);
      const path = parent === '/' ? '/' + node.name : parent + '/' + node.name;
      pathCache.set(node.id, path);
      return path;
    };
    const files = nodes.filter(node => node.id !== ROOT_ID).map(node => ({
      ...this.metadata(node, pathOf(node)), ...(node.kind === 'file' ? { text: node.content } : {})
    })).sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
    const states = this.all('SELECT * FROM states ORDER BY app').map(row => ({
      app: row.app, state: JSON.parse(row.state_json), revision: Number(row.revision), updatedAt: row.updated_at
    }));
    const events = this.all('SELECT * FROM events ORDER BY sequence').map(row => this.eventRecord(row));
    return { format: 'esos-workspace/1', volumeId: this.volumeId, exportedAt: now(), files, states, events };
  }
}
