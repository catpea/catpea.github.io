import { Volume, StorageError } from './volume.mjs';

const LOCK_NAME = 'esos-workspace:volume:main:v1';
let sqlite, pool, db, volume, releaseOwner, lockTask;
let closing = false;
let queue = Promise.resolve();

function status(state, message) { self.postMessage({ type: 'status', state, message }); }

function errorRecord(error, operationId) {
  let code = error?.code || 'E_STORAGE';
  if (/quota|disk.*full|database or disk is full/i.test(error?.message || '')) code = 'E_QUOTA';
  return { name: 'StorageError', code,
    message: typeof error?.message === 'string' ? error.message.slice(0, 1200) : 'The local storage operation failed.',
    ...(error?.details === undefined ? {} : { details: error.details }),
    ...(operationId ? { operationId } : {}) };
}

async function acquireOwner() {
  if (!navigator.locks?.request) throw new StorageError('E_UNSUPPORTED', 'This browser does not expose Web Locks in a worker.');
  let accept, refuse;
  const decision = new Promise((resolve, reject) => { accept = resolve; refuse = reject; });
  lockTask = navigator.locks.request(LOCK_NAME, { mode: 'exclusive', ifAvailable: true }, async lock => {
    if (!lock) {
      refuse(new StorageError('E_BUSY', 'This workspace is already open in another tab. Close that tab, then retry here.'));
      return;
    }
    const lifetime = new Promise(resolve => { releaseOwner = resolve; });
    accept();
    await lifetime;
  });
  lockTask.catch(refuse);
  await decision;
}

async function openVolume() {
  if (volume) return volume.call('status');
  if (closing) throw new StorageError('E_CLOSED', 'The storage worker is closing.');
  if (!self.isSecureContext) throw new StorageError('E_UNSUPPORTED', 'Local storage requires HTTPS or localhost.');
  if (!navigator.storage?.getDirectory || !self.FileSystemFileHandle?.prototype?.createSyncAccessHandle) {
    throw new StorageError('E_UNSUPPORTED', 'This browser does not provide the required OPFS synchronous access handles.');
  }
  status('opening', 'Opening the local volume');
  await acquireOwner();
  try {
    // This volume uses SAH-pool only. Avoid initializing unused proxy VFSes.
    globalThis.sqlite3ApiConfig = { disable: { vfs: { opfs: true, 'opfs-wl': true } } };
    const { default: initSqlite } = await import('../../vendor/sqlite/sqlite3.mjs');
    sqlite = await initSqlite({
      print: () => {},
      printErr: (...values) => console.warn('[SQLite]', ...values)
    });
    pool = await sqlite.installOpfsSAHPoolVfs({
      name: 'esos-workspace',
      directory: '.esos-workspace-v1',
      initialCapacity: 6,
      verbosity: 0,
      preserveOnInitFailure: true,
      clearOnInit: false
    });
    db = new pool.OpfsSAHPoolDb('/workspace.sqlite3');
    volume = new Volume(db);
    const result = await volume.call('status');
    result.persistent = navigator.storage.persisted ? await navigator.storage.persisted() : null;
    status('ready', 'Local volume ready');
    return result;
  } catch (error) {
    await closeVolume();
    throw error;
  }
}

async function closeVolume() {
  const errors = [];
  closing = true;
  volume = undefined;
  try { db?.close(); } catch (error) { errors.push(errorRecord(error)); }
  db = undefined;
  try { pool?.pauseVfs(); } catch (error) { errors.push(errorRecord(error)); }
  pool = undefined;
  releaseOwner?.();
  releaseOwner = undefined;
  try { await lockTask; } catch (error) { errors.push(errorRecord(error)); }
  return { closed: true, errors };
}

self.onmessage = ({ data }) => {
  if (!data || !Number.isSafeInteger(data.id) || typeof data.method !== 'string') return;
  queue = queue.then(async () => {
    try {
      let result;
      if (data.method === 'init') result = await openVolume();
      else if (data.method === 'close') result = await closeVolume();
      else {
        if (!volume || closing) throw new StorageError('E_CLOSED', 'The local volume is not open.');
        result = await volume.call(data.method, data.args);
      }
      self.postMessage({ id: data.id, ok: true, result });
      if (result?.operationId && !result.replayed && data.method !== 'operation') {
        self.postMessage({ type: 'change', change: {
          method: data.method, operationId: result.operationId, app: result.app || 'vfs',
          revision: result.revision ?? null, path: result.path ?? null,
          lastSequence: result.events?.at(-1)?.sequence ?? null
        } });
      }
    } catch (error) {
      self.postMessage({ id: data.id, ok: false, error: errorRecord(error, data.args?.operationId) });
    }
  }).catch(error => {
    // Keep the queue alive if structured-cloning a reply unexpectedly fails.
    self.postMessage({ type: 'status', state: 'error', message: errorRecord(error).message });
  });
};
