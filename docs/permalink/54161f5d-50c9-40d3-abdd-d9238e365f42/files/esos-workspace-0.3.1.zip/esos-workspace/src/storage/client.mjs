const mutations = new Set(['mkdir', 'write', 'remove', 'rename', 'commit']);
const methods = new Set(['status', 'list', 'find', 'read', 'mkdir', 'write', 'remove', 'rename',
  'getState', 'commit', 'events', 'operation', 'export']);

function storageError(value) {
  const error = new Error(value.message || 'The storage operation failed.');
  error.name = 'StorageError';
  error.code = value.code || 'E_STORAGE';
  if (value.details !== undefined) error.details = value.details;
  if (value.operationId) error.operationId = value.operationId;
  return error;
}

/** A client for one private dedicated storage worker. No database handles escape. */
export async function createStorage({ onStatus = () => {} } = {}) {
  const worker = new Worker(new URL('./worker.mjs', import.meta.url), { type: 'module', name: 'esos-storage' });
  const pending = new Map(), listeners = new Set();
  let sequence = 0, closed = false, closing = false, closeTask;

  const notify = (callback, value) => {
    try { callback(value); } catch (error) { console.error('Storage observer failed:', error); }
  };
  const failPending = (code, message) => {
    for (const item of pending.values()) {
      item.reject(storageError({ code, message,
        ...(item.operationId ? { operationId: item.operationId } : {}) }));
    }
    pending.clear();
  };
  worker.onmessage = ({ data }) => {
    if (data?.type === 'status') {
      notify(onStatus, { state: data.state, message: data.message });
      return;
    }
    if (data?.type === 'change') {
      for (const listener of listeners) notify(listener, data.change);
      return;
    }
    const entry = pending.get(data?.id);
    if (!entry) return;
    pending.delete(data.id);
    if (data.ok) entry.resolve(data.result);
    else entry.reject(storageError(data.error || {}));
  };
  worker.onerror = event => {
    event.preventDefault();
    closed = true;
    failPending('E_WORKER_LOST', 'The storage worker stopped. A pending mutation may have committed; use its operation id after reopening.');
    notify(onStatus, { state: 'error', message: 'The storage worker stopped. Reload to reopen the preserved volume.' });
    worker.terminate();
  };
  worker.onmessageerror = () => {
    closed = true;
    failPending('E_WORKER_LOST', 'A storage reply could not be decoded. Reopen and query a pending mutation by operation id.');
    worker.terminate();
  };

  function request(method, args = {}) {
    return new Promise((resolve, reject) => {
      const id = ++sequence;
      const operationId = mutations.has(method) ? args.operationId : undefined;
      pending.set(id, { resolve, reject, operationId });
      try { worker.postMessage({ id, method, args }); }
      catch (error) { pending.delete(id); reject(error); }
    });
  }

  let initialStatus;
  try { initialStatus = await request('init'); }
  catch (error) {
    closed = true;
    worker.terminate();
    failPending('E_CLOSED', 'The volume could not be opened.');
    throw error;
  }

  return Object.freeze({
    initialStatus,
    call(method, args = {}) {
      if (closed || closing) return Promise.reject(storageError({ code: 'E_CLOSED', message: 'The storage client is closed.' }));
      if (!methods.has(method)) return Promise.reject(storageError({ code: 'E_METHOD', message: 'Unknown storage operation.' }));
      if (!args || typeof args !== 'object' || Array.isArray(args)) {
        return Promise.reject(storageError({ code: 'E_ARGUMENT', message: 'Storage arguments must be an object.' }));
      }
      if (pending.size >= 64) return Promise.reject(storageError({ code: 'E_BUSY', message: 'The storage request queue is full; await outstanding work.' }));
      const payload = { ...args };
      if (mutations.has(method)) payload.operationId ??= crypto.randomUUID();
      return request(method, payload);
    },
    onChange(listener) {
      if (typeof listener !== 'function') throw new TypeError('A storage listener must be a function.');
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    close() {
      if (closeTask) return closeTask;
      if (closed) return Promise.resolve({ closed: true, errors: [] });
      closing = true;
      closeTask = request('close').catch(error => ({ closed: true, errors: [{ code: error.code, message: error.message }] }))
        .finally(() => {
          closed = true; closing = false;
          worker.terminate();
          failPending('E_CLOSED', 'The storage client was closed.');
          listeners.clear();
        });
      return closeTask;
    }
  });
}
