import { runCommand } from '../protocol/run.mjs';
import { decodeNdjson } from '../protocol/ndjson.mjs';
import { parseLine } from './parser.mjs';

const emptyInput = () => new ReadableStream({ start(controller) { controller.close(); } });
const pipe = () => new TransformStream(undefined,
  new ByteLengthQueuingStrategy({ highWaterMark: 65536 }),
  new ByteLengthQueuingStrategy({ highWaterMark: 65536 }));

export async function executeLine(line, commands, { signal, onRecord, onDiagnostic } = {}) {
  const stages = parseLine(line);
  if (!stages.length) return { status: 'ok', exitCode: 0 };
  if (stages.length > 12) throw new Error('A pipeline may contain at most 12 commands.');
  const selected = stages.map(([name]) => {
    const command = commands.get(name);
    if (!command) throw new Error('Unknown command: ' + name + '. Use help to list commands.');
    return command;
  });
  const streams = Array.from({ length: stages.length }, pipe);
  const cancellation = new AbortController();
  const abort = () => cancellation.abort(signal.reason);
  signal?.addEventListener('abort', abort, { once: true });
  if (signal?.aborted) abort();
  let firstFailure;
  const finalOutput = streams.at(-1).readable;
  const consume = (async () => {
    try {
      for await (const record of decodeNdjson(finalOutput)) await onRecord?.(record);
    } catch (error) {
      if (!cancellation.signal.aborted) throw error;
    }
  })();
  consume.catch(error => cancellation.abort(error));
  const runs = selected.map((command, index) => {
    const diagnostics = new WritableStream({
      async write(bytes) {
        const record = JSON.parse(new TextDecoder().decode(bytes));
        await onDiagnostic?.({ command: stages[index][0], ...record });
      }
    });
    return runCommand(command, {
      stdin: index ? streams[index - 1].readable : emptyInput(),
      stdout: streams[index].writable, stderr: diagnostics,
      args: stages[index].slice(1), signal: cancellation.signal
    }).then(result => {
      if (result.exitCode && result.status !== 'cancelled' && !firstFailure) {
        firstFailure = result;
        cancellation.abort(new Error('Pipeline stage failed'));
      }
      return result;
    });
  });
  try {
    const results = await Promise.all(runs);
    await consume;
    return firstFailure ?? (signal?.aborted
      ? { status: 'cancelled', exitCode: 130 }
      : results.find(result => result.exitCode) ?? { status: 'ok', exitCode: 0 });
  } finally {
    signal?.removeEventListener('abort', abort);
  }
}
