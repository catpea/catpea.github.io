export class ShellSyntaxError extends Error {
  constructor(message, position) {
    super(message);
    this.name = 'ShellSyntaxError';
    this.code = 'E_SHELL_SYNTAX';
    this.position = position;
  }
}

/**
 * A small, literal command language: words, quotes, escapes, and pipes.
 * There is no expansion, substitution, globbing, redirection, or JavaScript.
 * Returns one token array per pipeline stage; token 0 is its command name.
 */
export function parseLine(source) {
  if (typeof source !== 'string') throw new TypeError('A command line must be text.');
  if (source.length > 65536) throw new ShellSyntaxError('The command line is too long.', 65536);
  const stages = [];
  let words = [];
  let word = '';
  let started = false;
  let quote = null;
  let escaped = false;

  function finishWord() {
    if (!started) return;
    words.push(word);
    if (words.length > 128) throw new ShellSyntaxError('Too many arguments in one command.', source.length);
    word = '';
    started = false;
  }

  function finishStage(position) {
    finishWord();
    if (!words.length) throw new ShellSyntaxError('A pipe needs a command on each side.', position);
    stages.push(words);
    if (stages.length > 12) throw new ShellSyntaxError('A pipeline can contain at most 12 commands.', position);
    words = [];
  }

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];
    if (char === '\0' || char === '\r' || char === '\n') {
      throw new ShellSyntaxError('Use one command line at a time.', i);
    }
    if (escaped) {
      word += char;
      started = true;
      escaped = false;
    } else if (quote === "'") {
      if (char === "'") quote = null;
      else word += char;
    } else if (quote === '"') {
      if (char === '"') quote = null;
      else if (char === '\\') {
        const next = source[i + 1];
        if (next === '"' || next === '\\') escaped = true;
        else word += char;
      } else word += char;
    } else if (char === '\\') {
      escaped = true;
      started = true;
    } else if (char === "'" || char === '"') {
      quote = char;
      started = true;
    } else if (char === '|') {
      finishStage(i);
    } else if (/\s/u.test(char)) {
      finishWord();
    } else if (char === '>' || char === '<' || char === ';' || char === '&') {
      throw new ShellSyntaxError('This shell supports literal arguments and | pipelines; quote that character as data.', i);
    } else {
      word += char;
      started = true;
    }
  }
  if (quote) throw new ShellSyntaxError('Close the ' + quote + ' quote.', source.length);
  if (escaped) throw new ShellSyntaxError('An escape needs a following character.', source.length);
  finishWord();
  if (words.length) {
    stages.push(words);
    if (stages.length > 12) throw new ShellSyntaxError('A pipeline can contain at most 12 commands.', source.length);
  } else if (stages.length) {
    throw new ShellSyntaxError('A pipe needs a command after it.', source.length);
  }
  return stages;
}
