import { createStorage } from './storage/client.mjs';
import { createTaskService } from './services/tasks.mjs';
import { createCommands } from './commands/index.mjs';
import { parseLine } from './shell/parser.mjs';
import { createApplications } from './ui/apps.mjs';
import { decodeNdjson } from './protocol/ndjson.mjs';
import { createWindowManager } from './desktop/windows.mjs';
import { createLauncher } from './desktop/launcher.mjs';
import { createClipboard } from './services/clipboard.mjs';
import { createSearch } from './services/search.mjs';
import { createDesktopSession } from './services/desktop-session.mjs';
import { createCommandService } from './services/commands.mjs';
import { createStateService } from './services/state.mjs';
import { createSync } from './services/sync.mjs';
import { createSoftware } from './software/service.mjs';
import { createProjectDocuments } from './projects/documents.mjs';
import { createProjectAdapter } from './projects/adapter.mjs';
import { offline } from './offline.mjs';

const $ = id => document.getElementById(id);
const output = $('terminal-output');
const input = $('terminal-input');
const form = $('terminal-form');
const notice = $('desktop-notice');
const desktopMenu = $('desktop-menu');
let storage, os, commands, applications, profile, desktopSession, launcher, windows, dockObserver, software, job = null;
const optionalCommandNames = new Set();
let restoringDesktop = true;
let deferredWindows = [];
let setup = false;
const observers = new Set(), devices = new Map(), commandHistory = [];
let historyPosition = 0;
const applicationCatalog = Object.freeze([
  { id: 'terminal', name: 'terminal', title: 'Terminal', description: 'Small commands, composable data, and local services.' },
  { id: 'tasks', name: 'tasks', title: 'Tasks', description: 'Shared tasks with a durable history and undo.' },
  { id: 'files', name: 'files', title: 'Files', description: 'Browse, edit, and copy local text documents.' },
  { id: 'journal', name: 'journal', title: 'Journal', description: 'Inspect committed events in a native table.' },
  { id: 'system', name: 'system', title: 'System', description: 'Desktop capabilities, installed groups, and export.' },
  { id: 'software', name: 'software', title: 'Software', description: 'Install applications and publish, import, and share programs.' },
  { id: 'sync', name: 'sync', title: 'Sync', description: 'Compare and synchronize files with an optional Linux folder.' }
]);
const availableApplications = () => [...applicationCatalog, ...(software?.applications() ?? [])];
const knownApplications = () => [...availableApplications(), { id: 'project', title: 'Run project' }];
function refreshOptionalCommands() {
  if (!commands || !software || !os) return;
  for (const name of optionalCommandNames) commands.delete(name);
  optionalCommandNames.clear();
  for (const descriptor of software.commands()) {
    if (commands.has(descriptor.name)) throw new Error('A package conflicts with command ' + descriptor.name);
    commands.set(descriptor.name, Object.freeze({ ...descriptor,
      run: ctx => software.invokeCommand(descriptor.name, { ...ctx, os }) }));
    optionalCommandNames.add(descriptor.name);
  }
}
function renderApplicationMenu() {
  const menu = document.querySelector('.launcher');
  menu.replaceChildren();
  for (const app of availableApplications().filter(item => item.id !== 'terminal')) {
    const button = document.createElement('button');
    button.className = 'btn-text'; button.dataset.app = app.id; button.disabled = !os;
    button.textContent = app.title; button.title = app.description ?? app.title;
    menu.append(button);
  }
}

function line(value, kind = '') {
  const element = document.createElement('p');
  element.className = 'terminal-line ' + kind;
  element.textContent = value;
  const nearBottom = output.scrollHeight - output.scrollTop - output.clientHeight < 100;
  output.append(element);
  while (output.childElementCount > 300) output.firstElementChild.remove();
  if (nearBottom || kind === 'command') output.scrollTop = output.scrollHeight;
}
function showError(error) {
  const message = (error?.code ? error.code + ' · ' : '') + (error?.message ?? String(error));
  $('desktop-notice-message').textContent = message; notice.hidden = false;
}
function closeDesktopMenu(restoreFocus = false) {
  const wasOpen = desktopMenu.open;
  desktopMenu.open = false;
  if (wasOpen && restoreFocus) desktopMenu.querySelector('summary').focus();
}
function setReady(ready, status) {
  input.disabled = !ready;
  $('terminal-run').disabled = !ready;
  $('command-status').textContent = status;
  if (ready && windows.activeId === 'terminal') input.focus();
}
function desktopSnapshot() {
  const apps = new Map((applications?.session() ?? []).map(item => [item.id, item]));
  const entries = windows.list().filter(item => item.app === 'terminal' || apps.has(item.id)).map(item => ({
    id: item.id, app: item.app, options: apps.get(item.id)?.options ?? {},
    bounds: item.bounds, restoreBounds: item.restoreBounds ?? item.bounds,
    mode: item.mode, minimized: item.minimized, chrome: item.chrome
  }));
  // A temporarily unavailable package must not erase a saved document window.
  const registered = new Set(knownApplications().map(item => item.id));
  deferredWindows = deferredWindows.filter(saved => registered.has(saved.app) && !entries.some(live =>
    live.id === saved.id || live.app === saved.app && (live.options?.path ?? null) === (saved.options?.path ?? null)));
  entries.push(...deferredWindows.slice(0, Math.max(0, 12 - entries.length)));
  return { schema: 1, activeId: entries.some(item => item.id === windows.activeId) ? windows.activeId : null, windows: entries };
}
function desktopChanged(snapshot) {
  const count = snapshot.windows.length;
  $('window-count').textContent = count + (count === 1 ? ' window' : ' windows');
  if (!restoringDesktop && desktopSession && applications) desktopSession.schedule(desktopSnapshot());
}
async function restoreDesktop() {
  const saved = await desktopSession.read();
  const terminal = saved?.windows?.find(item => item.app === 'terminal');
  if (terminal) {
    windows.setBounds('terminal', terminal.restoreBounds ?? terminal.bounds);
    if (terminal.mode === 'maximized') windows.maximize('terminal');
    else if (terminal.mode === 'left' || terminal.mode === 'right') windows.snap('terminal', terminal.mode);
    windows.setChrome('terminal', terminal.chrome !== false);
  }
  for (const item of saved?.windows ?? []) {
    if (item.app === 'terminal') continue;
    try {
      await applications.open(item.app, { ...item.options, id: item.id, newWindow: true,
        bounds: item.bounds, restoreBounds: item.restoreBounds, mode: item.mode, minimized: item.minimized, chrome: item.chrome });
    } catch (error) {
      if (knownApplications().some(app => app.id === item.app)) deferredWindows.push(item);
      line('Could not reopen ' + item.app + ': ' + error.message, 'error');
    }
  }
  if (terminal?.minimized) windows.minimize('terminal');
  for (const item of saved?.windows ?? []) {
    if (!item.minimized && windows.get(item.id)) windows.focus(item.id);
  }
  if (saved?.activeId && windows.get(saved.activeId)) windows.focus(saved.activeId);
  else if (!saved) windows.focus('terminal');
  restoringDesktop = false;
  desktopSession.schedule(desktopSnapshot());
}
function publish(change) {
  for (const callback of observers) {
    try { callback(change); } catch (error) { console.error('Workspace observer failed', error); }
  }
}
function recordFile(path, value) {
  return { path, name: path.split('/').at(-1), kind: 'file', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', revision: 0, virtual: true };
}
function pathOf(value = '.') {
  if (typeof value !== 'string') throw new TypeError('A path must be a string.');
  let path = value === '~' ? '/home/' + profile.username
    : value.startsWith('~/') ? '/home/' + profile.username + value.slice(1)
    : value.startsWith('/') ? value : '/home/' + profile.username + '/' + value;
  const parts = [];
  for (const part of path.split('/')) {
    if (!part || part === '.') continue;
    if (part === '..') { if (!parts.length) throw new Error('The path escapes the root.'); parts.pop(); }
    else parts.push(part);
  }
  return '/' + parts.join('/');
}
const reserved = path => ['/dev', '/proc', '/sys'].some(prefix => path === prefix || path.startsWith(prefix + '/'));
function assertUserPath(path) {
  if (reserved(path)) throw new Error('This is a system device or status path.');
}

async function loadGroups() {
  const response = await fetch(new URL('../groups/roadmap.xml', import.meta.url));
  if (!response.ok) throw new Error('Package group manifest is unavailable.');
  const document = new DOMParser().parseFromString(await response.text(), 'application/xml');
  if (document.querySelector('parsererror')) throw new Error('The package group manifest is invalid.');
  return [...document.querySelectorAll('group')].map(group => ({
    id: group.getAttribute('id'), title: group.getAttribute('title'),
    status: group.getAttribute('status'), version: group.getAttribute('version') ?? null,
    requires: (group.getAttribute('requires') ?? '').split(' ').filter(Boolean),
    provides: [...group.querySelectorAll('provides')].map(item => item.getAttribute('capability'))
  }));
}

function download(name, content) {
  const url = URL.createObjectURL(new Blob([content], { type: 'application/json' }));
  const anchor = document.createElement('a');
  anchor.href = url; anchor.download = name; anchor.hidden = true;
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

async function activateProfile(username) {
  profile = Object.freeze({ username });
  await storage.call('mkdir', { path: '/home/' + username });
  const groups = await loadGroups();
  const tasks = createTaskService(storage, { username, onChange: publish });
  await tasks.ready;
  const clipboard = createClipboard();
  const facade = {
    version: '0.3.1',
    profile,
    observe(callback) { observers.add(callback); return () => observers.delete(callback); },
    tasks,
    clipboard,
    state: createStateService({ storage, username }),
    desktop: {
      list: () => windows.list(),
      focus: id => windows.focus(id),
      close: id => windows.close(id),
      minimize: id => windows.minimize(id),
      restore: id => windows.restore(id),
      recover: id => windows.recover(id),
      maximize: id => windows.maximize(id),
      snap: (id, side) => windows.snap(id, side),
      chrome: (id, visible) => windows.setChrome(id, visible),
      arrange: mode => windows.arrange(mode)
    },
    async journal({ after, limit = 50, app } = {}) {
      const status = after === undefined ? await storage.call('status') : null;
      const start = after ?? Math.max(0, status.lastSequence - limit);
      return storage.call('events', { after: start, limit, ...(app ? { app } : {}) });
    },
    vfs: {
      async list(value = '~') {
        const path = pathOf(value);
        const entry = (name, kind = 'directory') => ({ name, path: path.replace(/\/$/, '') + '/' + name, kind, revision: 0, virtual: true });
        if (path === '/dev') return [entry('view'), entry('clipboard')];
        if (path === '/dev/clipboard') return [entry('text', 'device'), entry('workspace', 'device'), entry('status.json', 'file')];
        if (path === '/dev/view') return [entry('new', 'device'), ...[...devices.keys()].map(id => entry(id))];
        if (/^\/dev\/view\/[^/]+$/.test(path)) {
          const device = devices.get(path.split('/')[3]);
          if (!device) throw new Error('That view directory is unavailable.');
          return [entry('ctl', 'device'), ...(device.readable ? [entry('events', 'device')] : []), entry('status.json', 'file')];
        }
        if (path === '/sys') return [entry('capabilities.json', 'file'), entry('groups.json', 'file'), entry('software.json', 'file')];
        if (path === '/proc') return [entry('self')];
        if (path === '/proc/self') return [entry('status.json', 'file')];
        if (reserved(path)) throw new Error('This system path is not a directory.');
        const entries = await storage.call('list', { path });
        if (path === '/') entries.push(entry('dev'), entry('sys'), entry('proc'));
        return entries.sort((a, b) => a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'directory' ? -1 : 1);
      },
      async read(value) {
        const path = pathOf(value);
        if (path === '/sys/capabilities.json') return recordFile(path, {
          vfs: 'sqlite-opfs', dom: 'esos.view/1', desktop: 'esos.desktop/1', commandProtocol: 'object-ndjson/1',
          workers: typeof Worker === 'function', webgpu: !!navigator.gpu,
          serial: !!navigator.serial, clipboard: !!navigator.clipboard,
          serviceWorker: !!navigator.serviceWorker, projects: 'esos.project/1', software: 'esos.package/1', mode: 'trusted-code-and-declarative-programs'
        });
        if (path === '/sys/groups.json') return recordFile(path, facade.system.groups());
        if (path === '/sys/software.json') return recordFile(path, software?.list() ?? []);
        if (path === '/proc/self/status.json') return recordFile(path, {
          profile: username, job: job ? { id: job.id, command: job.command } : null,
          views: [...devices.values()].map(device => device.inspect()), windows: windows.list(), jobs: facade.commands?.jobs() ?? []
        });
        if (path === '/dev/clipboard/status.json') return recordFile(path, clipboard.status());
        if (path === '/dev/clipboard/text' || path === '/dev/clipboard/workspace') {
          const value = await clipboard.readText({ source: path.endsWith('/workspace') ? 'workspace' : 'system' });
          return { ...recordFile(path, value.text), source: value.source };
        }
        if (/^\/dev\/view\/[^/]+\/status\.json$/.test(path)) {
          const device = devices.get(path.split('/')[3]);
          if (!device) throw new Error('That view is closed.');
          return recordFile(path, device.inspect());
        }
        if (reserved(path)) throw new Error('This device is not an ordinary text file.');
        return storage.call('read', { path });
      },
      async write(value, text, options = {}) {
        const path = pathOf(value);
        if (path === '/dev/clipboard/text' || path === '/dev/clipboard/workspace') {
          const result = await clipboard.writeText(text, { source: path.endsWith('/workspace') ? 'workspace' : 'auto' });
          return { path, revision: 0, ...result };
        }
        if (/^\/dev\/view\/[^/]+\/ctl$/.test(path)) {
          const device = devices.get(path.split('/')[3]);
          if (!device) throw new Error('That view is closed.');
          const bytes = new TextEncoder().encode(text.endsWith('\n') ? text : text + '\n');
          const input = new ReadableStream({ start(controller) { controller.enqueue(bytes); controller.close(); } });
          let ack;
          for await (const record of decodeNdjson(input)) ack = await device.write(record);
          return { path, applied: ack ?? null };
        }
        assertUserPath(path);
        return storage.call('write', { ...options, path, text });
      },
      async mkdir(value) { const path = pathOf(value); assertUserPath(path); return storage.call('mkdir', { path }); },
      async remove(value, options = {}) { const path = pathOf(value); assertUserPath(path); return storage.call('remove', { ...options, path }); },
      async rename(from, to, options = {}) {
        from = pathOf(from); to = pathOf(to); assertUserPath(from); assertUserPath(to);
        return storage.call('rename', { ...options, from, to });
      },
      async open(value, options = {}) {
        const path = pathOf(value);
        if (path === '/dev/view/new') return facade.devices.open(path, options);
        if (/^\/dev\/view\/[^/]+(?:\/(?:ctl|events))?$/.test(path)) {
          const device = devices.get(path.split('/')[3]);
          if (!device) throw new Error('That view is closed.');
          if (path.endsWith('/events') && !device.readable) throw new Error('This view uses a local action handler instead of an event stream.');
          return device;
        }
        const file = await facade.vfs.read(path);
        const bytes = new TextEncoder().encode(file.text);
        return { path, revision: file.revision, readable: new ReadableStream({
          start(controller) { controller.enqueue(bytes); controller.close(); }
        }), close() {} };
      },
      getOperationStatus(operationId) { return storage.call('operation', { operationId }); }
    },
    devices: {
      list() { return [...devices.values()].map(device => device.inspect()); },
      async open(path, options = {}) {
        if (path !== '/dev/view/new') throw new Error('The installed device factory is /dev/view/new.');
        return applications.openDevice(options.title ?? 'Document', { ...options, eventStream: options.eventStream !== false });
      }
    },
    views: { list: () => availableApplications(), open(name, options = {}) {
      if (name === 'terminal') { windows.focus('terminal'); return { application: 'terminal', window: 'terminal' }; }
      return applications.open(name, options);
    }, async openDocument(path, options = {}) {
      const file = await facade.vfs.read(path);
      let value;
      try { value = JSON.parse(file.text); } catch {}
      if (value?.format === 'esos.project') return applications.open('project', { ...options, path: file.path, newWindow: true });
      if (value?.format === 'esos.package') return applications.open('software', { ...options, path: file.path });
      return applications.open('files', { ...options, path: file.path, newWindow: true });
    } },
    system: {
      async status() {
        return {
          system: 'eSOS', version: '0.3.1', runtime: 'browser', profile,
          storage: await storage.call('status'), online: navigator.onLine,
          persistent: await navigator.storage.persisted(),
          desktop: { windows: windows.list().length, maximum: 12 }, clipboard: clipboard.status(),
          installedGroups: facade.system.groups().filter(group => group.status === 'installed').map(group => group.id),
          software: software?.status() ?? null, offline: offline.status()
        };
      },
      groups() {
        return structuredClone(groups).map(group => {
          const packageId = ({ automate: 'applications.automate', workbench: 'applications.workbench', cards: 'applications.cards' })[group.id];
          if (packageId) group.status = software?.installed().some(item => item.id === packageId && item.enabled) ? 'installed' : 'available';
          return group;
        });
      },
      async export() {
        const snapshot = await storage.call('export');
        const filename = 'esos-workspace-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
        download(filename, JSON.stringify(snapshot, null, 2) + '\n');
        return { exported: true, filename, files: snapshot.files.length, events: snapshot.events.length };
      }
    }
  };
  facade.projects = createProjectDocuments(facade);
  const projectAdapter = createProjectAdapter(facade);
  software = createSoftware({ storage, username,
    reservedApplications: knownApplications().map(app => app.id),
    onChange() { if (os) { refreshOptionalCommands(); renderApplicationMenu(); publish({ kind: 'software.changed' }); } },
    projectAdapter
  });
  await software.ready;
  facade.software = software;
  facade.sync = createSync({ os: facade, storage });
  commands = createCommands(facade);
  facade.commands = createCommandService({ getCommands: () => commands, onChange: publish });
  facade.search = createSearch({ storage, username, getApplications: availableApplications, getCommands: () => commands });
  desktopSession = createDesktopSession(storage, { username, onStatus(status) {
    $('layout-status').textContent = status.message ?? ({ saved: 'Layout saved locally', saving: 'Saving layout…', error: 'Layout could not be saved' })[status.state] ?? 'Local desktop';
    $('layout-status').dataset.state = status.state ?? '';
  } });
  await desktopSession.ready;
  for (const key of ['vfs', 'devices', 'views', 'system', 'desktop']) Object.freeze(facade[key]);
  os = Object.freeze(facade);
  applications = createApplications({
    os, windows, registry: devices, onError: showError,
    knownApplications,
    async resolveApplication(name) {
      if (name !== 'project') return software.loadApplication(name);
      return async (context, options) => {
        const loaded = options.project ? { project: options.project } : await facade.projects.load(options.path);
        return projectAdapter.build(loaded.project, context, { ...options, ...(loaded.path ? { path: loaded.path } : {}) });
      };
    },
    onSessionChange: () => desktopChanged({ windows: windows.list() })
  });
  Object.defineProperty(globalThis, 'esos', { value: Object.freeze({ v1: os }), configurable: false });
  commands.set('dom', Object.freeze({
    name: 'dom', summary: 'Display device batches from STDIN as an adopted document.', usage: 'dom [title]',
    async run(ctx) {
      const device = await os.devices.open('/dev/view/new', { title: ctx.args.join(' ') || 'Document', eventStream: false });
      let count = 0;
      for await (const record of ctx.stdin) { ctx.signal.throwIfAborted(); await device.write(record); count += 1; }
      await ctx.stdout.write({ device: device.path, batches: count, revision: device.revision });
    }
  }));
  commands.set('ndjson', Object.freeze({
    name: 'ndjson', summary: 'Read an NDJSON file as command records.', usage: 'ndjson PATH',
    async run(ctx) {
      if (ctx.args.length !== 1) throw new Error('Usage: ndjson PATH');
      const file = await os.vfs.read(ctx.args[0]);
      const bytes = new TextEncoder().encode(file.text);
      const source = new ReadableStream({ start(controller) { controller.enqueue(bytes); controller.close(); } });
      for await (const record of decodeNdjson(source)) await ctx.stdout.write(record);
    }
  }));
  refreshOptionalCommands(); renderApplicationMenu();
  launcher = createLauncher({ dialog: $('launcher-dialog'), search: os.search, onError: showError,
    async onActivate(result) {
      if (result.kind === 'application') await os.views.open(result.application ?? result.id);
      else if (result.kind === 'file') await os.views.openDocument(result.path, { newWindow: true });
      else if (result.kind === 'directory') await os.views.open('files', { directory: result.path, newWindow: true });
      else if (result.kind === 'command') {
        windows.focus('terminal');
        input.value = result.command ?? result.id; input.focus();
        $('command-status').textContent = 'Command prepared · press Enter to run';
      }
    }
  });
  await restoreDesktop();
  $('profile-label').textContent = username.toUpperCase() + ' · LOCAL';
  $('terminal-prompt').textContent = username + ' ›';
  $('terminal-help').disabled = false;
  for (const id of ['launcher-open', 'new-files', 'tile-windows', 'cascade-windows']) $(id).disabled = false;
  for (const button of document.querySelectorAll('.launcher button[data-app]')) button.disabled = false;
  setup = false;
  line('Welcome, ' + username + '.', 'welcome');
  line('Your local desktop is ready.\nUse help, open software, or Search (Ctrl K).', 'muted');
  line('Install Automate, Workbench, and Cards in Software to build and publish your own programs.', 'muted');
  setReady(true, 'Ready');
}

async function submit(command) {
  if (!command.trim() || job) return;
  if (setup) {
    const username = command.trim();
    if (!/^[a-z][a-z0-9_-]{0,31}$/.test(username)) {
      line('Use a lowercase name starting with a letter (up to 32 letters, numbers, - or _).', 'error'); return;
    }
    setReady(false, 'Creating profile…');
    let committed = false;
    try {
      await storage.call('commit', {
        app: 'system.profile', expectedRevision: 0, state: { username },
        events: [{ type: 'profile.created', data: { username } }], operationId: crypto.randomUUID()
      });
      committed = true;
      await activateProfile(username);
    } catch (error) {
      line(error.message, 'error');
      if (committed) {
        setup = false;
        line('Your profile was saved. Reload to finish opening the workspace.', 'muted');
        setReady(false, 'Profile saved · reload to continue');
      } else setReady(true, 'Profile not created');
    }
    return;
  }
  if (command.trim() === 'clear') { output.replaceChildren(); return; }
  commandHistory.push(command);
  if (commandHistory.length > 100) commandHistory.shift();
  historyPosition = commandHistory.length;
  line(profile.username + ' › ' + command, 'command');
  job = { id: crypto.randomUUID(), command, controller: new AbortController() };
  $('terminal-stop').hidden = false; $('terminal-run').hidden = true;
  setReady(false, 'Running');
  try {
    const stages = parseLine(command).map(([command, ...args]) => ({ command, args }));
    const result = await os.commands.pipeline(stages, {
      signal: job.controller.signal,
      onRecord: record => line(JSON.stringify(record), 'terminal-record'),
      onDiagnostic: record => line(JSON.stringify(record), 'error')
    });
    $('command-status').textContent = result.status === 'ok' ? 'Ready · exit 0' : result.status + ' · exit ' + result.exitCode;
  } catch (error) {
    line(error.message, 'error'); $('command-status').textContent = 'Error · exit 1';
  } finally {
    job = null; input.disabled = false; $('terminal-run').disabled = false;
    $('terminal-stop').hidden = true; $('terminal-run').hidden = false;
    if (windows.activeId === 'terminal') input.focus();
  }
}

form.addEventListener('submit', event => {
  event.preventDefault(); const command = input.value; input.value = ''; submit(command).catch(showError);
});
input.addEventListener('keydown', event => {
  if (setup || !commandHistory.length || event.isComposing) return;
  if (event.key === 'ArrowUp') { event.preventDefault(); historyPosition = Math.max(0, historyPosition - 1); input.value = commandHistory[historyPosition]; }
  if (event.key === 'ArrowDown') { event.preventDefault(); historyPosition = Math.min(commandHistory.length, historyPosition + 1); input.value = commandHistory[historyPosition] ?? ''; }
});
$('terminal-stop').addEventListener('click', () => job?.controller.abort(new DOMException('Stopped by user', 'AbortError')));
$('terminal-clear').addEventListener('click', () => output.replaceChildren());
$('terminal-help').addEventListener('click', () => submit('help').catch(showError));
document.querySelector('.launcher').addEventListener('click', event => {
  const button = event.target.closest('button[data-app]');
  if (button && !button.disabled) os.views.open(button.dataset.app).catch(showError);
});
$('show-terminal').addEventListener('click', () => { windows?.recover('terminal'); if (!input.disabled) input.focus(); });
$('launcher-open').addEventListener('click', () => launcher?.open());
$('new-files').addEventListener('click', () => applications.open('files', { newWindow: true }).catch(showError));
for (const [id, mode] of [['tile-windows', 'tile'], ['cascade-windows', 'cascade']]) {
  $(id).addEventListener('click', () => { try { windows.arrange(mode); } catch (error) { showError(error); } });
}
$('dismiss-notice').addEventListener('click', () => { notice.hidden = true; });
desktopMenu.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (button && !button.disabled) closeDesktopMenu();
}, { capture: true });
document.addEventListener('pointerdown', event => {
  if (desktopMenu.open && !desktopMenu.contains(event.target)) closeDesktopMenu();
});
document.addEventListener('keydown', event => {
  if (!desktopMenu.open || event.isComposing) return;
  if (event.key === 'Escape') {
    event.preventDefault(); event.stopPropagation(); closeDesktopMenu(true);
  } else if (event.ctrlKey && event.key.toLowerCase() === 'k') closeDesktopMenu();
}, { capture: true });
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && desktopSession) desktopSession.flush().catch(error => console.error('Layout flush:', error));
});
window.addEventListener('pagehide', event => {
  if (!event.persisted) {
    dockObserver?.disconnect();
    Promise.allSettled([desktopSession?.close(), software?.close()]).finally(() => storage?.close());
  }
});

offline.subscribe(status => {
  $('offline-status').textContent = (status.code ? status.code + ' · ' : '') + status.message;
});

async function boot() {
  line('eSOS Desktop 0.3.1', 'welcome');
  line('A local desktop, built from small commands.\nOpening the browser volume…', 'muted');
  if (!isSecureContext) throw new Error('Open this workspace on localhost or HTTPS so browser storage is available.');
  windows = createWindowManager({
    workspace: $('desktop-workspace'), taskbar: $('window-taskbar'),
    onChange: desktopChanged, onError: showError,
    getInsets() {
      const workspace = $('desktop-workspace').getBoundingClientRect();
      const dock = $('desktop-dock').getBoundingClientRect();
      return { bottom: Math.max(0, workspace.bottom - dock.top) + 8 };
    }
  });
  dockObserver = new ResizeObserver(() => windows.refreshLayout());
  dockObserver.observe($('desktop-dock'));
  windows.create({
    id: 'terminal', app: 'terminal', title: 'Terminal', content: $('terminal-pane'),
    closable: false, bounds: { x: 24, y: 24, width: 480,
      height: Math.min(560, Math.max(1, $('desktop-workspace').clientHeight - 112)) }
  });
  offline.start().catch(error => console.error('Offline startup:', error));
  storage = await createStorage({
    onStatus({ state, message }) {
      $('storage-status').textContent = state === 'ready' ? 'Local volume connected' : message;
    }
  });
  storage.onChange(publish);
  $('storage-status').textContent = 'Local volume connected';
  const saved = await storage.call('getState', { app: 'system.profile' });
  if (saved.state?.username) await activateProfile(saved.state.username);
  else {
    setup = true;
    line('Choose a name for this local workspace.\nEnter a username, for example: alice', 'welcome');
    line('This profile belongs to this browser. No online account is needed.', 'muted');
    $('terminal-prompt').textContent = 'username ›';
    setReady(true, 'Choose a local profile');
  }
}
boot().catch(error => {
  line((error.code ? error.code + ': ' : '') + error.message, 'error');
  $('storage-status').textContent = 'Local volume not opened';
  $('command-status').textContent = 'Reload to retry';
  showError(error.code === 'E_BUSY' ? 'This workspace is already open in another tab. Close that tab, then reload here.' : error);
});
