import { fail, sha256, canonical } from './schema.mjs';
import { MARKER, packageCache, packageURL } from './paths.mjs';
import { offline } from '../offline.mjs';

async function bytesFrom(response, expected) {
  if (!response.ok) fail('E_PACKAGE_FETCH', 'A package asset could not be downloaded (' + response.status + ').');
  const reader = response.body?.getReader();
  if (!reader) fail('E_PACKAGE_FETCH', 'The package response did not contain a readable body.');
  const chunks = []; let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > expected) { await reader.cancel(); fail('E_PACKAGE_INTEGRITY', 'A package asset exceeded its declared byte size.'); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  if (length !== expected) fail('E_PACKAGE_INTEGRITY', 'A package asset did not match its declared byte size.');
  const bytes = new Uint8Array(length); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return bytes;
}

/** Executable bytes live in their own verified caches, outside the UTF-8 VFS. */
export function createPackageAssets({ baseURL = new URL('../../', import.meta.url).href,
  cacheStorage = globalThis.caches, fetcher = globalThis.fetch,
  importer = url => import(url), ensureRoute = offline.ensurePackageRoute,
  document: doc = globalThis.document } = {}) {
  const base = new URL(baseURL).href;
  const modules = new Map(), styles = new Map();
  function available() {
    if (!cacheStorage?.open) fail('E_PACKAGE_CACHE', 'This browser needs CacheStorage to install optional software.');
  }
  async function check(manifest, { verify = false } = {}) {
    if (manifest.kind === 'project') return { available: true };
    if (!cacheStorage?.open) return { available: false, reason: 'CacheStorage is unavailable.' };
    const name = packageCache(manifest, base);
    if (cacheStorage.has && !await cacheStorage.has(name)) return { available: false, reason: 'Package assets are not cached.' };
    const cache = await cacheStorage.open(name);
    const response = await cache.match(packageURL(manifest, MARKER, base));
    if (!response) return { available: false, reason: 'Package staging has not completed.' };
    let marker;
    try { marker = await response.json(); } catch { return { available: false, reason: 'The package completion record is invalid.' }; }
    if (marker.schema !== 1 || marker.digest !== manifest.digest || marker.id !== manifest.id || marker.version !== manifest.version ||
        !Array.isArray(marker.assets) || canonical(marker.assets) !== canonical(manifest.assets)) return { available: false, reason: 'The package completion record does not match its manifest.' };
    for (const asset of manifest.assets) {
      const response = await cache.match(packageURL(manifest, asset.path, base));
      if (!response) return { available: false, reason: 'Missing package asset: ' + asset.path };
      if (verify) {
        try {
          const bytes = await bytesFrom(response, asset.bytes);
          if (await sha256(bytes) !== asset.sha256) return { available: false, reason: 'Package bytes changed: ' + asset.path };
        } catch (error) { return { available: false, reason: error.message }; }
      }
    }
    return { available: true, cache: name };
  }
  async function stage(manifest, { onProgress = () => {}, verify = false } = {}) {
    available();
    const prior = await check(manifest, { verify });
    if (prior.available) return { staged: true, reused: true, cache: prior.cache };
    const name = packageCache(manifest, base), cache = await cacheStorage.open(name);
    await cache.delete(packageURL(manifest, MARKER, base));
    try {
      for (const [index, asset] of manifest.assets.entries()) {
        const source = new URL(manifest.source + '/' + asset.path, base);
        const response = await fetcher(source.href, { cache: 'no-store', credentials: 'same-origin', redirect: 'error' });
        const bytes = await bytesFrom(response, asset.bytes);
        if (await sha256(bytes) !== asset.sha256) fail('E_PACKAGE_INTEGRITY', 'Package bytes changed: ' + manifest.id + '/' + asset.path + '. Refresh the software catalog from a complete release.');
        await cache.put(packageURL(manifest, asset.path, base), new Response(bytes, { headers: {
          'Content-Type': asset.type, 'Content-Length': String(asset.bytes),
          'Cache-Control': 'public, max-age=31536000, immutable', 'X-Content-Type-Options': 'nosniff'
        } }));
        onProgress({ id: manifest.id, completed: index + 1, total: manifest.assets.length });
      }
      // No module may load until every declared asset has passed verification.
      await cache.put(packageURL(manifest, MARKER, base), new Response(JSON.stringify({
        schema: 1, id: manifest.id, version: manifest.version, digest: manifest.digest, assets: manifest.assets
      }), { headers: { 'Content-Type': 'application/json' } }));
      return { staged: true, reused: false, cache: name };
    } catch (error) {
      await cacheStorage.delete(name).catch(() => {});
      throw error;
    }
  }
  async function ensureStyles(manifest) {
    if (!manifest.styles.length) return;
    if (!doc?.head) fail('E_PACKAGE_STYLE', 'A document is required to load package styles.');
    for (const path of manifest.styles) {
      const url = packageURL(manifest, path, base);
      if (!styles.has(url)) {
        const task = new Promise((resolve, reject) => {
          const link = doc.createElement('link');
          link.rel = 'stylesheet'; link.href = url; link.dataset.package = manifest.id;
          link.onload = () => resolve();
          link.onerror = () => { link.remove(); reject(new Error('Package stylesheet could not load: ' + path)); };
          doc.head.append(link);
        });
        styles.set(url, task);
        task.catch(() => styles.delete(url));
      }
      await styles.get(url);
    }
  }
  async function load(manifest, path = manifest.entry) {
    if (!path || !manifest.assets.some(asset => asset.path === path && /\.(mjs|js)$/.test(path))) fail('E_PACKAGE_ENTRY', 'The package does not declare this JavaScript module.');
    // The same lifecycle drives boot's Offline indicator. Registration failures
    // reach this caller, and first installation is awaited through activation.
    await ensureRoute();
    const result = await check(manifest);
    if (!result.available) fail('E_PACKAGE_REPAIR', 'Repair ' + manifest.id + ' in Software. ' + result.reason);
    try { await ensureStyles(manifest); }
    catch (error) { fail('E_PACKAGE_STYLE', error.message + '. If an offline update is waiting, save work and close all workspace tabs before reopening.'); }
    const url = packageURL(manifest, path, base);
    if (!modules.has(url)) {
      const task = importer(url);
      modules.set(url, task);
      // The browser retains evaluated modules. A failed evaluation may require a reload.
      task.catch(() => {});
    }
    try { return await modules.get(url); }
    catch (error) { fail('E_PACKAGE_LOAD', 'The package could not start: ' + manifest.id + '. ' + error.message + ' Save work and reload after repairing its assets. If an offline update is waiting, close all workspace tabs before reopening.'); }
  }
  return Object.freeze({ baseURL: base, check, stage, load,
    hasImported: manifest => manifest.assets.some(asset => modules.has(packageURL(manifest, asset.path, base))),
    url: (manifest, path) => packageURL(manifest, path, base),
    async remove(manifest) {
      if (manifest.kind === 'project' || !cacheStorage?.delete) return { removed: false };
      return { removed: await cacheStorage.delete(packageCache(manifest, base)) };
    }
  });
}
