import { createPackageAssets } from './assets.mjs';
import { SoftwareError, fail, object, clone, bounded, identifier, version, dependencies, digest,
  sha256, canonical, jsonSize, normalizeManifest, LIMITS } from './schema.mjs';

const APP = 'system.software';
const empty = () => ({ schema: 1, installed: [], published: [] });
const stamp = () => new Date().toISOString();
const unique = values => [...new Set(values)].sort();
const identity = manifest => manifest.id + '@' + manifest.version + ':' + manifest.digest;

function stateValue(value) {
  if (value === null) return empty();
  if (!object(value) || value.schema !== 1 || !Array.isArray(value.installed) || !Array.isArray(value.published) ||
      value.installed.length > LIMITS.packages || value.published.length > LIMITS.published) fail('E_PACKAGE_STATE', 'The saved software registry is not a supported bounded registry.');
  const ids = new Set(), published = new Set();
  const result = { schema: 1, installed: value.installed.map(item => {
    if (!object(item) || typeof item.enabled !== 'boolean') fail('E_PACKAGE_STATE', 'An installed record is invalid.');
    const manifest = normalizeManifest(item.manifest);
    if (ids.has(manifest.id)) fail('E_PACKAGE_STATE', 'The installed registry contains duplicate IDs.');
    ids.add(manifest.id);
    if (!Array.isArray(item.reasons) || item.reasons.length > LIMITS.packages) fail('E_PACKAGE_STATE', 'An installed package needs bounded installation reasons.');
    return { manifest, enabled: item.enabled, installedAt: bounded(item.installedAt, 'Installation date', 40),
      reasons: unique(item.reasons.map(reason => bounded(reason, 'Installation reason', 120))) };
  }), published: value.published.map(item => {
    const manifest = normalizeManifest(item.manifest);
    if (manifest.kind !== 'project' || !manifest.id.startsWith('programs.') || published.has(manifest.id)) fail('E_PACKAGE_STATE', 'A published catalog entry is invalid.');
    published.add(manifest.id);
    return { manifest, publishedAt: bounded(item.publishedAt, 'Publication date', 40),
      ...(item.sourcePath ? { sourcePath: bounded(item.sourcePath, 'Project source path', 4096) } : {}) };
  }) };
  jsonSize(result, 900 * 1024, 'Software registry');
  return result;
}

/**
 * The committed registry is authoritative. Cached bytes are prepared before it
 * changes; contributions are derived from that registry without evaluating code.
 * This is trusted package management, not a JavaScript security sandbox.
 */
export function createSoftware({ storage, username, onChange = () => {}, onStatus = () => {},
  busy = () => [], projectAdapter = {}, catalog: suppliedCatalog, assets: suppliedAssets,
  baseURL = new URL('../../', import.meta.url).href, fetcher = globalThis.fetch,
  reservedApplications = ['terminal', 'tasks', 'files', 'journal', 'system', 'software', 'sync'],
  reservedCommands = ['help', 'echo', 'ls', 'cat', 'write', 'mkdir', 'rm', 'mv', 'tasks', 'events', 'open', 'system', 'groups', 'export', 'select', 'where', 'windows', 'find', 'clipboard', 'dom', 'ndjson', 'software', 'project', 'sync'] } = {}) {
  if (typeof storage?.call !== 'function') throw new TypeError('Software requires the local storage service.');
  if (typeof username !== 'string' || !/^[a-z][a-z0-9_-]{0,31}$/.test(username)) fail('E_PROFILE', 'Software needs a valid local username.');
  const home = '/home/' + username, directory = home + '/.local/share/software', path = directory + '/installed.json';
  const publishedDirectory = home + '/Published';
  const assets = suppliedAssets ?? createPackageAssets({ baseURL, fetcher });
  const bundled = new Map(), health = new Map(), listeners = new Set(), leases = new Map(), transitioning = new Set(), evaluated = new Map();
  let state = empty(), revision = 0, tail = Promise.resolve(), pending = 0, closed = false, catalogError = null;

  function notify(status) { try { Promise.resolve(onStatus(status)).catch(() => {}); } catch {} }
  function changed(result) {
    for (const listener of [onChange, ...listeners]) {
      try { Promise.resolve(listener(result)).catch(() => {}); } catch {}
    }
  }
  function current(id) { return state.installed.find(item => item.manifest.id === id); }
  function availableMap() {
    return new Map([...bundled, ...state.published.map(item => [item.manifest.id, item.manifest])]);
  }
  function resolveId(value) {
    identifier(value);
    const all = availableMap();
    if (all.has(value) || current(value)) return value;
    const name = 'applications.' + value;
    if (all.has(name) || current(name)) return name;
    fail('E_PACKAGE_NOT_FOUND', 'Unknown package: ' + value + '. Open Software to see the catalog.');
  }
  function catalogManifest(id) { return availableMap().get(id) ?? current(id)?.manifest; }
  function installedMap(next = state) { return new Map(next.installed.map(item => [item.manifest.id, item])); }

  async function loadCatalog() {
    let value = suppliedCatalog;
    if (!value) {
      const response = await fetcher(new URL('catalog/software.json', baseURL).href, { credentials: 'same-origin' });
      if (!response.ok) fail('E_PACKAGE_CATALOG', 'The software catalog could not be loaded.');
      const source = await response.text();
      if (source.length > 1024 * 1024) fail('E_PACKAGE_CATALOG', 'The software catalog exceeds its size limit.');
      value = JSON.parse(source);
    }
    const records = Array.isArray(value) ? value : value?.schema === 1 ? value.packages : null;
    if (!Array.isArray(records) || records.length > LIMITS.packages) fail('E_PACKAGE_CATALOG', 'The software catalog is invalid.');
    for (const raw of records) {
      const manifest = normalizeManifest(raw);
      if (manifest.kind === 'project' || !manifest.source || bundled.has(manifest.id)) fail('E_PACKAGE_CATALOG', 'The bundled catalog contains an invalid package.');
      const body = { ...manifest }; delete body.digest;
      if (await sha256(canonical(body)) !== manifest.digest) fail('E_PACKAGE_CATALOG', 'The catalog manifest digest does not match: ' + manifest.id);
      bundled.set(manifest.id, manifest);
    }
  }
  async function mkdirs(target) {
    const parts = target.split('/').filter(Boolean); let location = '';
    for (const part of parts) { location += '/' + part; await storage.call('mkdir', { path: location }); }
  }
  const ready = (async () => {
    await mkdirs(directory);
    await mkdirs(publishedDirectory);
    const saved = await storage.call('getState', { app: APP });
    state = stateValue(saved.state); revision = saved.revision;
    try { await loadCatalog(); }
    catch (error) { catalogError = error.message; notify({ state: 'catalog-error', message: catalogError }); }
    validateContributions(state);
    for (const item of state.installed) {
      try { health.set(item.manifest.id, await availability(item.manifest)); }
      catch (error) { health.set(item.manifest.id, { available: false, reason: error.message }); }
    }
    notify({ state: 'ready', message: 'Software registry loaded.', revision, path });
    return { revision, installed: state.installed.length, catalogError };
  })();
  ready.catch(error => notify({ state: 'error', message: error.message, code: error.code }));

  function validateContributions(next) {
    const appIds = new Set(reservedApplications), commandIds = new Set(reservedCommands);
    const map = installedMap(next);
    for (const item of next.installed) {
      for (const dep of item.manifest.dependencies) {
        const target = map.get(dep.id);
        if (!target || target.manifest.version !== dep.version) fail('E_PACKAGE_DEPENDENCY', item.manifest.id + ' requires ' + dep.id + '@' + dep.version + '.');
        if (item.enabled && !target.enabled) fail('E_PACKAGE_DEPENDENCY', 'Enable ' + dep.id + ' before enabling ' + item.manifest.id + '.');
      }
      if (!item.enabled) continue;
      for (const [values, seen] of [[item.manifest.applications, appIds], [item.manifest.commands, commandIds]]) {
        for (const contribution of values) {
          if (seen.has(contribution.id)) fail('E_PACKAGE_COLLISION', 'A contribution already owns the name: ' + contribution.id);
          seen.add(contribution.id);
        }
      }
    }
  }
  function dependencyClosure(manifest, map = availableMap()) {
    const result = [], visiting = new Set(), done = new Set();
    function visit(item) {
      if (visiting.has(item.id)) fail('E_PACKAGE_CYCLE', 'Package dependencies contain a cycle at ' + item.id + '.');
      if (done.has(item.id)) return;
      visiting.add(item.id);
      for (const dep of item.dependencies) {
        const present = current(dep.id)?.manifest;
        const target = present?.version === dep.version ? present : map.get(dep.id);
        if (!target || target.version !== dep.version) fail('E_PACKAGE_DEPENDENCY', item.id + ' needs unavailable dependency ' + dep.id + '@' + dep.version + '.');
        visit(target);
      }
      visiting.delete(item.id); done.add(item.id); result.push(item);
    }
    visit(manifest);
    return result;
  }
  function reasons(next) {
    for (const item of next.installed) item.reasons = item.reasons.filter(reason => reason === 'explicit' || reason.startsWith('group:'));
    const map = installedMap(next);
    for (const item of next.installed) for (const dep of item.manifest.dependencies) {
      const target = map.get(dep.id);
      if (target) target.reasons.push('dependency:' + item.manifest.id);
    }
    for (const item of next.installed) item.reasons = unique(item.reasons);
  }
  async function commit(next, type, data, writes = []) {
    reasons(next); validateContributions(next); stateValue(next);
    const operationId = crypto.randomUUID();
    const receipt = await storage.call('commit', { app: APP, expectedRevision: revision, state: next,
      events: [{ type, data }], writes: [{ path, text: JSON.stringify(next, null, 2) + '\n' }, ...writes], operationId });
    state = next; revision = receipt.revision;
    const result = { revision, operationId, path };
    changed({ type, ...data, ...result });
    return result;
  }
  function enqueue(label, action) {
    if (closed) return Promise.reject(new SoftwareError('E_PACKAGE_CLOSED', 'The software service is closed.'));
    if (pending >= 8) return Promise.reject(new SoftwareError('E_PACKAGE_BUSY', 'Await the current software operations.'));
    pending++;
    const work = tail.then(async () => {
      await ready;
      notify({ state: 'working', message: label });
      try {
        const result = await action();
        notify({ state: 'ready', message: label + ' completed.', revision });
        return result;
      } catch (error) {
        notify({ state: 'error', message: error.message, code: error.code }); throw error;
      }
    }).finally(() => { pending--; });
    tail = work.catch(() => {});
    return work;
  }
  function dependedOn(id, enabledOnly = false) {
    return state.installed.filter(item => (!enabledOnly || item.enabled) && item.manifest.dependencies.some(dep => dep.id === id)).map(item => item.manifest.id);
  }
  function busyReasons(id) {
    const result = [];
    for (const lease of leases.values()) if (lease.packages.includes(id)) result.push({ ...lease.owner, packageId: lease.root });
    const supplied = busy(id) ?? [];
    if (Array.isArray(supplied)) result.push(...supplied.slice(0, 128));
    return result;
  }
  function refuseBusy(id) {
    const owners = busyReasons(id);
    if (owners.length) fail('E_PACKAGE_BUSY', 'Close the application windows and finish its running commands before changing ' + id + '.', { owners });
  }
  function ensureActive(id) {
    if (closed) fail('E_PACKAGE_CLOSED', 'The software service is closed.');
    if (transitioning.has(id)) fail('E_PACKAGE_BUSY', 'The package is changing. Try again when Software finishes.');
    const item = current(id);
    if (!item) fail('E_PACKAGE_NOT_INSTALLED', 'Install ' + id + ' from Software first.');
    if (!item.enabled) fail('E_PACKAGE_DISABLED', 'Enable ' + id + ' in Software first.');
    const status = health.get(id);
    if (status && !status.available) fail('E_PACKAGE_REPAIR', 'Repair ' + id + ' in Software. ' + status.reason);
    return item;
  }
  function acquire(value, owner = {}) {
    const id = resolveId(value), root = ensureActive(id);
    const closure = dependencyClosure(root.manifest, new Map(state.installed.map(item => [item.manifest.id, item.manifest])));
    for (const manifest of closure) ensureActive(manifest.id);
    const key = crypto.randomUUID();
    leases.set(key, { root: id, packages: closure.map(item => item.id), owner: {
      kind: bounded(owner.kind ?? 'operation', 'Resource kind', 32),
      id: bounded(owner.id ?? key, 'Resource ID', 160), title: bounded(owner.title ?? root.manifest.title, 'Resource title', 180)
    } });
    let released = false;
    return () => { if (!released) { released = true; leases.delete(key); } };
  }
  function activeContributions(key) {
    return state.installed.filter(item => item.enabled).flatMap(item => item.manifest[key].map(value => ({
      ...clone(value), packageId: item.manifest.id, version: item.manifest.version,
      available: health.get(item.manifest.id)?.available !== false,
      ...(item.manifest.kind === 'project' ? { program: true } : {})
    })));
  }
  function describe(id) {
    const available = catalogManifest(id), installed = current(id), status = installed ? health.get(id) : null;
    if (!available) fail('E_PACKAGE_NOT_FOUND', 'Unknown package: ' + id);
    const manifest = installed?.manifest ?? available;
    const dependents = dependedOn(id), running = busyReasons(id);
    return { id, title: manifest.title, description: manifest.description, version: manifest.version, kind: manifest.kind,
      bytes: manifest.assets.reduce((sum, asset) => sum + asset.bytes, 0), installed: Boolean(installed),
      enabled: installed?.enabled ?? false, installedVersion: installed?.manifest.version ?? null,
      availableVersion: available.version,
      updateAvailable: Boolean(installed && installed.manifest.digest !== available.digest),
      state: !installed ? 'available' : status?.available === false ? 'repair-required' : installed.enabled ? 'installed' : 'disabled',
      reasons: installed ? [...installed.reasons] : [], dependencies: clone(manifest.dependencies), dependents, running,
      applications: clone(manifest.applications), commands: clone(manifest.commands),
      ...(status?.reason ? { problem: status.reason } : {}),
      ...(manifest.bundlePath ? { bundlePath: manifest.bundlePath } : {}),
      dataRetention: 'Documents, published bundles, application data, and journal history are retained on removal.' };
  }
  function plan(value) {
    const id = resolveId(value), manifest = catalogManifest(id);
    const closure = dependencyClosure(manifest);
    return { id, packages: closure.map(item => ({ id: item.id, version: item.version,
      action: !current(item.id) ? 'install' : current(item.id).manifest.digest !== item.digest ? 'replace' : current(item.id).enabled ? 'keep' : 'enable',
      reason: item.id === id ? 'explicit' : 'dependency', bytes: item.assets.reduce((sum, asset) => sum + asset.bytes, 0) })),
      bytes: closure.filter(item => current(item.id)?.manifest.digest !== item.digest).reduce((sum, item) => sum + item.assets.reduce((n, asset) => n + asset.bytes, 0), 0) };
  }
  async function availability(manifest) {
    if (manifest.kind !== 'project') return assets.check(manifest);
    try { await readBundle(manifest); return { available: true }; }
    catch (error) { return { available: false, reason: error.message }; }
  }
  async function prepare(manifest, { verify = false } = {}) {
    if (manifest.kind === 'project') { await readBundle(manifest); return; }
    await assets.stage(manifest, { verify, onProgress: progress => notify({ state: 'staging', ...progress, message: 'Verifying ' + manifest.title + '…' }) });
  }

  async function install(value) {
    const id = resolveId(value), manifest = catalogManifest(id), closure = dependencyClosure(manifest);
    const previous = [], next = clone(state), map = installedMap(next);
    if (new Set([...map.keys(), ...closure.map(item => item.id)]).size > LIMITS.packages) fail('E_PACKAGE_LIMIT', 'Too many installed packages.');
    for (const item of closure) transitioning.add(item.id);
    try {
      for (const item of closure) {
        const old = current(item.id);
        if (old && old.manifest.digest !== item.digest) {
          refuseBusy(item.id);
          if (evaluated.has(item.id)) fail('E_PACKAGE_RESTART', 'Save work and reload before replacing the evaluated code of ' + item.id + '.');
          previous.push(old.manifest);
        }
        await prepare(item);
        const record = map.get(item.id) ?? { installedAt: stamp(), reasons: [] };
        record.manifest = clone(item); record.enabled = true;
        if (item.id === id && !record.reasons.includes('explicit')) record.reasons.push('explicit');
        if (!map.has(item.id)) { next.installed.push(record); map.set(item.id, record); }
      }
      // Availability follows the successful preparation, and becomes observable
      // together with the committed registry through the onChange callback.
      const oldHealth = new Map(health);
      for (const item of closure) health.set(item.id, { available: true });
      let receipt;
      try { receipt = await commit(next, 'software.installed', { id, packages: closure.map(item => ({ id: item.id, version: item.version })) }); }
      catch (error) { health.clear(); for (const [key, value] of oldHealth) health.set(key, value); throw error; }
      for (const old of previous) await assets.remove(old).catch(() => {});
      return { installed: true, id, packages: closure.map(item => item.id), ...receipt };
    } finally { for (const item of closure) transitioning.delete(item.id); }
  }
  async function enable(value) {
    const id = resolveId(value), item = current(id);
    if (!item) fail('E_PACKAGE_NOT_INSTALLED', 'Install the package before enabling it.');
    const closure = dependencyClosure(item.manifest, new Map(state.installed.map(record => [record.manifest.id, record.manifest])));
    const next = clone(state), ids = new Set(closure.map(record => record.id));
    for (const manifest of closure) {
      const status = await availability(manifest); health.set(manifest.id, status);
      if (!status.available) fail('E_PACKAGE_REPAIR', 'Repair ' + manifest.id + ' before enabling it. ' + status.reason);
    }
    for (const record of next.installed) if (ids.has(record.manifest.id)) record.enabled = true;
    return { enabled: true, id, ...await commit(next, 'software.enabled', { id, packages: [...ids] }) };
  }
  async function disable(value) {
    const id = resolveId(value), item = current(id);
    if (!item) fail('E_PACKAGE_NOT_INSTALLED', 'This package is not installed.');
    const dependents = dependedOn(id, true);
    if (dependents.length) fail('E_PACKAGE_DEPENDENCY', 'Disable dependent packages first: ' + dependents.join(', '), { dependents });
    transitioning.add(id);
    try {
      refuseBusy(id);
      const next = clone(state); next.installed.find(record => record.manifest.id === id).enabled = false;
      return { disabled: true, id, ...await commit(next, 'software.disabled', { id }) };
    } finally { transitioning.delete(id); }
  }
  async function remove(value) {
    const id = resolveId(value), item = current(id);
    if (!item) return { removed: false, id, dataRetained: true };
    const dependents = dependedOn(id);
    if (dependents.length) fail('E_PACKAGE_DEPENDENCY', 'Remove dependent packages first: ' + dependents.join(', '), { dependents });
    transitioning.add(id);
    try {
      refuseBusy(id);
      const next = clone(state); next.installed = next.installed.filter(record => record.manifest.id !== id);
      const receipt = await commit(next, 'software.removed', { id, version: item.manifest.version, dataRetained: true });
      health.delete(id);
      let assetsRemoved = false;
      try { assetsRemoved = Boolean((await assets.remove(item.manifest)).removed); } catch {}
      return { removed: true, id, dataRetained: true, assetsRemoved, ...receipt };
    } finally { transitioning.delete(id); }
  }
  async function repair(value) {
    const id = resolveId(value), item = current(id);
    if (!item) fail('E_PACKAGE_NOT_INSTALLED', 'Install the package before repairing it.');
    const closure = dependencyClosure(item.manifest, new Map(state.installed.map(record => [record.manifest.id, record.manifest])));
    try {
      for (const manifest of closure) {
        try { await prepare(manifest, { verify: true }); health.set(manifest.id, { available: true }); }
        catch (error) { health.set(manifest.id, { available: false, reason: error.message }); throw error; }
      }
    } catch (error) { changed({ type: 'software.repair-failed', id }); throw error; }
    changed({ type: 'software.repaired', id });
    return { repaired: true, id, packages: closure.map(manifest => manifest.id), revision };
  }

  async function executable(manifest, module = manifest.entry) {
    try { return await assets.load(manifest, module); }
    catch (error) {
      if (error.code === 'E_PACKAGE_REPAIR' || error.code === 'E_PACKAGE_CACHE') {
        health.set(manifest.id, { available: false, reason: error.message });
        changed({ type: 'software.assets-unavailable', id: manifest.id });
      }
      throw error;
    } finally {
      // Failed evaluation can leave partial effects, whereas waiting for the
      // worker or a stylesheet has not evaluated JavaScript at all.
      if (!assets.hasImported || assets.hasImported(manifest)) evaluated.set(manifest.id, manifest.digest);
    }
  }

  async function loadModule(value) {
    await ready;
    const id = resolveId(value), item = ensureActive(id);
    if (item.manifest.kind !== 'module') fail('E_PACKAGE_ENTRY', 'This package contains no executable entry module.');
    const release = acquire(id, { kind: 'loading', title: item.manifest.title });
    try {
      return await executable(item.manifest);
    } finally { release(); }
  }
  async function loadApplication(appId) {
    await ready;
    const descriptor = activeContributions('applications').find(item => item.id === appId);
    if (!descriptor) fail('E_APPLICATION_NOT_INSTALLED', 'Install or enable this application in Software: ' + appId);
    // Return a builder before importing anything, so its complete lifetime is leased.
    return async (context, options = {}) => {
      const item = ensureActive(descriptor.packageId);
      const release = acquire(item.manifest.id, { kind: 'window', id: options.id ?? crypto.randomUUID(), title: descriptor.title });
      try {
        let app;
        if (item.manifest.kind === 'project') {
          const bundle = await readBundle(item.manifest);
          if (typeof projectAdapter.build !== 'function') fail('E_PROJECT_RUNTIME', 'The project runtime is unavailable.');
          app = await projectAdapter.build(clone(bundle.project), context, { ...options, application: appId, packageId: item.manifest.id });
        } else {
          const namespace = await executable(item.manifest, descriptor.module);
          const build = namespace[descriptor.export];
          if (typeof build !== 'function') fail('E_PACKAGE_ENTRY', 'The application builder is missing: ' + descriptor.export);
          app = await build(context, options);
        }
        if (!Array.isArray(app?.cleanup)) fail('E_PACKAGE_APP', 'An application must return a host frame with a cleanup scope.');
        // The host's logical application identity owns session and resource lookup.
        app.name = appId;
        app.cleanup.push(release);
        return app;
      } catch (error) { release(); throw error; }
    };
  }
  async function invokeCommand(name, ctx) {
    await ready;
    const descriptor = activeContributions('commands').find(item => item.name === name);
    if (!descriptor) fail('E_COMMAND_NOT_INSTALLED', 'Install or enable the command package first: ' + name);
    const item = ensureActive(descriptor.packageId), release = acquire(item.manifest.id, { kind: 'command', title: name });
    try {
      ctx.signal?.throwIfAborted();
      const namespace = await executable(item.manifest, descriptor.module);
      const run = namespace[descriptor.export];
      if (typeof run !== 'function') fail('E_PACKAGE_ENTRY', 'The command export is missing: ' + descriptor.export);
      ctx.signal?.throwIfAborted();
      return await run(ctx);
    } finally { release(); }
  }

  async function validateProject(value) {
    if (typeof projectAdapter.validate !== 'function') fail('E_PROJECT_RUNTIME', 'The project validator is unavailable.');
    const result = await projectAdapter.validate(clone(value));
    jsonSize(result, LIMITS.bundleBytes - 8192, 'Published project');
    return result;
  }
  function programId(value) {
    const id = identifier(value);
    return id.startsWith('programs.') ? id : identifier('programs.' + id);
  }
  async function makeBundle({ project: input, id: requestedId, title } = {}) {
    const prepared = projectAdapter.preparePublish ? await projectAdapter.preparePublish(clone(input)) : input;
    const project = await validateProject(prepared);
    const sourceId = bounded(project.id, 'Project ID', 64), lowerId = sourceId.toLowerCase();
    const defaultId = lowerId === sourceId ? lowerId : lowerId + '-' + (await sha256(sourceId)).slice(0, 8);
    const id = programId(requestedId ?? defaultId);
    const appId = identifier('program.' + id.slice('programs.'.length), 'Program application ID');
    const name = bounded(title ?? project.name ?? project.title ?? 'Published program', 'Program title', 100);
    let requirements = projectAdapter.requirements ? await projectAdapter.requirements(project) : project.requires ?? [];
    requirements = dependencies(requirements);
    const projectDigest = await sha256(canonical(project));
    const labelDigest = await sha256(canonical({ id, name, projectDigest, requirements }));
    const manifest = { id, version: '1.0.0+' + labelDigest.slice(0, 16), title: name,
      description: bounded(project.description ?? '', 'Program description', 600), api: 'esos.v1',
      dependencies: requirements, application: { id: appId, title: name, description: bounded(project.description ?? '', 'Program description', 600) } };
    const body = { format: 'esos.package', version: 1, manifest, project };
    const result = { ...body, integrity: { algorithm: 'SHA-256', digest: await sha256(canonical(body)) } };
    jsonSize(result, LIMITS.bundleBytes, 'Portable program bundle');
    return result;
  }
  async function validateBundle(value) {
    if (!object(value) || value.format !== 'esos.package' || value.version !== 1 ||
        Object.keys(value).some(key => !['format', 'version', 'manifest', 'project', 'integrity'].includes(key)) ||
        !object(value.manifest) || !object(value.integrity) || value.integrity.algorithm !== 'SHA-256') fail('E_BUNDLE_FORMAT', 'Import a version 1 declarative eSOS package bundle.');
    jsonSize(value, LIMITS.bundleBytes, 'Portable program bundle');
    const body = { format: value.format, version: value.version, manifest: value.manifest, project: value.project };
    if (await sha256(canonical(body)) !== digest(value.integrity.digest)) fail('E_BUNDLE_INTEGRITY', 'The portable bundle does not match its integrity digest.');
    const manifest = value.manifest;
    if (Object.keys(manifest).some(key => !['id', 'version', 'title', 'description', 'api', 'dependencies', 'application'].includes(key)) ||
        !object(manifest.application) || Object.keys(manifest.application).some(key => !['id', 'title', 'description'].includes(key))) {
      fail('E_BUNDLE_FORMAT', 'Portable program bundles contain declarative data, not executable assets or module entries.');
    }
    if (programId(manifest.id) !== manifest.id || manifest.api !== 'esos.v1') fail('E_BUNDLE_FORMAT', 'A portable program uses a programs.* ID and the esos.v1 API.');
    version(manifest.version); bounded(manifest.title, 'Program title', 100); bounded(manifest.description, 'Program description', 600);
    identifier(manifest.application.id, 'Program application ID');
    if (manifest.application.id !== 'program.' + manifest.id.slice('programs.'.length)) fail('E_BUNDLE_FORMAT', 'The program application ID must match its package.');
    bounded(manifest.application.title, 'Application title', 100); bounded(manifest.application.description, 'Application description', 600);
    const declared = dependencies(manifest.dependencies), project = await validateProject(value.project);
    if (canonical(project) !== canonical(value.project)) fail('E_BUNDLE_FORMAT', 'The project in this bundle is not in the supported canonical format. Re-publish it with its editor.');
    const required = dependencies(projectAdapter.requirements ? await projectAdapter.requirements(project) : project.requires ?? []);
    for (const dependency of required) if (!declared.some(item => item.id === dependency.id && item.version === dependency.version)) {
      fail('E_BUNDLE_DEPENDENCY', 'The bundle omits required runtime ' + dependency.id + '.');
    }
    return clone(value);
  }
  async function readBundle(manifest) {
    const file = await storage.call('read', { path: manifest.bundlePath });
    let value;
    try { value = JSON.parse(file.text); } catch { fail('E_BUNDLE_FORMAT', 'The published bundle is not valid JSON: ' + manifest.bundlePath); }
    const bundle = await validateBundle(value);
    if (bundle.integrity.digest !== manifest.digest || bundle.manifest.id !== manifest.id || bundle.manifest.version !== manifest.version ||
        await sha256(canonical(bundle.project)) !== manifest.projectDigest) fail('E_BUNDLE_INTEGRITY', 'The published bundle does not match the installed program.');
    return bundle;
  }
  async function storeBundle(bundle, { sourcePath, imported = false } = {}) {
    const id = bundle.manifest.id, targetDirectory = publishedDirectory + '/' + id;
    await mkdirs(targetDirectory);
    const bundlePath = targetDirectory + '/' + bundle.integrity.digest + '.esospkg.json';
    const raw = bundle.manifest;
    const manifest = normalizeManifest({ schema: 1, id, version: raw.version, title: raw.title,
      description: raw.description, api: raw.api, kind: 'project', dependencies: raw.dependencies,
      applications: [raw.application], commands: [], styles: [], assets: [], bundlePath,
      projectDigest: await sha256(canonical(bundle.project)), digest: bundle.integrity.digest });
    const previous = state.published.find(item => item.manifest.id === id);
    if (previous?.manifest.digest === manifest.digest) return { published: true, imported, unchanged: true, id,
      application: raw.application.id, version: manifest.version, bundlePath, installed: Boolean(current(id)), revision };
    if (!previous && state.published.length >= LIMITS.published) fail('E_PACKAGE_LIMIT', 'This local catalog already has 64 published programs. Existing programs were preserved.');
    const next = clone(state);
    next.published = next.published.filter(item => item.manifest.id !== id);
    next.published.push({ manifest, publishedAt: stamp(), ...(sourcePath ? { sourcePath: bounded(sourcePath, 'Source project path', 4096) } : {}) });
    // A received ordinary bundle may already occupy the immutable content path.
    // Verify those exact bytes, then retain the ordinary file rather than taking ownership.
    let existing = null;
    try { existing = await storage.call('read', { path: bundlePath }); }
    catch (error) { if (error.code !== 'E_NOT_FOUND') throw error; }
    if (existing) {
      let found;
      try { found = JSON.parse(existing.text); } catch { fail('E_BUNDLE_EXISTS', 'An unrelated file occupies the immutable bundle path.'); }
      if (canonical(found) !== canonical(bundle)) fail('E_BUNDLE_EXISTS', 'An unrelated file occupies the immutable bundle path.');
    }
    const writes = existing ? [] : [{ path: bundlePath, text: JSON.stringify(bundle) + '\n', expectedRevision: 0 }];
    const receipt = await commit(next, imported ? 'software.bundle-imported' : 'software.published',
      { id, version: manifest.version, application: raw.application.id, bundlePath }, writes);
    return { published: true, imported, id, application: raw.application.id, version: manifest.version,
      bundlePath, installed: Boolean(current(id)), ...receipt };
  }

  return Object.freeze({ ready, path, publishedDirectory, limits: LIMITS,
    list() {
      const ids = unique([...availableMap().keys(), ...state.installed.map(item => item.manifest.id)]);
      return ids.map(describe);
    },
    catalog() { return this.list(); },
    installed() { return state.installed.map(item => describe(item.manifest.id)); },
    inspect(value) {
      const id = resolveId(value);
      return { ...describe(id), manifest: clone(current(id)?.manifest ?? catalogManifest(id)), availableManifest: clone(catalogManifest(id)),
        ...(current(id) ? { installedManifest: clone(current(id).manifest) } : {}), revision, path };
    },
    plan,
    install: value => enqueue('Install software', () => install(value)),
    enable: value => enqueue('Enable software', () => enable(value)),
    disable: value => enqueue('Disable software', () => disable(value)),
    remove: value => enqueue('Remove software', () => remove(value)),
    uninstall: value => enqueue('Remove software', () => remove(value)),
    repair: value => enqueue('Repair software', () => repair(value)),
    applications: () => activeContributions('applications'),
    commands: () => activeContributions('commands'),
    loadApplication, loadModule, invokeCommand, acquire,
    ownerOfApplication: id => activeContributions('applications').find(item => item.id === id)?.packageId ?? null,
    ownerOfCommand: name => activeContributions('commands').find(item => item.name === name)?.packageId ?? null,
    publish: input => enqueue('Publish program', async () => storeBundle(await makeBundle(input), { sourcePath: input?.sourcePath })),
    importBundle: value => enqueue('Import program', async () => storeBundle(await validateBundle(value), { imported: true })),
    async exportBundle(value) {
      await ready;
      const id = resolveId(value), manifest = catalogManifest(id);
      if (manifest.kind !== 'project') fail('E_BUNDLE_TYPE', 'Only declarative published programs are exported as portable bundles.');
      return readBundle(manifest);
    },
    subscribe(listener) {
      if (typeof listener !== 'function') throw new TypeError('A software subscriber must be a function.');
      listeners.add(listener); return () => listeners.delete(listener);
    },
    status: () => ({ revision, path, installed: state.installed.length, published: state.published.length,
      working: pending > 0, catalogError, trust: 'Bundled JavaScript has page authority; portable programs are validated declarative data.' }),
    async close() { closed = true; await tail; listeners.clear(); return { closed: true }; }
  });
}
