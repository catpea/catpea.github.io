export class SoftwareError extends Error {
  constructor(code, message, details) {
    super(message); this.name = 'SoftwareError'; this.code = code;
    if (details !== undefined) this.details = details;
  }
}
export const fail = (code, message, details) => { throw new SoftwareError(code, message, details); };
export const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export const clone = value => structuredClone(value);
export const encoder = new TextEncoder();
export const LIMITS = Object.freeze({ packages: 96, published: 64, assets: 128, assetBytes: 32 * 1024 * 1024,
  packageBytes: 64 * 1024 * 1024, bundleBytes: 768 * 1024, manifestBytes: 128 * 1024 });

export function bounded(value, label, max = 160) {
  if (typeof value !== 'string' || value.length > max || /[\u0000-\u001f\u007f]/.test(value) ||
      (value.isWellFormed && !value.isWellFormed())) fail('E_PACKAGE_FORMAT', label + ' must be bounded text without control characters.');
  return value;
}
export function identifier(value, label = 'Package ID') {
  if (typeof value !== 'string' || !/^[a-z][a-z0-9._-]{0,95}$/.test(value)) fail('E_PACKAGE_FORMAT', label + ' must be a short lowercase identifier.');
  return value;
}
export function version(value) {
  bounded(value, 'Version', 64);
  if (!/^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.-]+)?(?:\+[a-zA-Z0-9.-]+)?$/.test(value)) fail('E_PACKAGE_FORMAT', 'A package needs an exact semantic version.');
  return value;
}
export function assetPath(value) {
  bounded(value, 'Asset path', 240);
  if (!value || value.split('/').some(part => !/^[a-zA-Z0-9_][a-zA-Z0-9_.-]*$/.test(part)) || value === '_verified.json') {
    fail('E_PACKAGE_FORMAT', 'An asset needs a relative path without dot segments.');
  }
  return value;
}
export function digest(value) {
  if (typeof value !== 'string' || !/^[a-f0-9]{64}$/.test(value)) fail('E_PACKAGE_FORMAT', 'A SHA-256 digest is required.');
  return value;
}
export async function sha256(value) {
  const data = typeof value === 'string' ? encoder.encode(value) : value;
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', data)), byte => byte.toString(16).padStart(2, '0')).join('');
}

/** Deterministic JSON used for manifests and portable declarative bundles. */
export function canonical(value, depth = 0, seen = new Set()) {
  if (depth > 48) fail('E_PACKAGE_FORMAT', 'Package data is nested too deeply.');
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') {
    if (value.isWellFormed && !value.isWellFormed()) fail('E_PACKAGE_FORMAT', 'Package strings must be well-formed Unicode.');
    return JSON.stringify(value);
  }
  if (typeof value === 'number') {
    if (!Number.isFinite(value) || (Number.isInteger(value) && !Number.isSafeInteger(value))) fail('E_PACKAGE_FORMAT', 'Package numbers must be finite and exact.');
    return JSON.stringify(value);
  }
  if (!value || typeof value !== 'object' || seen.has(value) ||
      ![Object.prototype, Array.prototype, null].includes(Object.getPrototypeOf(value))) fail('E_PACKAGE_FORMAT', 'Packages contain plain JSON data only.');
  seen.add(value);
  let result;
  if (Array.isArray(value)) {
    if (value.length > 16384 || Object.keys(value).length !== value.length) fail('E_PACKAGE_FORMAT', 'Package arrays must be dense and bounded.');
    result = '[' + value.map(item => canonical(item, depth + 1, seen)).join(',') + ']';
  } else {
    const keys = Object.keys(value).sort();
    if (keys.length > 4096) fail('E_PACKAGE_FORMAT', 'A package object has too many properties.');
    result = '{' + keys.map(key => {
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || !Object.hasOwn(descriptor, 'value')) fail('E_PACKAGE_FORMAT', 'Package data cannot contain getters.');
      return JSON.stringify(key) + ':' + canonical(descriptor.value, depth + 1, seen);
    }).join(',') + '}';
  }
  seen.delete(value);
  return result;
}
export function jsonSize(value, max, label) {
  const text = canonical(value);
  if (encoder.encode(text).byteLength > max) fail('E_PACKAGE_LIMIT', label + ' exceeds its byte limit.');
  return text;
}

export function dependencies(value = []) {
  if (!Array.isArray(value) || value.length > 24) fail('E_PACKAGE_FORMAT', 'A package supports at most 24 direct dependencies.');
  const ids = new Set();
  return value.map(item => {
    if (!object(item)) fail('E_PACKAGE_FORMAT', 'A dependency needs an ID and exact version.');
    const id = identifier(item.id);
    if (ids.has(id)) fail('E_PACKAGE_FORMAT', 'A dependency is listed more than once: ' + id);
    ids.add(id);
    return { id, version: version(item.version) };
  });
}

export function normalizeManifest(value, { generated = true } = {}) {
  if (!object(value) || value.schema !== 1 || !['module', 'metadata', 'project'].includes(value.kind ?? 'module')) {
    fail('E_PACKAGE_FORMAT', 'A package manifest uses schema 1.');
  }
  const result = { schema: 1, id: identifier(value.id), version: version(value.version),
    title: bounded(value.title, 'Package title', 100), description: bounded(value.description ?? '', 'Package description', 600),
    api: bounded(value.api ?? 'esos.v1', 'API version', 32), kind: value.kind ?? 'module',
    dependencies: dependencies(value.dependencies), applications: [], commands: [], styles: [] };
  if (!result.title || result.api !== 'esos.v1') fail('E_PACKAGE_API', 'This package requires an unsupported host API.');
  if (value.entry !== undefined) result.entry = assetPath(value.entry);
  if (value.source !== undefined) {
    result.source = assetPath(value.source);
    if (!result.source.startsWith('packages/')) fail('E_PACKAGE_FORMAT', 'Bundled package sources stay under packages/.');
  }
  for (const [kind, source] of [['applications', value.applications ?? []], ['commands', value.commands ?? []]]) {
    if (!Array.isArray(source) || source.length > 12) fail('E_PACKAGE_FORMAT', 'A package has too many contributions.');
    const ids = new Set();
    result[kind] = source.map(item => {
      if (!object(item)) fail('E_PACKAGE_FORMAT', 'A contribution must be an object.');
      const id = identifier(item.id ?? item.name, 'Contribution ID');
      if (ids.has(id)) fail('E_PACKAGE_FORMAT', 'Duplicate contribution: ' + id);
      ids.add(id);
      const out = { id, title: bounded(item.title ?? id, 'Contribution title', 100),
        description: bounded(item.description ?? item.summary ?? '', 'Contribution description', 600) };
      if (result.kind !== 'project') {
        out.module = assetPath(item.module ?? result.entry);
        out.export = bounded(item.export ?? (kind === 'applications' ? 'build' : 'run'), 'Export name', 80);
        if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(out.export)) fail('E_PACKAGE_FORMAT', 'Invalid module export name.');
      }
      if (kind === 'commands') {
        out.name = id; out.summary = out.description;
        out.usage = bounded(item.usage ?? id, 'Command usage', 500);
        if (item.action !== undefined) { jsonSize(item.action, 8192, 'Action metadata'); out.action = clone(item.action); }
      }
      return out;
    });
  }
  if (!Array.isArray(value.styles ?? []) || (value.styles ?? []).length > 8) fail('E_PACKAGE_FORMAT', 'Too many package stylesheets.');
  result.styles = (value.styles ?? []).map(assetPath);
  if (generated) {
    if (!Array.isArray(value.assets) || value.assets.length > LIMITS.assets) fail('E_PACKAGE_FORMAT', 'Invalid package assets.');
    const paths = new Set(); let total = 0;
    result.assets = value.assets.map(asset => {
      if (!object(asset)) fail('E_PACKAGE_FORMAT', 'An asset must be an object.');
      const path = assetPath(asset.path);
      if (paths.has(path)) fail('E_PACKAGE_FORMAT', 'Duplicate asset path: ' + path);
      paths.add(path);
      if (!Number.isSafeInteger(asset.bytes) || asset.bytes < 0 || asset.bytes > LIMITS.assetBytes) fail('E_PACKAGE_LIMIT', 'A package asset exceeds its byte limit.');
      total += asset.bytes;
      return { path, bytes: asset.bytes, sha256: digest(asset.sha256), type: bounded(asset.type, 'Asset MIME type', 100) };
    });
    if (total > LIMITS.packageBytes) fail('E_PACKAGE_LIMIT', 'This package exceeds the 64 MiB asset limit.');
    for (const path of [result.entry, ...result.applications.map(item => item.module), ...result.commands.map(item => item.module), ...result.styles].filter(Boolean)) {
      if (!paths.has(path)) fail('E_PACKAGE_FORMAT', 'The manifest does not include the required asset: ' + path);
    }
    if (result.kind === 'module' && !result.entry) fail('E_PACKAGE_FORMAT', 'An executable package needs an entry module.');
    if (result.kind === 'project') {
      if (result.assets.length || result.entry || result.commands.length || result.styles.length || result.applications.length !== 1) fail('E_PACKAGE_FORMAT', 'A project package contains data and one application, never executable assets.');
      result.bundlePath = bounded(value.bundlePath, 'Bundle path', 4096);
      result.projectDigest = digest(value.projectDigest);
    }
    result.digest = digest(value.digest);
  }
  jsonSize(result, LIMITS.manifestBytes, 'Package manifest');
  return result;
}
