// Shared by the installer and the service worker. Package URLs are immutable.
export const PACKAGE_ROUTE = '__esos_packages/';
export const MARKER = '_verified.json';
export const packagePrefix = base => 'esos-packages:' + new URL(base).pathname + ':';
export const packageCache = (manifest, base) => packagePrefix(base) + manifest.id + '@' + manifest.version + ':' + manifest.digest;
export const packageURL = (manifest, path, base) => new URL(PACKAGE_ROUTE + manifest.id + '/' + manifest.version + '/' + manifest.digest + '/' + path, base).href;

export function parsePackageURL(value, base) {
  const url = new URL(value), scope = new URL(base);
  const prefix = scope.pathname + PACKAGE_ROUTE;
  if (url.origin !== scope.origin || !url.pathname.startsWith(prefix)) return null;
  const parts = url.pathname.slice(prefix.length).split('/');
  if (parts.length < 4) return null;
  const [id, version, digest, ...names] = parts;
  const path = names.join('/');
  if (!/^[a-z][a-z0-9._-]{0,95}$/.test(id) ||
      !/^[0-9]+\.[0-9]+\.[0-9]+(?:-[a-zA-Z0-9.-]+)?(?:\+[a-zA-Z0-9.-]+)?$/.test(version) ||
      !/^[a-f0-9]{64}$/.test(digest) || names.some(name => !/^[a-zA-Z0-9_][a-zA-Z0-9_.-]*$/.test(name))) return null;
  return { id, version, digest, path };
}
