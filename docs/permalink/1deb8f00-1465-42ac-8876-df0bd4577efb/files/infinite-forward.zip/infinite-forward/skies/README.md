# Sky Images Folder

Place your AI-generated sky images here.

## Requirements

- **Format**: JPG or PNG
- **Type**: Equirectangular 360° panorama
- **Aspect Ratio**: 2:1 (width = 2× height)
- **Recommended Size**: 4096×2048 pixels

## Naming

Use descriptive, lowercase names with hyphens:

```
blood-dawn.jpg
alien-twilight.jpg
void-approaching.jpg
crystal-cavern.jpg
neon-storm.jpg
```

## After Adding Images

1. Edit `with-sky-images.html`
2. Add `<img>` tag in `<a-assets>` section
3. Add matching entry in `SKY_IMAGES` array

See `GENERATING-SKIES.md` for detailed instructions.
