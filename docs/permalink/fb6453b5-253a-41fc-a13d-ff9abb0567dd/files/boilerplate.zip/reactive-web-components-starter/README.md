# Reactive Web Components Starter

A structural/layout starter for building browser applications out of a readable nested Web Component hierarchy.

This starter is for two collaborators:

1. **Humans**, who should be able to open `index.html` and understand the application structure immediately.
2. **AI assistants**, which should be able to edit the application safely by preserving the component tree and making local, inspectable changes.

The core idea is simple:

```html
<app-root>
  <app-navbar brand="Reactive Starter">
    <nav-link text="Overview" to="#overview"></nav-link>
    <nav-link text="Workspace" to="#workspace"></nav-link>
  </app-navbar>

  <app-shell>
    <app-container>
      <hero-section></hero-section>

      <app-grid columns="2">
        <ui-card title="Counter">
          <counter-panel></counter-panel>
        </ui-card>

        <ui-card title="Inspector">
          <state-inspector></state-inspector>
        </ui-card>
      </app-grid>
    </app-container>
  </app-shell>
</app-root>
```

The HTML body is the application map. JavaScript gives those tags behavior.

## Files

```text
reactive-web-components-starter/
├─ index.html
├─ package.json
├─ server.mjs
├─ README.md
├─ SKILL.md
└─ src/
   ├─ main.js
   ├─ core/
   │  └─ reactive.js
   └─ components/
      ├─ layout.js
      └─ examples.js
```

## Run

```bash
npm start
```

The tiny server starts at port `48187` or the next open port, then tries to open your browser.

This project intentionally avoids a build step. It uses native ES modules, native Custom Elements, Bootstrap and Bootstrap Icons from CDN, and a small reactive helper: `Scope`, `Signal`, `Concern`, and `ReactiveHTMLElement`.

## Why nested Web Components?

A flat JavaScript application usually hides the app structure inside render functions.

This starter does the opposite. It puts the structure in the document:

```html
<app-grid columns="3">
  <ui-card title="Orders"></ui-card>
  <ui-card title="Customers"></ui-card>
  <ui-card title="Revenue"></ui-card>
</app-grid>
```

That gives humans and AI a shared editing surface:

- move cards by moving tags
- add layout by adding components
- change presentation by editing attributes
- change behavior by editing the component class
- keep state in a small, explicit application root

## Component design rule

A component should do one of these jobs:

1. **Layout component**: wraps children in Bootstrap structure.
   - Examples: `app-shell`, `app-container`, `app-grid`, `ui-card`.
2. **Control component**: emits user intent or updates state.
   - Example: `counter-panel`.
3. **Display component**: subscribes to signals and renders state.
   - Example: `state-inspector`.
4. **Application root**: owns shared state and application-level methods.
   - Example: `app-root`.

## ReactiveHTMLElement pattern

```js
import { ReactiveHTMLElement } from "./src/core/reactive.js";

class AlertElement extends ReactiveHTMLElement {
  static observedAttributes = ["color", "text"];

  constructor() {
    super();
    this.signal("color", "primary");
    this.signal("text", "");
  }

  mount() {
    this.setAttribute("role", "alert");

    this.subscribe("color", color => {
      this.className = `alert alert-${color || "primary"}`;
    });

    this.concern.bindText("text", this);
  }
}

customElements.define("ui-alert", AlertElement);
```

## Shared state pattern

`app-root` owns the application state:

```js
this.state = this.signal("state", {
  count: 0,
  messages: []
});
```

Child components locate the root through `this.app` and call `this.commit(...)`:

```js
this.commit(draft => {
  draft.count += 1;
});
```

Each commit creates a new top-level state object, so subscribers receive updates predictably.

## Suggested growth path

Start with layout components only:

```html
<app-shell>
  <app-container>
    <ui-card title="First Card"></ui-card>
  </app-container>
</app-shell>
```

Then add feature components:

```html
<ui-card title="Counter">
  <counter-panel></counter-panel>
</ui-card>
```

Then add domain components:

```html
<project-list></project-list>
<project-editor></project-editor>
<project-preview></project-preview>
```

## AI collaboration rule

Give an AI the `SKILL.md` file and ask it to preserve the component hierarchy.

Good request:

> Add a sidebar by introducing `<app-sidebar>` inside `<app-shell>`. Keep the app structure readable in `index.html`.

Bad request:

> Rewrite everything into one render function.

The hierarchy is the product.
