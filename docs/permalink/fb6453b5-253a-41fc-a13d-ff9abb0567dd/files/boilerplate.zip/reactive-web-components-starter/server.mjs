import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.dirname(fileURLToPath(import.meta.url));
const startPort = Number(process.env.PORT || 48187);

const types = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp"
};

async function fileExists(file) {
  try {
    const stat = await fs.stat(file);
    return stat.isFile();
  } catch {
    return false;
  }
}

function createServer() {
  return http.createServer(async (request, response) => {
    try {
      const url = new URL(request.url, "http://localhost");
      const pathname = decodeURIComponent(url.pathname);
      const safePath = path.normalize(pathname).replace(/^([.][.][/\\])+/, "");
      const file = path.join(root, safePath === "/" ? "index.html" : safePath);

      if (!(await fileExists(file))) {
        response.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
        response.end("404 Not Found");
        return;
      }

      const ext = path.extname(file).toLowerCase();
      response.writeHead(200, { "content-type": types[ext] || "application/octet-stream" });
      response.end(await fs.readFile(file));
    } catch (error) {
      response.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
      response.end(error.stack || String(error));
    }
  });
}

function listen(port) {
  return new Promise((resolve, reject) => {
    const server = createServer();

    server.once("error", error => {
      if (error.code === "EADDRINUSE") resolve(listen(port + 1));
      else reject(error);
    });

    server.listen(port, () => resolve({ server, port }));
  });
}

const { port } = await listen(startPort);
const url = `http://localhost:${port}/`;

console.log("Reactive Web Components Starter");
console.log(url);

const opener = process.platform === "darwin" ? "open" : process.platform === "win32" ? "start" : "xdg-open";

try {
  const { spawn } = await import("node:child_process");
  spawn(opener, [url], { shell: true, stdio: "ignore", detached: true }).unref();
} catch {
  // Server still runs even if the browser cannot be opened.
}
