import { ReactiveHTMLElement } from "./core/reactive.js";

class AppRoot extends ReactiveHTMLElement {
  constructor() {
    super();

    this.state = this.signal("state", {
      count: 0,
      messages: [
        "Application mounted",
        "Nested component tree detected"
      ]
    });
  }

  mount() {
    // Development convenience. Remove this in production if desired.
    window.App = this;
  }

  commit(mutator) {
    const current = this.state.value;
    const draft = structuredClone(current);
    mutator(draft);
    this.state.value = draft;
  }
}

customElements.define("app-root", AppRoot);

// Define app-root first so child components can find an upgraded root.
await import("./components/layout.js");
await import("./components/examples.js");
