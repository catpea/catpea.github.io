import { ReactiveHTMLElement } from "../core/reactive.js";

export class AppElement extends ReactiveHTMLElement {
  get app() { return this.closest("app-root"); }
  get state() { return this.app.state.value; }
  commit(mutator) { this.app.commit(mutator); }
  watchState(fn) { return this.subscribe(this.app.state, fn); }
}

export class AppNavbar extends AppElement {
  static observedAttributes = ["brand", "icon"];

  constructor() {
    super();
    this.signal("brand", "Application");
    this.signal("icon", "bi-app");
  }

  mount() {
    const children = [...this.childNodes];
    this.innerHTML = `
      <nav class="navbar navbar-expand-lg sticky-top border-bottom border-secondary-subtle bg-dark bg-opacity-75">
        <div class="container py-2">
          <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <i class="brand-icon bi text-app-accent"></i>
            <span class="brand-text"></span>
          </a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#starterNavbar" aria-controls="starterNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="starterNavbar">
            <div class="navbar-nav ms-auto nav-slot"></div>
          </div>
        </div>
      </nav>
    `;
    this.querySelector(".nav-slot").append(...children);
    this.concern.bindText("brand", this.querySelector(".brand-text"));
    this.subscribe("icon", icon => {
      this.querySelector(".brand-icon").className = `brand-icon bi ${icon || "bi-app"} text-app-accent`;
    });
  }
}

export class NavLink extends AppElement {
  static observedAttributes = ["text", "to"];

  constructor() {
    super();
    this.signal("text", "Link");
    this.signal("to", "#");
  }

  mount() {
    this.innerHTML = `<a class="nav-link" href="#"></a>`;
    const anchor = this.querySelector("a");
    this.concern.bindText("text", anchor);
    this.concern.bindAttribute("to", anchor, "href", value => value || "#");
  }
}

export class AppShell extends AppElement {
  mount() {
    const children = [...this.childNodes];
    this.innerHTML = `<main class="py-4 py-xl-5"></main>`;
    this.querySelector("main").append(...children);
  }
}

export class AppContainer extends AppElement {
  static observedAttributes = ["size"];

  constructor() {
    super();
    this.signal("size", "xl");
  }

  mount() {
    const children = [...this.childNodes];
    this.innerHTML = `<div class="container-xl"></div>`;
    this.querySelector("div").append(...children);
    this.subscribe("size", size => {
      this.firstElementChild.className = size ? `container-${size}` : "container";
    });
  }
}

export class AppGrid extends AppElement {
  static observedAttributes = ["columns"];

  constructor() {
    super();
    this.signal("columns", "2");
  }

  mount() {
    const children = [...this.children];
    this.innerHTML = `<div class="row g-4 mb-4"></div>`;
    this.row = this.querySelector(".row");

    for (const child of children) {
      const col = document.createElement("div");
      col.append(child);
      this.row.append(col);
    }

    this.subscribe("columns", columns => {
      const count = Math.max(1, Math.min(4, Number(columns) || 2));
      const md = count >= 2 ? 6 : 12;
      const xl = Math.floor(12 / count);
      for (const col of [...this.row.children]) col.className = `col-12 col-md-${md} col-xl-${xl}`;
    });
  }
}

export class HeroSection extends AppElement {
  static observedAttributes = ["eyebrow", "title", "text"];

  constructor() {
    super();
    this.signal("eyebrow", "Application");
    this.signal("title", "Build readable applications.");
    this.signal("text", "");
  }

  mount() {
    this.innerHTML = `
      <section class="hero-panel p-4 p-xl-5 mb-4">
        <div class="row align-items-end g-4">
          <div class="col-lg-8">
            <div class="soft-pill d-inline-flex align-items-center gap-2 mb-3">
              <i class="bi bi-stars"></i>
              <span class="eyebrow"></span>
            </div>
            <h1 class="display-5 fw-semibold mb-3 title"></h1>
            <p class="lead text-app-muted mb-0 text"></p>
          </div>
          <div class="col-lg-4">
            <div class="d-flex flex-wrap justify-content-lg-end gap-2">
              <span class="soft-pill"><i class="bi bi-diagram-3 me-1"></i> nested tree</span>
              <span class="soft-pill"><i class="bi bi-bootstrap me-1"></i> Bootstrap</span>
              <span class="soft-pill"><i class="bi bi-lightning-charge me-1"></i> signals</span>
            </div>
          </div>
        </div>
      </section>
    `;
    this.concern.bindText("eyebrow", this.querySelector(".eyebrow"));
    this.concern.bindText("title", this.querySelector(".title"));
    this.concern.bindText("text", this.querySelector(".text"));
  }
}

export class UICard extends AppElement {
  static observedAttributes = ["title", "subtitle", "icon"];

  constructor() {
    super();
    this.signal("title", "Card");
    this.signal("subtitle", "");
    this.signal("icon", "bi-square");
  }

  mount() {
    const children = [...this.childNodes];
    this.innerHTML = `
      <section class="card glass-card h-100">
        <header class="card-header bg-transparent border-secondary-subtle px-4 py-3">
          <div class="d-flex align-items-start justify-content-between gap-3">
            <div>
              <div class="d-flex align-items-center gap-2 fw-semibold">
                <i class="card-icon bi text-app-accent"></i>
                <span class="card-title-text"></span>
              </div>
              <div class="small text-app-muted mt-1 card-subtitle-text"></div>
            </div>
          </div>
        </header>
        <div class="card-body p-4 card-content"></div>
      </section>
    `;
    this.querySelector(".card-content").append(...children);
    this.concern.bindText("title", this.querySelector(".card-title-text"));
    this.concern.bindText("subtitle", this.querySelector(".card-subtitle-text"));
    this.subscribe("icon", icon => {
      this.querySelector(".card-icon").className = `card-icon bi ${icon || "bi-square"} text-app-accent`;
    });
  }
}

export class AppFooter extends AppElement {
  static observedAttributes = ["text"];

  constructor() {
    super();
    this.signal("text", "");
  }

  mount() {
    this.innerHTML = `
      <footer class="border-top border-secondary-subtle py-4">
        <div class="container-xl small text-app-muted footer-text"></div>
      </footer>
    `;
    this.concern.bindText("text", this.querySelector(".footer-text"));
  }
}

customElements.define("app-navbar", AppNavbar);
customElements.define("nav-link", NavLink);
customElements.define("app-shell", AppShell);
customElements.define("app-container", AppContainer);
customElements.define("app-grid", AppGrid);
customElements.define("hero-section", HeroSection);
customElements.define("ui-card", UICard);
customElements.define("app-footer", AppFooter);
