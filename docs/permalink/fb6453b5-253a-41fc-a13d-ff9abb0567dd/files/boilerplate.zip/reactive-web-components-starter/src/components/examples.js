import { AppElement } from "./layout.js";

export class UIAlert extends AppElement {
  static observedAttributes = ["color", "text"];

  constructor() {
    super();
    this.signal("color", "primary");
    this.signal("text", "");
  }

  mount() {
    this.setAttribute("role", "alert");
    this.subscribe("color", color => { this.className = `alert alert-${color || "primary"}`; });
    this.concern.bindText("text", this);
  }
}

export class CounterPanel extends AppElement {
  mount() {
    this.innerHTML = `
      <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
        <div>
          <div class="small text-app-muted">Shared count</div>
          <div class="display-5 fw-semibold count-value">0</div>
        </div>
        <div class="btn-group">
          <button class="btn btn-outline-light decrement" type="button"><i class="bi bi-dash-lg"></i></button>
          <button class="btn btn-warning increment" type="button"><i class="bi bi-plus-lg"></i></button>
        </div>
      </div>
    `;

    this.on(this.querySelector(".increment"), "click", () => {
      this.commit(draft => {
        draft.count += 1;
        draft.messages.unshift(`Incremented to ${draft.count}`);
      });
    });

    this.on(this.querySelector(".decrement"), "click", () => {
      this.commit(draft => {
        draft.count -= 1;
        draft.messages.unshift(`Decremented to ${draft.count}`);
      });
    });

    this.watchState(state => { this.querySelector(".count-value").textContent = state.count; });
  }
}

export class StateInspector extends AppElement {
  mount() {
    this.innerHTML = `
      <pre class="form-control codebox mb-3 state-json"></pre>
      <div class="small text-app-muted mb-2">Recent messages</div>
      <ul class="list-group list-group-flush messages"></ul>
    `;
    this.watchState(state => this.render(state));
  }

  render(state) {
    this.querySelector(".state-json").textContent = JSON.stringify(state, null, 2);
    this.querySelector(".messages").innerHTML = state.messages
      .slice(0, 5)
      .map(message => `<li class="list-group-item bg-transparent text-light border-secondary-subtle">${message}</li>`)
      .join("");
  }
}

customElements.define("ui-alert", UIAlert);
customElements.define("counter-panel", CounterPanel);
customElements.define("state-inspector", StateInspector);
