# Skill: Build Applications with Nested Reactive Web Components

Use this skill when creating or editing applications in this project style.

## Purpose

Build browser applications where the **HTML body is the readable application map** and every custom element extends `ReactiveHTMLElement`.

The goal is collaboration between humans and AI:

- humans can inspect and rearrange the application by reading HTML
- AI can make precise edits by adding, moving, or modifying custom elements
- component behavior remains local and easy to audit
- shared application state remains explicit

## Non-negotiable structure

Preserve this architectural shape:

```html
<app-root>
  <app-navbar></app-navbar>

  <app-shell>
    <app-container>
      <!-- Human-readable application structure lives here. -->
    </app-container>
  </app-shell>
</app-root>
```

The body must remain a nested tree of semantic custom elements. Do not collapse the UI into a single JavaScript render function.

## Component rules

Every custom element must extend `ReactiveHTMLElement`.

```js
import { ReactiveHTMLElement } from "../core/reactive.js";

class ExampleElement extends ReactiveHTMLElement {
  static observedAttributes = ["title"];

  constructor() {
    super();
    this.signal("title", "");
  }

  mount() {
    this.concern.bindText("title", this);
  }
}

customElements.define("example-element", ExampleElement);
```

## Preferred component categories

### 1. Layout components

Layout components should preserve their children.

Examples:

- `app-shell`
- `app-container`
- `app-grid`
- `ui-card`
- `app-navbar`

Pattern:

```js
mount() {
  const children = [...this.childNodes];

  this.innerHTML = `
    <section class="container py-4">
      <div class="content"></div>
    </section>
  `;

  this.querySelector(".content").append(...children);
}
```

### 2. Display components

Display components subscribe to state or attributes.

```js
mount() {
  this.watchState(state => {
    this.textContent = state.count;
  });
}
```

### 3. Control components

Control components update state by calling `this.commit(...)`.

```js
mount() {
  this.on("click", () => {
    this.commit(draft => {
      draft.count += 1;
    });
  });
}
```

### 4. Root component

The root component owns shared application state.

```js
class AppRoot extends ReactiveHTMLElement {
  constructor() {
    super();
    this.state = this.signal("state", { count: 0 });
  }

  commit(mutator) {
    const draft = structuredClone(this.state.value);
    mutator(draft);
    this.state.value = draft;
  }
}
```

## State access

Feature components should use a small base class:

```js
class AppElement extends ReactiveHTMLElement {
  get app() {
    return this.closest("app-root");
  }

  get state() {
    return this.app.state.value;
  }

  commit(mutator) {
    this.app.commit(mutator);
  }

  watchState(fn) {
    return this.subscribe(this.app.state, fn);
  }
}
```

## Attributes are public API

Use attributes for human-editable component settings:

```html
<ui-card title="Revenue" icon="bi-graph-up"></ui-card>
<app-grid columns="3"></app-grid>
<ui-button text="Save" color="primary" icon="bi-save"></ui-button>
```

For every attribute that should update reactively:

1. add it to `static observedAttributes`
2. initialize a signal in the constructor
3. subscribe/effect/bind it in `mount()`

## Use Bootstrap through components

Prefer:

```html
<ui-card title="Settings">
  <settings-panel></settings-panel>
</ui-card>
```

Over:

```html
<div class="card">
  ...
</div>
```

Bootstrap classes belong inside component implementations. Application structure belongs in custom tags.

## Editing guidance for AI

When asked to add UI:

1. Add or modify tags in `index.html` first.
2. Create a focused component class if the tag does not exist.
3. Keep state mutations in `commit(...)`.
4. Preserve existing children when creating layout wrappers.
5. Avoid global selectors when component-local selectors will work.
6. Avoid hidden framework magic. Prefer explicit signals and subscriptions.

## Good additions

- New layout wrappers: `app-sidebar`, `app-toolbar`, `split-pane`
- New cards: `ui-card title="..." icon="..."`
- New controls: `ui-button`, `ui-input`, `ui-select`
- New feature islands: `task-list`, `project-editor`, `preview-panel`

## Avoid

- replacing the body tree with a single root-generated string
- mixing application state into many unrelated globals
- using shadow DOM unless the project explicitly asks for encapsulation
- making components that silently destroy their children
- writing large anonymous event handlers in `index.html`

## Checklist before finishing

- The body still reads like an application outline.
- Every custom element extends `ReactiveHTMLElement`.
- Layout components preserve nested children.
- Public knobs are attributes.
- Shared state lives in `app-root`.
- Event listeners are collected through `Concern` or `ReactiveHTMLElement.on(...)`.
- Timers, animation frames, and subscriptions are cleaned up by `Scope`.
